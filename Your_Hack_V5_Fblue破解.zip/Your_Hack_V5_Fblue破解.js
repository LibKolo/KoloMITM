/*
*有趣的源码千篇一律,有意思的狗儿到处乱叫.
*By_Fblue_UID:003.
*不是不报是时候未到.
*/
 
 function FontColor(text) {
 var colors = [
 [" ", " &nbsp;"],
 ["\n", "<br/>"],
 ["§l", "</b><b>"],
 ["§m", "</del><del>"],
 ["§n", "</ins><ins>"],
 ["§o", "</i><i>"],
 ["§r", "</font></b></del></ins></i>"],
 ["§0", "</font><font color=#000000>"],
 ["§1", "</font><font color=#0000AA>"],
 ["§2", "</font><font color=#00AA00>"],
 ["§3", "</font><font color=#00AAAA>"],
 ["§4", "</font><font color=#AA0000>"],
 ["§5", "</font><font color=#AA00AA>"],
 ["§6", "</font><font color=#FFAA00>"],
 ["§7", "</font><font color=#cccccc>"],
 ["§8", "</font><font color=#555555>"],
 ["§9", "</font><font color=#5555FF>"],
 ["§a", "</font><font color=#55FF55>"],
 ["§b", "</font><font color=#55FFFF>"],
 ["§c", "</font><font color=#FF5555>"],
 ["§d", "</font><font color=#FF55FF>"],
 ["§e", "</font><font color=#FFFF55>"],
 ["§f", "</font><font color=#FFFFFF>"]
 ];
 for (var e in colors) {
 text = text.split(colors[e][0]).join(colors[e][1]);
 };
 return android.text.Html.fromHtml(text);
}


var ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
/*——控件——*/
var Class=android.widget;

var 线性布局=Class.LinearLayout;
var 滑动布局=Class.ScrollView;
var 相对布局=Class.RelativeLayout;

var 窗口=Class.PopupWindow;

var 按钮=Class.Button;
var 文本=Class.TextView;
var 输入框=Class.EditText;
var 复选框=Class.CheckBox;
var 滑动按钮=Class.Switch;

var GD=android.graphics.drawable.GradientDrawable;
var bg = new GD;
bg.setStroke(1, android.graphics.Color.WHITE); //按钮边框
bg.setCornerRadius(30); //按钮圆角半径
bg.setAlpha(255);

var 屏幕高度=ctx.getWindowManager().getDefaultDisplay().getHeight();
var 屏幕宽度=ctx.getWindowManager().getDefaultDisplay().getWidth();
/*——控件——*/
var 主标题=null;
var menu;
var menu2;

function 对话框(view,Title,Message,按钮name,cmd,是否按钮,按钮name2,cmd2,是否按钮2,按钮name3,cmd3){Ui(function(){try{
 var app=new android.support.v7.app.AlertDialog.Builder(ctx);
 app.setTitle(Title);
 if(Message!=null){
 app.setMessage(Message);
 }
 if(view!=null){
 app.setView(view);
 }
 
 app.setPositiveButton(按钮name,function(){
 ctx.runOnUiThread(new java.lang.Runnable({run:cmd}));
 });
 if(是否按钮==true){
 app.setNegativeButton(按钮name2,function(){
 ctx.runOnUiThread(new java.lang.Runnable({run:cmd2}));
 });
 if(是否按钮2==true){
 app.setNegativeButton(按钮name2,function(){
 ctx.runOnUiThread(new java.lang.Runnable({run:cmd3}));
 })
 }
 }
 app.show();
}catch(err){ERR(err)}})}

function 窗口显示2(view,canFocusable,canTouchable,位置,Number,Number2){
 Ui(function(){
 var layout=new 线性布局(ctx);
 menu2 = new 窗口(layout,dip2px(ctx,75),dip2px(ctx,30));
 var Layout=new 线性布局(ctx); 
 Layout.setOrientation(1); 
 Layout.addView(view); 
 menu2.setFocusable(canFocusable);
 menu2.setTouchable(canTouchable); 
 var mlayout=makeMenu(ctx,Layout);
 menu2.setContentView(mlayout);
 menu2.setWidth(dip2px(ctx,220));
 menu2.setHeight(dip2px(ctx,320));
 menu2.setAnimationStyle(android.R.style.Animation_Dialog);
 menu2.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0))); 
 if(位置=="LT"){
 menu2.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT|android.view.Gravity.TOP,Number,Number2);
 } 
 else if(位置=="RT"){
 menu2.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.RIGHT|android.view.Gravity.TOP,Number,Number2); 
 } 
 else if(位置=="CC"){ 
 menu2.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.CENTER | android.view.Gravity.CENTER,Number,Number2); 
 }
 else if(位置=="CT"){
 menu2.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.CENTER | android.view.Gravity.TOP,Number,Number2); 
 }
 else{ 
 menu2.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT|android.view.Gravity.TOP,Number,Number2) 
 }
 });
}

function 窗口显示3(view,canFocusable,canTouchable,位置,Number,Number2){
 Ui(function(){
 var layout=new 线性布局(ctx);
 menu3 = new 窗口(layout,dip2px(ctx,75),dip2px(ctx,30));
 var Layout=new 线性布局(ctx); 
 Layout.setOrientation(1); 
 Layout.addView(view); 
 menu3.setFocusable(canFocusable);
 menu3.setTouchable(canTouchable); 
 var mlayout=makeMenu(ctx,Layout);
 menu3.setContentView(mlayout);
 menu3.setWidth(dip2px(ctx,250));
 menu3.setHeight(dip2px(ctx,350));
 menu3.setAnimationStyle(android.R.style.Animation_Dialog);
 menu3.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0))); 
 if(位置=="LT"){
 menu3.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT|android.view.Gravity.TOP,Number,Number2);
 } 
 else if(位置=="RT"){
 menu3.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.RIGHT|android.view.Gravity.TOP,Number,Number2); 
 } 
 else if(位置=="CC"){ 
 menu3.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.CENTER | android.view.Gravity.CENTER,Number,Number2); 
 }
 else if(位置=="CT"){
 menu3.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.CENTER | android.view.Gravity.TOP,Number,Number2); 
 }
 else{ 
 menu3.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT|android.view.Gravity.TOP,Number,Number2) 
 }
 });
}

 
 function 复制(内容){
ctx.runOnUiThread(new java.lang.Runnable({ 
run: function(){ 
try{
var cm=ctx.getSystemService(ctx.CLIPBOARD_SERVICE)
cm.setText(内容)
}catch(err){
print(err)}
}}))}

 function 移动按键(text,sizeW,sizeH,command,颜色){
var tpopx =100;
var tpopy =510;
var mX,mY;
var gui=null
var downa=false
var ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get()
var 移动color=false
ctx.runOnUiThread(new java.lang.Runnable({ 
run: function(){ 
try{
var layout=new android.widget.LinearLayout(ctx); 
var button=new android.widget.Button(ctx); 
var button=new android.widget.Button(ctx);
button.setText(text);
button.setTextSize(13);
button.setTextColor(android.graphics.Color.parseColor("#fc030303"));
button.setBackgroundDrawable(roundBG("#afffffff",10));
button.setOnClickListener(new android.view.View.OnClickListener() { 
onClick: function(v){ 
if(颜色==true){
 ctx.runOnUiThread(new java.lang.Runnable({run:command}));
if(移动color==false){
移动color=true
button.setBackgroundDrawable(roundRect([hexColor("#DAFFCE"),hexColor("#BBFFEA")],15))
}else{
移动color=false
button.setBackgroundDrawable(roundBG("#afffffff",15));
}
}else{
 ctx.runOnUiThread(new java.lang.Runnable({run:command}));
}
}}); 
button.setOnLongClickListener(new android.view.View.OnLongClickListener() {
onLongClick: function(v,t){
 downa=true;
 var vibrator = ctx.getSystemService(android.content.Context.VIBRATOR_SERVICE);vibrator.vibrate(40);
 return true
}
});
button.setOnTouchListener(new android.view.View.OnTouchListener(
{
onTouch :function(v, e) 
{
if(!downa)
{
mX=e.getX();
mY=e.getY()
}
if(downa)
{
var a=e.getAction();
if(a==2){
 var delX=parseInt(e.getX() - mX)*-1/10;
var delY=parseInt(e.getY() - mY)*-1/10;
tpopx = tpopx + delX;
tpopy = tpopy + delY;
gui.update(parseInt(tpopx), parseInt(tpopy), -1, -1);
 }
if(a==1) downa=false;
} 
 return false;
 }
})); 
layout.addView(button); 
gui=new android.widget.PopupWindow(layout, dip2px(ctx,80), dip2px(ctx,80)); 
gui.setContentView(layout); 
gui.setWidth(sizeW); 
gui.setHeight(sizeH)
gui.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.RIGHT,tpopx,tpopy)
}catch(err){print(err)}
}}))
return gui
}

function H() {
var metrics = new android.util.DisplayMetrics();
ctx.getWindowManager().getDefaultDisplay().getMetrics(metrics);
return metrics.heightPixels;
};

function W() {
var metrics = new android.util.DisplayMetrics();
ctx.getWindowManager().getDefaultDisplay().getMetrics(metrics);
return metrics.widthPixels;
};

function 验证(){
ctx.runOnUiThread(new java.lang.Runnable({run:function(){
var A=new android.widget.LinearLayout(ctx);
A.setGravity(android.view.Gravity.TOP|android.view.Gravity.CENTER);
A.setOrientation(1);
var B=new android.widget.LinearLayout(ctx);
B.setLayoutParams(new android.widget.LinearLayout.LayoutParams(W()*0.4,H()*0.05));
B.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
B.setBackgroundDrawable(roundBG("#ffffffff",20));
var C=new android.widget.LinearLayout(ctx);
C.setLayoutParams(new android.widget.LinearLayout.LayoutParams(W()*0.45,H()*0.05));
C.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
C.setBackgroundDrawable(roundRect([hexColor("#ff00fff6"),hexColor("#ff3700ff")],20,"右下"));
var T1= new android.widget.TextView(ctx);
T1.setText(FontColor("§l 驗證中"))
T1.setTextSize(20);
T1.setTextColor(android.graphics.Color.parseColor("#f00f0f0f"));


空格(A,W()*0.3,H()*0.04)
A.addView(T1);
空格(A,W()*0.3,H()*0.04)
A.addView(B);
B.addView(C);
UILevel(C, -100, 1400, 19000);


验证窗口= new android.widget.PopupWindow(ctx);
验证窗口.setBackgroundDrawable(roundRect([hexColor("#FFFFFF"),hexColor("#FFFFFF")],20))
验证窗口.setFocusable(false);
验证窗口.setTouchable(true);
验证窗口.setContentView(A);
验证窗口.setWidth(W()*0.5);
验证窗口.setHeight(H()*0.4);
验证窗口.setAnimationStyle(android.R.style.Animation_InputMethod);
验证窗口.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.CENTER|android.view.Gravity.CENTER,0,0);
}}));
ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
new android.os.Handler().postDelayed(new java.lang.Runnable({ run: function(){
 验证窗口.dismiss();
 顶部提示("驗證成功,歡迎使用!");
 公告FU();
 
}}),3130)}}));

}
function 顶部提示(Text){
 Ui(function(){
 var layout=new 线性布局(ctx);
 layout.setOrientation(0);
 
 var 功能=new android.widget.TextView(ctx)
功能.setText(FontColor(Text));
功能.setTextSize(22);
 功能.setBackground(bg);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)))
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){

}}))
layout.addView(功能);
 UIFadein(layout,0,500,2100);
 
 窗口显示2(layout,false,false,"CT",0,0);
 });
 计时(function(){
 menu2.dismiss();
 },2500);
}

function roundRect(arr,arr2,f,s){
if(!(arr instanceof Array))arr=[arr,arr,arr];
if(!(arr2 instanceof Array))arr2=[arr2,arr2,arr2,arr2];
if(arr2==null)arr2=[10,10,10,10];
var jb=null,type=null;
if(f=="上下"||f==null){
jb=android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM;
}else if(f=="左右"){
jb=android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT;
}else if(f=="右上"){
jb=android.graphics.drawable.GradientDrawable.Orientation.BL_TR;
}else if(f=="右下"){
jb=android.graphics.drawable.GradientDrawable.Orientation.TL_BR;
}
var dra=new android.graphics.drawable.GradientDrawable(jb,arr);
if(s==0||s==null){
type=android.graphics.drawable.GradientDrawable.LINEAR_GRADIENT;
}else if(s==1){
type=android.graphics.drawable.GradientDrawable.RADIAL_GRADIENT;
}else if(s==2){
type=android.graphics.drawable.GradientDrawable.SWEEP_GRADIENT;
}
dra.setGradientType(type);
dra.setCornerRadii([arr2[0],arr2[0],arr2[1],arr2[1],arr2[2],arr2[2],arr2[3],arr2[3]]);
return dra;
}


function roundBG(hex,round,f,s){
return roundRect(hexColor(hex),round,f,s)
}

function hexColor(c){
return android.graphics.Color.parseColor(c);
}


function 空格(view,sizeW,sizeH){
var A=new android.widget.LinearLayout(ctx);
A.setLayoutParams(new android.widget.LinearLayout.LayoutParams(sizeW,sizeH));
A.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
A.setOrientation(0);
view.addView(A);
}


function Ui(runCMD){ctx.runOnUiThread(new java.lang.Runnable({run:runCMD}))};

function load(showText){Ui(function(){Class.Toast.makeText(ctx,FontColor("§r§6Your Hack·"+showText),5).show()})};

/*#揭露*/function UIReveal(view,x,y,startr,endr,time){var globallayoutlinstener=new android.view.ViewTreeObserver.OnGlobalLayoutListener(){onGlobalLayout:function(){var anim=new android.view.ViewAnimationUtils.createCircularReveal(view,x,y, startr,endr);anim.setDuration(time);anim.start();view.getViewTreeObserver().removeOnGlobalLayoutListener(globallayoutlinstener);}};view.setVisibility(android.view.View.VISIBLE);view.getViewTreeObserver().addOnGlobalLayoutListener(globallayoutlinstener);return globallayoutlinstener;};
/*#移动*/function UIMove(view,x1,x2,y1,y2,time,type){var anim=android.view.animation;var tp=((type==null||type==0)?anim.Animation.RELATIVE_TO_SELF:type==1?anim.Animation.RELATIVE_TO_PARENT:anim.Animation.ABSOLUTE);var dh=new anim.TranslateAnimation(tp,x1*0.01,tp,x2*0.01,tp,y1*0.01,tp,y2*0.01);dh.setDuration(time);if(view!=null)view.startAnimation(dh);return dh;}
/*#旋转*/function UIRotate(view,A,B,x,y,time,type){var anim=android.view.animation;var tp=((type==null||type==0)?anim.Animation.RELATIVE_TO_SELF:type==1?anim.Animation.RELATIVE_TO_PARENT:anim.Animation.ABSOLUTE);var dh=new anim.RotateAnimation(A,B,tp,x*0.01,tp,y*0.01);dh.setDuration(time);dh.setFillAfter(true);if(view!=null)view.startAnimation(dh);return dh;}
/*#收缩*/function UIShrink(view,x1,x2,y1,y2,x,y,time,type){var anim=android.view.animation;var tp=((type==null||type==0)?anim.Animation.RELATIVE_TO_SELF:type==1?anim.Animation.RELATIVE_TO_PARENT:anim.Animation.ABSOLUTE);var dh=new anim.ScaleAnimation(x1*0.01,x2*0.01,y1*0.01,y2*0.01,tp,x*0.01,tp,y*0.01);dh.setDuration(time);if(view!=null)view.startAnimation(dh);return dh;}
/*#淡入*/function UIFadein(view,A,B,time){var dh=new android.view.animation.AlphaAnimation(A*0.01,B*0.01);dh.setDuration(time);if(view!=null)view.startAnimation(dh);return dh;}
/*#缩放*/function UIZoom(view,In,out,time,type){return UIShrink(view,In,out,In,out,50,50,time,type);}
/*#水平*/function UILevel(view,In,out,time,type){return UIMove(view,In,out,0,0,time,type);}
/*#垂直*/function UIPlumb(view,In,out,time,type){return UIMove(view,0,0,In,out,time,type);}

function dip2px(ctx,dips){return Math.ceil(dips*ctx.getResources().getDisplayMetrics().density);}

function makeMenu(ctx,layout){ 
var mlayout=new android.widget.RelativeLayout(ctx);
var svParams=new android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.FILL_PARENT,android.widget.RelativeLayout.LayoutParams.FILL_PARENT);
var scrollview=new android.widget.ScrollView(ctx);
var pad=dip2px(ctx,2);
scrollview.setPadding(pad,pad,pad,pad);
scrollview.setLayoutParams(svParams);
scrollview.addView(layout);
mlayout.addView(scrollview);
return mlayout;
}


function 窗口显示(view,canFocusable,canTouchable,位置,Number,Number2){
 Ui(function(){
 var layout=new 线性布局(ctx);
 menu = new 窗口(layout,dip2px(ctx,75),dip2px(ctx,30));
 var Layout=new 线性布局(ctx); 
 Layout.setOrientation(1); 
 Layout.addView(view); 
 menu.setFocusable(canFocusable);
 menu.setTouchable(canTouchable); 
 var mlayout=makeMenu(ctx,Layout);
 menu.setContentView(mlayout);
 menu.setWidth(dip2px(ctx,220));
 menu.setHeight(dip2px(ctx,320));
 menu.setAnimationStyle(android.R.style.Animation_Dialog);
 menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0))); 
 if(位置=="LT"){
 menu.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT|android.view.Gravity.TOP,Number,Number2);
 } 
 else if(位置=="RT"){
 menu.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.RIGHT|android.view.Gravity.TOP,Number,Number2); 
 } 
 else if(位置=="CC"){ 
 menu.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.CENTER | android.view.Gravity.CENTER,Number,Number2); 
 }
 else if(位置=="CT"){
 menu.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.CENTER | android.view.Gravity.TOP,Number,Number2); 
 }
 else{ 
 menu.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT|android.view.Gravity.TOP,Number,Number2) 
 }
 });
}
function MenuMake(menu){
 var layout=new 线性布局(ctx);
 menu=new 窗口(layout,dip2px(ctx,75),dip2px(ctx,30));
}


function ERR(err){
 Ui(function(){
 
 
 var layout=new 线性布局(ctx);
 layout.setOrientation(1);
 
 主标题="錯誤";
 
 var 功能=new android.widget.TextView(ctx)
功能.setText("－|"+主标题+"|－");
功能.setTextSize(29);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)))
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 
 }}));
 layout.addView(功能);
 
 var 错误信息=new 文本(ctx);
 错误信息.setText(FontColor("§r§b十分抱歉,出現了一個意料之外的錯誤..\n錯誤信息:"+err.message+"\n錯誤行數:"+err.lineNumber+"行\n錯誤文件/文件夾:"+err.fileName+"錯誤堆淺:"+err.stack+"\n請程序員大大盡快修復!"));
 错误信息.setTextSize(20);
 layout.addView(错误信息);
 
 var 关闭=new 按钮(ctx);
 关闭.setText(FontColor("§4§r關閉"));
 关闭.setTextSize(27);
 关闭.setBackground(bg);
 关闭.setOnClickListener(new android.view.View.OnClickListener({onClick:function(){menu.dismiss()}}));
 layout.addView(关闭);
 
 UIFadein(layout,0,500,2100);
 
 窗口显示(layout,false,true,"CC",0,0);
 });
}

function NewView(type,sizeW,sizeH,gravity,ori,cm,color,cr,clickrun){
if(type=="LL"){
var _L1=new android.widget.LinearLayout(ctx);
}else if(type=="SV"){
var _L1=new android.widget.ScrollView(ctx);
};
_L1.setLayoutParams(new android.widget.LinearLayout.LayoutParams(sizeW,sizeH));
if(gravity=="LT"){
_L1.setGravity(android.view.Gravity.LEFT|android.view.Gravity.TOP);
}else if(gravity=="LC"){
_L1.setGravity(android.view.Gravity.LEFT|android.view.Gravity.CENTER);
}else if(gravity=="LB"){
_L1.setGravity(android.view.Gravity.LEFT|android.view.Gravity.BOTTOM);
}else if(gravity=="CT"){
_L1.setGravity(android.view.Gravity.CENTER|android.view.Gravity.TOP);
}else if(gravity=="CC"){
_L1.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
}else if(gravity=="CB"){
_L1.setGravity(android.view.Gravity.CENTER|android.view.Gravity.BOTTOM);
}else if(gravity=="RT"){
_L1.setGravity(android.view.Gravity.RIGHT|android.view.Gravity.TOP);
}else if(gravity=="RC"){
_L1.setGravity(android.view.Gravity.RIGHT|android.view.Gravity.CENTER);
}else if(gravity=="RB"){
_L1.setGravity(android.view.Gravity.RIGHT|android.view.Gravity.BOTTOM);
};
if(ori!=null){
_L1.setOrientation(ori);
};
if(cm==0){
_L1.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor(color)));
}else if(cm==1){
_L1.setBackgroundDrawable(roundBG(color,cr));
}else if(cm==2){
 
 };
if(clickrun!=null){
_L1.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){try{
clickrun(v);
}catch(e){
print(e)
};}}));
};

return _L1;
};


function 计时(runCMD,时间){
 Ui(function(){
 
 new android.os.Handler().postDelayed(new java.lang.Runnable({ run: runCMD
 
 }),时间);
 
 });
}

var logo="iVBORw0KGgoAAAANSUhEUgAAARMAAAETCAYAAAAVqeK4AAAABHNCSVQICAgIfAhkiAAAIABJREFUeJzsnXeYHVX5xz9zN4EQIIQqndCkhBJA6SU0GyBNQEEhlB+CioACgiIERRBRmgpSlKAgvRcDUkIHaSH0Egid0BJIT2bm+/tj5u7OnjlnZm7bu5vM93nm2b33zpw5M3POd973PW/xKDFPQNIwYJH44zBgcPz/cMvuQ+LNhgnxZmKM5buxwGTP8+4v1MkSfRpeuztQonmICWMlIrIYEm9J4mgnJhORy4R4K4lmLkNJJn0QkgYD6xNJFcPoIo++iiTRjAXu9zxvbFt7VKJmlGTSBxBLHNvQRRzD2tujHsFkItVpLDCmlGB6P0oy6YWQNISIPHYjkj56g5rSGzCmupXk0vtQkkkvgaRdiYhjN7qrLCFQaUOX+gLGxNvNpVrUfpRk0ibEdo9dichjtzZ3Z27ABOAm4LKSWNqDkkx6GLEEshswIvG1D/RrS4fmTowFRhFJLBPa25V5ByWZ9AASBLIbXfaPUn3pGZTE0kMoyaRFiNWYI4kkkCHx1yWBtBc3xdvNnudNbndn5jaUZNJkSBoOHEB3NabXwgdmA3Piv7MTn+ekfhNzABlteEQ62gA85gPmB5Yncrft6IFrqAOfA5cC55bSSvNQkkkTkDCmHkWXD4joJfd3NvAa8BLi5c6/0f/TW3zuhYClgGWA5fBYBVgZj5XjvysB/VvcBwuSz2YUEamURtsG0SsGe19FQpU5il7gCzIVeImILKIt+n88ELS3a050AF8G1sVjHTzWjf9fhR4fnGOAUzzPG9Ozp517UJJJHegNJDIVeBp4EnVur7WjIy3CIGATPDYDNsVjUzwW7ZlTTwBGep53Wc+cbu5BSSY1wEIiPWZQnQ7ch7gD8QDiBdK2i7kdawHD8dgRjx3wWLi1p5tAlwpUGmsLoCSTAohJ5Gy6lnZ7hETGA3fEBHIvYnarT9iH0AF8FdgRj29QYTNaNpgnA+dQkkouSjLJQDskkVeBaxDXEPJcK080l+FLwK547IHH9njN9ACsGmsnUKo/mSjJxAFJBwAjiXxEWkoir9NFIM+26iQx+gMrAkPwGEK0hLsQHgOBBeMt+r/ru+TfgdgHzSTgA+BDxAfALOBDYCJiIvA+4k3gPVqvni0CfBuP7+HxdbxmP7gxwNHl6k8aJZkYiP1EzqbFYf5TgKsR/yDk0Ra0vySwDh5D479rxcuxy9Fer7mZwBvA+Nhg/BJiLOI5IgJqNpYB9sPj/6jw5eY2PYqIVErVJ0ZJJjHisP+qXaRleBD4ByHXoKb5ePQDNga2w2M4HhvgsViT2u4pBMArwFjEU4iHEU8ROdU1CxsCB1FhBB4LNqfJL4CzPM87pTnN9W2UZAJIOpkW2kWmAKMQfyZsyvKtRzQxtsVjOzy2bt7k6FWYATyGeAi4H/EQaor0MggYgceRVFilsaaS9pSjPc+7qeHO9WHM02QSZzC7lEilCWiy9/cbwF8IuRgxtcG21iCSPLaPt7Z7yLUBM+haHr8N8VaD7XnA1/E4Eo9vNGcqjAEOnFdd9OdJMkms0oxsRfsPAGcTcjOq29g4ANgej71iv4plm9i/uQUvAaMRt8e+N3MaaGsYcCIV9sBrdFJ8Dpzsed65jTXT9zDPkUlsYL2UFqzS3IM4kZDH6jx+UWAnPHbD45vxakpfwRxgNQJ8YHVgfTzO7UFT71Tgv4hbETcjPquznbWAX1Lhe3iNiqk3EUkppYF2boSks9UC/EehviJf1LF58rWdAl2jUHNa0bkewgxJyySua1H5zn1PU6ht5OvbCnStwqb3ZZakKxVqOwXy6nwuq8jXFQob7d1kSfNMFr15QjJRd9tI06J570P8nJBn6jh2MeAAPH7SuBGw1+EVIn8W13UNJeDFxOfP6GhZ3M144BJCRiE+rOP4YcA5dLBNY904hyiIcK6WUuZ6MpFUtY00zWb5LnAsIVfVYRFZA/gVFfaJc3/Mi5gMXIt4D7EOHt9xDMO/IkYjtsZjdzxWa+Ccc4BbEBci7q7DlrUjHmdRYZ36uzCWSO0pnd36GiQNlnRjoyJzErMkna5QA+sQm7eUr1taINLPzVgjcf8GytfUJrX7uqRfKNBiNT7DinwdpkCTGjv9ye2eG63CXCmZKFJrbiQysjZlyfduxA8JeaOGYzxgFzx+TYWvNNqBeRATgesQ9yBWB85oskH3C+BsxFmEfFHDcUsAf4id32qcQFUVewxz4RLyXEcmkkYQ2UeagveAowm5tgbBuD+wLx4nUGGNZnWkDZgJTIu3qfHfJelddUinACsQsBzwYyrsW4cPziTgTELOrdEreWPgYjpYr8bzxfgcGD43qT1zFZlIupQo92rD0ogPnIf4NWHhATYQOBiP46iwfCMnbyE+JDJKjke8gXgdeBfxBV2EMRWcb+qT8DilF+XEngQsTdCZnmFvPK6us38fA78n5K81eNp2AEfi8Vsq9Szlfw4c5XneqNoPLdESKLKP3BfrpA0bJh6WtHYNunQ/+TpCgT5u9MRNxlOS/qFQP1WgbeRrcJ3LpMntJAXtvqwUZkm6U6F2UaDbmmCXelfS/ylQRw33ZVn5Gl3/uY9s9xwqQWQfkfRm/FDczg0FMFvS8TX6JmyvQC81ctIm4TNJNyvUsQq0aRNIoy+RSRFMlfSgVJMvzxuS9lJQ0/3ZTYHeq6+LTVPNS9QBSbtJjRrXI7wpaaMaBs0q8nVjm1dnRivUUQq0TgvJY24hk5/EpLCafN1c43N7TNL6Ndyjhes4R4xnFIV69En0WZuJmmhovRxxOGGhYLz5gFOo8HO8Hi/R8D5wcxyLci9iRgNtLQCsCqyCx5rAongsBMZm+65v4kHg6wSd9+x5Ohhaw/EhcDHiBEImFTzmJ3j8iUqt/kTPAfv3RcNsnySTBJE0ZGidChwc5xYpgq8A/6aD1es9YR34DLgScTUhD9bZxtrAhnGekw2A1fF6rYG4lfiAyFnudcQ5VOoy034O/IKQCwuOmQ2A6+lg5dpP0+dWevocmUjNWbF5AdiVgPEF9l0Q+B0Vftp4RGkhTCHyr7gS8d8afTU3oIs4NsJjGFEEconmYgziQEImFNh3YeDvVNir9tFzYLnS0yJIujTWLRsyVlykUPPXYGB9p5GT1YDrFdZs8Ntcvk5TqCd6qI9zM8ZJOlRB4Xs5VdJPazDYH6mgnmDOEe2ed3Md1EUkdVsAp0nareBknU++/tB41Ggu3pJ0uAItVHBADpCv3RXocoX6tMV9m9dwhkKhKJJ7fwWF3fcflLRCwef3Vfn6oHiXqsNvRLvn31wDdfmQ1L30+5KkVQs+8NXla1yBNmdLOkehFlUUrl4LXpD0vRqkkK8p0GUKmxafUiKNqZJ+pkD9FfkOPVvDsZNV/EW1pHyNKd50SSjNgrokkrqJ5BFJixSctP+nQDMKtDlT0tD4mI4algKfkLRTwUE3TL7+pFAT673wNuHqWI1cML6GfRToJAW6QqGeVCQh9ma8pcjHpB5cWFCFrsjXqOIvoJJQGoWaQCTXKNR8BR7uIqrNb+RTSevI1/LydVeB416W9O0CJLKcfB2nQC/We8FtxnSpUFT1mvJ1sAL9XaFebnenm4znJa1Z8OX1u9oV6RHtnpd9DrIQyW8UakoNd/2PsQ6ct20kX2/X+kgL4i1J+xcgkU3k6/a5IEXBW1Jh1S25LaEo89qfFBZSMduFsZIuLfCcpkj6VkEJ9CcKan3yI9o9P/sMZCGSw+IHs4n8XEIJ1eXxmLV58nVMfRb2XHwi6cgCfdhRge5vwfnbiW3qIBNzW0aREfRyhfqk3ReUQPXa9lOgyTn7hpJ+WZBQ9lCg2bV1ZUS752mvh5Re/j3JeCBZhDJb0q4FHuBC8nVHgffBaIU1TfYZkn6nMHd1Zg8FerqGdvsSpil6ex+kQJur8QBDT742lK/TFdYb99I0XJ94thurmPZ9jUINKHCd2yvQ9OJd+UJR3p4SNkg6Kr5RnbP8HIuqspGDTKZJ2rrAQ1tWvl7IeVIz1GXjWKrgoLlMYbekyi4S6c1ifKvwoaQxki5QqB8r0CbyC/v6mMSyjXxdrDBXMmgVXpP0dQX6eQ1eCmMlLVXg+jaVr8+Ld+VzlYSShqQR8Q3qnLn/sBDJevKtkX2fShpW4GGtJ18fFnhKxyakm+NzBs1HypeGvq2gpqXGeQFzFE2yvyvU4Qq0YUwWRYllPvnaW4EeaveFFMSbklYrOEZrUO0mqySULihKI9DtRfMfC5GsJd/qqPWOivmQbKug8LLkP+NyDH/OUYVuVpiZS3Qj+X1msPcGfChplELto0CLFiSV/vI7c1D0dnwiaYMC17S6/FpUusmKamXP25A0REYagaellI65unx9ZLmL76mY9+EIBWoo2YmBScp2OltaNfkRlLDAV5So6lcKcl8WV/eSez1D0qs5+0yV9LUCdr0NlL/YkEDb0xe0NdAvvvj7iMqTAPA6sBkBnyT2GwI8QgfLGMd/CmxOwKs55zkIj0uoNO1i70aMIOQ9x+8n4HFifWn82gqfKM3Bu0SpHN8CphmBhpW40mAyJcEgYHE8liHKEduqQfUscA0h/0bdAuwqwDt09IoSqj8g5HLEXnhcSsVZUN4H9i2QW3gT4F46io6lUZ7nHVhLf5uJdpPJfcDw6udPgQ0JeDuxz6LA/+hI1UyZAmxFwLM55zgKj7ObmLP0qDjxsA3rAlfQwbpNO1vz8RHwAmIc8CbiXeCd+O8HUHdt5Cr6AUvF2xA8hgArG38XbvAcEBWhuSPO67I/Hvv3kgD4MYivETIH2BmPWzPGnoBDCPlHzl3fErizOKEc7XneOYU73ES07QlIOoeoeHgnNibgCWO/h+hgC+O72cC2BDySc44T40S/LnwK7EHAp8BzdGTejBeA7xDwsuP306hwQi8Z0FV8DjyGeBjxMDC2gRq8zcQqwBZ4bI7HFngMpYkFn3sBHgS+T8AQ4P4CWTKOJuScAoTyXzqKppPY1vO8McV27eNQlG5RSiwBH2jRIa+y6MG+pF0K6Jun5+jQL0laPmEkzdr7ZoVawHGeofJ7jTv4HEXLr8co0HqqbWWkndsgRYGMIxXqHoVNtW31FZxawFt7u4JxY4qWjIe0e563HIpWbroZXP9muZGnOqb39wsQydkFjHEXxef8ds4DOirjfEf0gnyoMyT9W6H2VqBBvYAYmrEtrijg8u55jFhGFiCU3Yq73ve4QbZH5XJZDK6PAFsQdNtvRGy8MnFqXMcmC6dT4fgCl+V3ntueru1jYE8Ca6rExYDLqLBzm9SakEg3vxxxLSqUu9aGCrAMsCKwIh4rE+WCXQQ6t0Hx50Hx54WBGUQ2q6nxNgX4JC4M/kHnX3gDMR4K16CxYUlgTzz2xmMbvLlKHbLhcEL+lqPy/ByPPxa7Ez1qkO1pMqmmXAQiY+C6BHyU2GddYJxlel+L2DuHSE7GY2QThtt4YHsC3rL8tjlwDR0s1/BZasfLwD8JuQzxfo3HDgQ2x2M9YD081ottFa0uni6iFaI3iAp/vRLbcB6HzsJZRbE0cAAeP6bCCs3uaA/hdsT8wA6OqSdgP0KuzCGUC6lwaLHpO/elflSXh2unbrCFIcItIl9vWeS1exSqX474l+elWhRPSE4ntOPaoNZMV5Qj46s1qgoD5GtnBTpToR5XgwWFWoCZku5XFAm+gwKnTcq2VWL1tEjqh96GgXH/787ouy9p5xx1vqJCUebVHeYeD1lZPFxt0ZT/tdycFyUtmDO4DmzSJL/JEZC1mIoFBTYT70s6sQYvUBRl8DpIgW5WqJk92tvGUXVQO76Ag1pyW0O+zlWoL9p9AQVxesIu8kjGfjMlDc8hlAHyi+arnaw+XI+nGxQZgzpxr8XQ9GsLIUxRvpv8ZvIz37qjFGpx+fpnDhlc5DB+rSRfrxd7YE3BW4pWtvoXnExD5OtoBXpADSTH7YUYJ+nkGgqMLagonURfyIt7eFx6NItMpGhJJi/J0rKyh5hYcGOr53nLbSaSRgInVz9PBIbGvh1VbI19PX5nQm7P0B2HAE/TwaKO329C7EGIgAuocJjjci9A/Mhij1kXuJsOlnL2oHl4H/gdIRcj5uTsuxjwAzz2p8KGTTr/FOAt4O3Y8/UDxDRgumVT/Ey82Bt28XhbB48D8OjXpD5VMR64CnE+Ya6taGEiR8VjqDCozvOdhTiJkEWJnBC3rrOdZuA9YCMCJmbsszVwHx1FrIW7e553U5O61rNQpN5IiZfmVhbR3BZzc3rOMtkg+bkxENV0BD/IeGe7luO2kN8jovMMSccpKBSOv4MCXaVQs5pw3kmKJKD11ZyC5tVtgxbetzmSrlCodQv0Y1FFKRFrzTf7iqRKop1+ivLwthPjlK/qn1BMLu276o4M9eZMy8S12UnuV/cHam4VFas4/7CkszN8FX7u0El36SGF4UaFnY5zrq1DUZh9s3OgFHH8q3c7vwcm330KtVOBmjVLyNc5CgtnMbvd8XL5dg2lL1qB0Qoz5wTydVux+z6q3bxQMySNTF7B60rnBj3aMmnfl3s1pbrlebcWgSut43d7gEjeVJRcJ49EfqhAE1rUh7yB2ch2QQ++yV+T9H+xDSKrT0Pla2yB9iZJWtbRxurKl4ZbCdvLOLktJF/jizU1vN38UBiyqDfm0uY6sssLeaHZOzVhsh/jOMdPWkwksxWldMxTab6tQK+0tCfSRi0ikvXkF3X5tuJKhdpVgf6oUB/XcNx4RYm7s0ilnyJDf56U8rHc92dB1VbFoCjmKEqwdZyCzFGYJ1FuLr/IKH5LfUXdUY56M0C+dbL8NYd5V1VN+R2sMPPJVrdmSDtZeFjSGjkTcZj8Hksu/bSk7RWon6LcK5vJ174K9EsFulih7or9U55XJElNVJSHw7xLkxVJnY8oigtqxJ5zu8Juaks/+dpVgW6pwa3+FUV5ZrIkr6Hy9WROOzNkjxdDUczTZU0eL7660joemkEHU5Sfre20Yn0b2W6eyIW68rhKihLFmL4b51oudrxlv+S2gHy9lHFn7lKop3Lu3h8cZHVyCyWS2Yp8J7IG9wrydXnBUqShoms9RWFRHbnPIKsi3jLy9RuF+qxgWy9L2jOjvQ5FRss88rtIoXWZ3pOvi5p8/x+VOp33ssjuRWXXJqqhGmHvdWZTV9a0ztm5mXGhG1jeMXMkbZjDtlnlN6+L32hDM95f1zmI5LAWEsl4Zafom0++fquwkFowTZHktorRRtFKgn0BPypgFF4gfmYFbQO6Q6G+lNHeusq3g4yRtLDj+Ly0nrXiPoX6jgJrnuMkrsmR4teUX0RKfKbdnOGEpBuTPb3McsHPW64oL1rygIwJP07qtEG4xLtHZC8M9b0WEsn1CjPfHl8pMIilSH/P8oRt5TX0ND6TtHEOmSQlgz0UFEr/8JmyC6EtmPOykqJx5souf2abCP3gHPK1LXBYMLLdvJGCpOFx5wIpEk8WNy7uV5aLe0HKjLsZIj/TV+CemIj2dty48ZZ+oChupRUIJP0i4yEvEA++vOH3uSIP0Lz6O0fNRWQiRWrcg4q8RPNW9VDkJrC/AmtMl4k7FDpXapCvQ3Lq1rwuaXXHsXWU+WwYUyV9OYdwc2ozheqNuU9kGF0PMSbUEKVVkFDS+hk3o5/87o068IhkHQRTHDd7YzW24uDC55K2yyCSLZSfRX26IoN1kYm0jmrKYN7nMEcRAexRwJ+kv3z9uIB68IWkAzKe0VrKlhg/U9rxskpqNp+pVuM5KbOW9lD5RSpW3tdu/uiEuiKCJdnVCtsqxbk56k2j4qNtGW1V1VSTpDDelNvKPkCRF2Xe1dygMDfTvqfIE/ZGhXOZTJKNFyTtl2PIRlFipYsK3Ot/yl3QfkH5ujajhWmSNrcct4B8PdzMiy6Is3Lm0SnF5tHwdvMIkgZL3V+4ptHxO5Zh/66UGXa+bfGMUlacbbnBi8ue4qBRPCw5bRory9eLOce/qXwntgXk60cK2uo01RvwhqK603kpKTaUn7u696Tk9ED25OvvGSNwquwSykLKrxZZK/6kUKvK19sZ+2yfMX76qZB9rv3SiQxP16stk9jmxZl18fOpsaJKD8tucH2sgTZd+HdGrpVvKsiMU5mjyPic5cTmKbIJFKlCOC/hbUV2lazo6g7lh118IjspVLesFKCzZE8TsLKaK/1WjcdZdr7xUua92ETZeY5jDG8nkQxWZGvtNIisZFzEzyw34IYcsez3GZf9kpRp7/hYstb7bUW8yN8NJ6vklmeQe1X5ld22kK/nmt7ruQvvS/phhk1lXeW7u82RdGTGyy0riM6l8mwgv2mxPO9Lncvbd2aMq1/lSLcFisK1TzqRNCrZE9MGMkjpIsyzJa2YccFD5c5PcmMc7JS1HGqTePZtgXXBpkahyBB4TcZDCyX92ZGEqbqtIl83zEX+Iz2BR2VfadmoAJlUcXmGlHl4htr9hewLCdspKGL8LIRnJO2VE2w4U9nVLZeVXyRp1vB2EEm3+JvPlbYb2ETEP2VIJR1yL2VNVVcAoCuG5i+Wtou8mWqFqyzBQPkak3FcKGmPHH+H3/XBLGm9BTMl/TphTxmo2ldY7lToDPffNyNu5hNJQy3HuFwWWoVbcqT+kfn3w5ZDveVk0k0qOcW4iJUsk/gzuT0JUXbpiBvj9teWb10Gfl5pO0kNUZSF4cqzsrjyo1LvzHjQ2yrQ+03u67yKdxXZzeqN43padt8k5OvgjDH6oeySQcFcI03DThkvrIGy5w8yMLwniWRIfNI5UuQbYSbYselnP864yIXlZ8ZdBIpUC9vKyAzZRdxmqwouIllGvl4rcLzNBbqfIhtRqdT0LrwmaYhjrGaRwwuS1dGwJ4vYvyVlGvVH5JNbz9lOZEglpuqyikUqeU3KDA//YwM3+1gLSWW9QeqBay1/NWUv2SXxuaRFEseuoPzo1RLtw0TJmdXtLxnjdbTFMN8heyhJq5BljPXkF0m2NbwniGRwfLJOxljC6Ozllhu9b8bFrSS/cCYsEzb1ZnU118P1KgeRDJVfU84NSXpWkZv8jaVtpE9gkuy2EE++bs0glDMsY+acJksnVyp0ZqefJvuqZnUrkE2w9dKJDL+SCwtIJS8pO7PX1Q3c5GGW9pqZ4vB+2dfvhypbLSsx92CipJUtY2ABZZeaOCjxAu2n5i7zv6zoJTpYbkfMf+cYYx/NP83wVhJJ1a+kE6ZeeaWFGLLySmxqIZ+isK0MndhE9eYlyVq/d1hJJPMc3pY9neMSynawvFmhdlSgfzdZKpmjLjthVt0omw9MdduxydJJTaUuJB0FnF39fB1ir0SJiC8DrxglK54Fhhm1hJO4lwrbWroxGfgPYg885rcc9w7wZQJmJr5bE3jJWjm4dkwFNiDgdeP7ZYBn6WDJppylRF/CK8CmBEw2vl+DqOTKwB7uz/+A4QQMAV50jPt7EDtklNV9lA42zT7Ntp7njSnSn1oL8x6Z/HCK0ckjLc2dmHEhW4GVSCAq4LwvIX911M35GWE3IgG4rElEArAvYYpI5gfuKIlkrsanRKRhwxrAnXSk6jO/AhyYUwe7FdgYGE8Ht2eM++3xMmsrHZ/xoo8xovae5UBGZPD96m74XFjpvCMvyx4jU90ed8hW/5PkKVoTf8cme1nUmx81Ub1xebdmebaW6NsIFSV0rq7CfC8jpePNspeduLCXjo/bcmwnBWLWCiWfrkUyOTn54UyDiQ+Lq7sl8YcMtt4Rj40dvz0X14z7KR7LW34/3Gh3YeDUmoUsO54EjrX0+xg89mp9AcQSbcIjwM2dtQrhSsSehNYR/G0863g7kpBnW9nJOrETHkMzfj8rX6oaUeQ8hWaHosSzzwAB0PEysJYhHr1LB8slPk8CliZgtqPNx+hgE9f5gKeAr1h++zPip8bFn0WFo5sw0acB6xLwpvH9psBDdDRRiSrR2/AMsKFF5B+Bx6WOF9XXCbnLUMPXAMbSwYAW9LER3BCTow0V4C06rC/uGBM8z1s57xxFX+cj4r8dAJcYndoLrxuRAJxL6CSSLcFJJBAxnI1IpgG/Ns69IjSFSACOIEwRyVLAzSWRzPXYAPiq5ftRiOMdk/BqKqxkfPcKcFQb7Cd52B2PNRy/hcA52X0eogLLxEXJ5IDkh38ZbHyE0cxs4LyMguNH1amSnI343PjuvCapN9cjLjX6XAGucxQuHwdsRkCFgOEEqX6V6Hu4gQ6WsHx/hmVsAAwGbrUYZC9E3Jox/luFAHgAmGX5zQOOzZgrFyGmZzc/ov6exZC0W9ISc2uBgL5/ZBh8llehimMpTFZ3V3QUZXhvBj5ROrYIuevpTFQ6U/nh81QSxbkXT8ieAbB/hpOXLf3oEvL1aU92XNIlcT/2cozFWXJn2Ef2elYGMg2xRV7ruyU/jDIY90eWJi7MEJmOolKXLHEWYertf3aTlI+fE6Z8BzYGTrL0NAB2JeAj4/tXm9KTEu3GV4BrqKQU5znYnztECwU7GUd8AvxfD6s734oXQa5FjLX8Ph/ZWsFfm2SItUJGHM4kpZd6zdiU1yz7VLeB8p1pDF+PNxsmKR2JuUOTJAHbMvNCcrsouzJy9dZlwRL1wVUkfFPZs71/JmnpXuBOcEQ8Pl1xQF8oO/eyy10jhmlS7IY8IaEqlXQAXG5IJbvipXTM8zLYbX88FrZ8/xmwPgFbOhxozkNMNb47vQm2ktnAQZb+nkmFFS3734A416ILfwOPQ8tl47kKx+DxPcszfQz4rWXMLAqcaxmThxHyaQv658JpVLiACj92jMeFgYMzxurF+YbY+kqKyqiFY/r5m1GTM2WPZalurnD7ap6QnSzSxnSlE9V8q0lSia328CYOO8xkSz+Qr+Xk59ZqKdE3MVP2FASVjLFsqzLww15mTxsrt/awoHJz14508YXz9a6oytcwwAd4i8ixp4olgZ0NhrsO8YWjvXWBjRy/XROz4SEWxvwHSjH7L5sglXxC+g3TD/ghkJMBAAAgAElEQVSXww5zlOUN0w+4kQ4KuQeW6HOYH7jNssITAvsYcWFVXEKFBYzvLkK82JIe1of1weliPw24KnslalfXD1mzsqri9MNyAps3qG35rIpDMk51HBWuosJuljb/aEz4rwBbOFsqjl8QMsX47hg8Vrfs+wBpwzPAKVSsvgkl5h6sCFxuGbvjgWMsKsHyROMiCQE/yo+B6VEcnDEf/5Gt6gyTo5yoU3lSVCG9Uz/agKCbhXgMHWyT+PwZsBSB9Zb1Bz6mg0WyumjB1YjvGhd2K5WURFQrniW6niQ9LAO8bon8nEnk7TvB+H4j4Ak6SkvJPIKDCFMvS48oWtg0IswB1rZEnN/oeGG2A5OBZRzSFcAHdLC0+/CjPc87x/zSSk+K1pM7VZw3oBuRfAm6EQlETl8u7t0Dr2YigUg8TOLLpFWrenACYUrO+AMVawj5aYQpIhkAXF0SyTyFP1uM8gJ+aBn1/YHzHRH0Pe/KZsdg4DsZI/ia7J7uZvvSJet0U3GuNhrex9KJ6zJOvm8d0+5t4F6jzZ83wVbyEFGelCQ2Ab5v6eObwOmW6zqTCqs23JMSfQkLApdb7Gn/w64C74jHN40x9QJRMGFP4WZEB4HT/GBbrariumxVZxtZHNhcs3N48sMdRsN7G4dNIUrCYsMCREunteICy8Xs1wRZ4GjLm+S3jttwEGEkmiWwGfCTUiaZJ7EV8EPLsz/OYn8D+J1lXNmWlU1MJ3rpfVJzD7tjCpGx+DTHOXfAY5Dj2IeAD7ObT0knLjLp1GImxw1XsTRpA+h1GSrOt/FSsQtFcLFBTvvisWAd7STxX8STxnebEr1FTPwbMcZCkOeXIX/zNP5IJWVL+Jh0vBpEwYOmWv40ZMbtPAasQMBWBKxP0JCPyl6xX9frRFKRifmAXRwvRhH5VWUgn0wUOaUMIbaX3Gk0+DXLyW/MOOmejs5egNjD4sYOcJNlOfjAJkgDf7T08zcWPg2BkyxsPgIvZWwrMW9hIezOaR855oBtfP0mQzo5joDP4v/fB2emwSKYHxgZG33NqP4q9siYVzlkkloitkkmw+O//SBtX/i6cfKAtG2jivmwG0xFlPLxRsQbluOuNNpbhkgkawSvQCr3xCbYpZKrEOON7wYSGWlLlNjb8I7tD+zlGBsbEMXMJPEkcJ9jzpijcVSD8T0/w+NGKk5fqG/ipfxiqngIWSOQq5CRlsB2B7qJL6ONizYn3/2IaY6Tfd3R0f8iJhLlCtnA+G0mcItxzhFNkEp+b3kotpBsYZdKTqBS5n4t0Yl/UuHPVDiFCs/SkZnJ7FjL+P2dg0xMe+SbRH5OrcICkDIUVzELty00xvDkBxuZbEMkcPACMDHxw0aQmlCmGpSEq5P94+37eKk9rkepte/vNSgRfEpkA0liCFHCGBM3WKSSxWleAqYScwf6ERniT8JjrZx9h+OxnvHdPcia4nFfPPob3zUqneQha4Eka36TRSaSugX23Z+j4kBacknCZdzZFo936OCPFpIwVZxViFzxG8HfUSrr27GOVAjnW67nl1QaNv6WmLdxgmW0XeoIGDTTGVxjecE2E7Z5XUXW/IbuJkTzCrv9aJKJqeJ8TJRxzIZVISunJF8irR9OBm43zpnl9lsEIp2nYSDuyMnxxvmXBn5USiUlGsTeeCmp/jLEHMu++xvjbRq5TmQNYUVwpnR8lcjny4FFlIgiziSTu1MGy+4XmcVatlWfPPzX0l6WY00R3INSN+NAR2EvgMOMW3IOlV6XHLhE30MFOMAYy5OxLxPvjMeixnem42g9GEckANiQNV9zpJPh1X9MMlm/+s+r0LlEBZGh1DSmPtxkMjE7PRTITYmdA5v33+EZ0s7xePyVCifjcRsVq7dviRL1wCZl27xn+5P2Gr8nZ2UlD08Q5Qw61GF/yZqvjxVUdTqvLnaPHULsX/KA0cCmlpM96jhJBdiujkloruK4DLhFMYe0D8xmkGl5h0itGUklpbuWKNEI1oRUrajRiEmWfc24mVmkNYVaUJV0/oNSXt0QzVfXK9Y1z2N0Orgmj68yTD+Ap3PIZCbwvKP1dcDppuvCONLuw42SyW2IGcZ3Pyh9RUq0ESOM8TcHuz1kK0twrGlPrAWrEdn/ZhF54ZoYCE6HzJfBmaeIKPvaEOhOJsOTezyTQyYPI+eC1eYOErgWMYjA6qZuqjgLUJ90k4T5kDzgu6W0UaKN+C5eKiDjCstM6iD9Mm20fMb5VDgBz1qTCtzzFnKlk2Fgl0yAKEagikFE4f/dG3fD1akLEFMgVegKSBFMox6vAZFkksQ2FsNWiRI9iUVJ+3U8SOQ6b8J0rXgXtzZQBLvjcVpGdYhmkkmn8dVMMbex5SSPZzTu6lTVkGOuCgE8aLS3bYNkMsaShDorf0OJEs3AvYilCBhAwP6E1sJWtnQXd1jm004WKaYRVScPWWTymPMXwEImQ4g9X00VZx3L0c85LmpxsOb6ENGK0NcsHoPjIDXxt2pw4psxRWD3eC1RolkQsB8hHxPZJv6FrMGlu1g8v23jdRHSEfrmwkgzsRJYKxoCjMs+70oQk0kiYKcDYGyKTLpf+nSiBNM22KQOiOwVD9PBnZYCRw8Z5xuAvdZwLTCZfl1g2QbbLFEiCwHpHCC2JEMLkq61facjjYcpoZtzpdlwSScf0N1VxEA3yaSbveRlY891jRO4vF7BLsXkwbxBWzYoQbwLvGR81+jKUIkSeegHqRic54jGownTm3waaVUfYDNjvy9Iz89mIsttIsteI2lIlUy6RSi/kqPmuFScqDO1T9onjPYaVXFs4d31ZHsrUaJWmOkGwG4P2cFiBn3Y0p5JJgCPNCid3IWcAoGphSSRNe+BIVbJ5LXE/ytDKtHy800kk+mQyuLtqulRFCbD96NxgipRogh2spCEjUw2h1SYho0kBgFrF9ivKGYD3yRkK0duxKz5mzXvgWEpycQUoda2NJ4l7tQa4WtLJ2eqVbXCJJMNiT3xSpRoMbaAlLPZvRafrH6kfbdc9hBTOmmETOYDFiNSl2wuGmuCMzFpDpl0SiYrVb951ZICwMRrjkZXjTtbC0zRaWCyM3XgM9KEaBMVS5RoBTzS9rkp2F/AWxqfXfYQc/y+RHr1sxasH7c3wTKP5yfylrXhNcf3MTolkyFEqU9TBwwxLsQH3nG09mXHpL0BsRyBVSc0yaRRFedJyw2yxRVBFEF5P5GlukSJZmG4ZbzZgmJtCw2m/RBgA8t+jRhhL6LCxVSs/QT3PJ4IqfCUBFaqJOpfVAA+sGQkSyIjt4FTorgc8T52A85zxudGVRybYcm2XP0EsDwBwwlYniAvo1SJEoWxTQNk8qxlP9sKy8sNjNdViOp6u2ZalmbgcgkhVnO6GV8nmnsYp7SJRl2dsHfv3fgYm8r0ptHemg2SiU1tsqUxOJWwM/taCPyyxanxSsw7WJPIeTMJG5ksCKxgfDc2tVekepjZ5V9qqfOaew5mzf+U6TlNJmZjbpjlE6tYEo/VgK9aOmlmp280f0lRtckUJzOiIkuUqBmmCjEBu51jPWO/pxyTdQ1jv1b6mrjmMWTP/wpGtPCHiYtZgMjy272x2iWT26nwGh2pIDubyGRKQrXCjCta39LeLNJ2klVKI22JJsJm57Cp4Obq52TsQX9mWsU+J5nYGMp2oV2dqA0TLN81kjz6PUhlo7I54ZiEA+mo6BIlGoEtY/0Lloloc72wLdmaksmr0DLFPGsev5fxWwXD+/WjxP+m3gfu+qceab0uD6a9xBVkVLy9NIZYvrMtba9eSiYlmggbSdjIxCaJm/MCYCNjvw7ctX2L4EPgPEc80NKkk71XkRGfQ8oAm8TiliY/dYg5i2Z0wAWT5bKy2ReBTQSzPSzbenkpmZRoJlYn7fxlk4iHWL6bYPluS7rXbjqpwYyBPyXkSEJnKkhXwTnX/IcccqtFMrHtm4dPjI4t2aB0YJNMbCJbKZmUaDU6SL+g3raMu+VJk45NMgE4iwrj6eB1OvhVg+O1WujLpba45nNWIfWaycTVmGmoLQKTmBpVc0wfmSVJZ9SHNJl0YH9DlCjRCJa2ZEoz4ZF+4WU5Ua6CPV9QrVgm/jvZ8btrPjdAJmn2c0smdqa8HLE0QSolAKRreDRKJkXbM5ejV8Udj1CiRL1Y2vg8DbsLwlLG5yxVolk4iArfxEulQqjCNZ8n4Tb8ZpKJuZT7BTgv0yUWPUJUpNwsOQFpNWeJBkU3k+hcfTLZ2HzoJUo0A7ZxZVMrzHGf9fZvFtYG7qDiXD3NMlvYSnNADpmYBZSz6p0u7Pi+ysS2Wr3mTWs02fPHBjktZiGnkPR1LFTaS0q0AF+yLmCkYUrQLum/J+Gaz5B2v6iiQsayshm2bxb/TsIVLVyNQLSt1JjikkletcJkTJve97nlu6wbV6JEvTBTIHZgt3eYZPI5OLKN9Byyov9dPFAhw/Zo2hHqIZORVPgfHexpYWlT8Wm0PJbJmDZpaIrlu5JMSrQCWwE/icf9CsBlVDoNn0mYycfA/fbvKdRDJpk5g5pBJgBfdXzfajKxFSe3xUeUZFKiVfgzFf6cs898eJizYRZ2kukp2PpURZZk4kRtZNK43aHZZGIjOJtkslCD5y1RohHYxmlflExqIpOsC6w1wxrUL5m8/D946Kb093OMz6ZkMvljuOcs0c8wnCzcAwbYD96El5+o/bjpX0TXG7ZbiW4Arz4VXX+t+OxDeM6WUauP45n74IuEX3o7yORDYFECDnQs9GbNZ1ffMtUcc3JmoR6pwjS42qqz2/Dk3fDcg7Dlbtn7mWT16Qfw0EiP/nuCn0jUWV0Gm/4FHLJBwU5Y8KOzYMtd7b/dcyU8ehv89ZHa2nz9WTh+J7jmbVhosH2f3+4LLz1eW7tVLLsq/PGu+o4tiguOhY12gO//srbjnrobLjkRrp5g//3ZB+CMA+vv1xHnwWY72X+76ky45W/1t33JMzBwkP23X+0Kv7kevrJj9Nnm42Sb4kdsCfsc6x5jteBNohKeLue0lYBtHL+Zl3UtYi88+hFlArCu6JhkkrXakqUCuWCyX6NsvADd08rZSjPa0JkkKYykl/1OgJVsYZ8ZOOMgmJ2R066VmDoJVt8QdtyvtuMevQ1efaY1feoJzJkVPa/j/g79alwKzHteM6ZEZDDi5Pr6Np/N9dp1Lst3tsMnf9y8MTYNcT9uZ803iFKa2mDOq+pCRz+iuCIrmZgEka1HCVuo3zWISxH/sFiyTTUky4+lCAbQ/cEUve8maa67Jay3VW3nPvOQ2vZvNpZdJV9SM/H+G32bTKrYfBeYz6wbkYMiz2vhRWu/p/XA9tKrgYvqQtXD1eXblSUcmLxdrdGZqZ3UIpm4pIp/IkYjaxp/k0yaIZkkUVQyKbpfiRKtwHTL3Gg1mWwAPEEHFzkoYFaGS78pVFR5oiabST1qTlVWsRFFWs2xSzdFYb6cipJErXlYSpRoJmwSdD0LGrUiq5531ovdZevMlExqUXNcJ68aeGzHzm8QRzPUnCRcas5IKp03ZGtgn9KdvkQbYb702ulfUkUtak5SMnFFITPN+GxWKkvCNXFPo8L6iJ0tE9Z0Fms0qbPZP5tPCcABeBxCB++SLjRdokRPwyST3uBEmfViNz3LvxRrFP2IsutbF5smG2rHgvEnmzblSue2HPAzx5vfjEkwUwjUimWN3r2fofctRn05WEqUaDY+jP/2/wxW+lu0UHG5Zb/prrdjC5AVuWzO2yrxZNpMbKHGS5EuhxGdvPYcDGkyaSyPw7LGZ1flwRIlehOqdaX6T4LVf+/BZvCyRddZaxNY3Bbc0wK4IpcHkbZqVrWSmslkUVxkUjuWMCSJRiWTxd73WPna7t9dTpdl/NMPzSPmPlxxOtz412L7zpkFS2UVSWkBHv8PjB2Tvc8iS8B3j62t3Qeuj5zY8rD+1rD1nrW13WqYzsFLnx9y6qqNBpdk41bEtYi/UEk5oUF2rmcThchksqVB17p0PTkYTMnkI+teaXztB3YvwIXfgjV/XWHK2hDGFt/76b7Mttow6G+LAJxLsNXusEoN9UIW6OHApKmTYWJGjUmISK5WzJwO02z5JSz79SZ8Rtrz25YHpdn4M+K/iN0QexTMuwJ200C/hM3EaYC12UEWc1hNmkEmRaWbpcyaikZ7T10dMCN2w/s1Fb4xD63WrLhmtOUhDCGY0/PEuv33oq3Z+NoPoq2vwZYX1kzj2Ap8FM9hM09tFa75vKhl/yEJp7Vu5U2TKe5taodpl6hCuMngX4j/Wb5fxtKxrCJfebC1V0d82TyBB2+A3b/U7l6UeMfyYnbNsWZiDpHtw1aOdyrupWEb0Tmd1paji0RsJoYVMvIcvI09d+ShhPjAbDq6TXdb1qnXqP9m2pzPnmvQEa5EiVbiOct3PVF25Vo6eBFZkzVlaaGmUjCDLjJJSSbLGxdiNpxlr3PV+1iSSC80DbeLko5AfLXJmbnH9UCm7xIl6sVYy/jsiQTnawPfcZDWWxlzxuSHd+mq513xPG8yidSo5tvd1Okc5grArVKsGp/MtgpkqvfNJpOx+buUKNE22Mik3ahFMvkAVesLP1tdf+qcc8ulmKf7xa5QR4X0k/EYRYX1Lb+tZrRnK93ZCKZhL7dYokS7MR14pd2dsMA1jyE9/2d2fZ5cJZMJ1W/MLPKmZGIz2FThkkyG43GAg4RWMz43WzKBUtUp0Tsxrt0dcCBLMjH5ITGrx6TIZFVj0o83JmI/S4NV1EMEQ43z2Sr/NYqnSzIp0QvRW8flG45+LQiYC4AzuvadkFJzzGLLL1saXdMhZbxG7RnXNrS0VUeq1G5Yw/g8ppc+tBLzNu6z1LzuCYxGqXMn4bIzrk16XTSxIDMhJZmYluSXLCfNymj4fMZvNqxGOuT6yQYn/1eMS34YdxTka8AehAwn4DhnFdUSJZqPu41xbrMpNhuzgV0I2Sl21zAxHnfuZ1OLgG5VM8dWADzP60ZGGyb+/5B0rZm1Moywz9dBBGZdnacaJJONjP75wIOONkcQcGOcD/PiUoIp0UN4k7Tr+Vd7wL/kWaL5MB/2WJos++LalprIVcnE87zJyWiiTrvLl42DTGkjy1vbRSaTgb8iqxpkqjqNkontodzraLNRlapEiXrwrGU8mhJ1K1C1h2zqOJfNia6KocbnhFPr/dCdnCYQJ5beAI+rEhf7P9Tt5DY7RxVPOb6/BfETQl7B4zwjwdvmeJydON84Immo3hi05eMtuRJ1j4NM1iJtVb/rVnjrxdrOGRSoazNlEvzXlqgiA+++Wtv+JZqHzz+p/XlVsdEOsFiG95lpfO0ANsbjcuDhW2GwGbgWo998sO3e9fUJ4Ft4/ImKtVwvRHPdhY2NYz6ik2AmQHcyGUNcKmMjo5EnDZf0RYiMnLY18kcRIel8kFUX4VsQ5xm/bWt0MiQymtqysxXFN/G6qS1PEAUvmc9od7xO0U4dMGVNeGwMvD6mtvMtvzosmJGKbuFFof98UT2WWrHMylDpKetcCQAGLQ6eV9/zAlhutWwyMYsCbI3HoPmiZz36UvdxAxdujEwWxp2sDOABB5msSHruTOnihQndfpB0lGJMkoT8zm1N+TLxfQXd9kluY1N7S7MlLRD/PsPy+5eNNn6uwLJXNt4fL533U+nzT6XrFab6dYnC1DHjjGt1XW9vxsO3SM8/Utsx774m3XpRa/pj4tHbpdeeqf24d1+T7rnS/funH0S/B7UPFd13jTTxrdqPawZOHxVqwLvdx9wZlrHZ03hV6blQ3fa0zMd7u/q8m0kmw5M7rmI0Nt1o6FzLZK1uf3PcmIcl3eT47WCDnDZqcEJPldRh9Gs3B0ENtVzDow2dvUQJNw6xvIifbXenJP0zY07/3pi30yU90/XdYEhoI57njUmSi7ki8pgh/pj6UxKPOkSlzYFdHcdtbXz/DOlVpFqwYHy+JP6LrEvE+1qS9P+9XCYu0QIIuM2YH0vSOxKbu+YtpFdcnwSGRXP22Ti+LzWLOisCmmRirnpsZDm4SKdc2MphN2kE3zV6OI2oLqqJH1gI7l/ImSS7RIl6cRdKpfbYt5ekyDAFhiTMlabENXS6lZh8MKb6j90I24X+uJ1sXqX2shUrQyq3gms5tyj2xUvV+PiHpc0ViOrnJDELuKj0OynRZFxqfZm1Nt8rRDmKdiTkIcfvM4l8UGz4MulUIZWu6xjT9V13dP5gMtETlpuQpeq4nMSyYK7eXN/gZB4MqfyW9yNrQOJPLA/0HMJS2SnRNHwO3GCM6ZVJv7hbgZsRdyNGOkb04+Ac6za/rYQX/JjqP91mUNJuMpjuEcITSCQ9iZFFJvWoKHsZ7b1N405lBxptCrjUctv2xEsFMU0EriilkxJNwuUo5ap+SA9IJRDF44CbuO7NeG2a83wKkTdsCO94njeh+r3tSjrtJpsYjZiOX1mJmm/NmISj48zYJrbDS2W/vrZB2eBreKk0kKNQ6uwV4AjL7fhtKZ2UaBJMo74HjOghe8mHiAqwq4O8suarOc9fiP9W4Onk97aWx1T/2dFo5D/GCZclqqZuwyu485scQsg3CFPpBjqInMiSuLpBycADDjbafAe4ydLuD/FS1edfA64ppZMSDeIh0o5qW9EzyaMBbqGDN+hIrXACfEC6b1WsTDqTQGixl4CdTG6q/rOLMQlHWyaVuU8SLpvH5pGIZF1+tak6TzrPUAw/ppIKajrdcu4lgEMt1/PbUjYp0SDOsIyhI3tIxYGo3s1Kjt9uzHhZ2rzQE9nWxiS/T11NHEH8BUTr38l6Tu+SDvrbOeOG3OqYhFWj6HjLbzvgpQo3N6rqfAnYz7LUbbPrHGchnheBf5fSSYk68Spwu8XwulsvWRK+JWNsf8uSVnUFQPCFmW3AxQT3Vf8x9SVTOvkqaZ/9Kh4kbbQF2AePv1NhlOX0HcDexjltviG14heWc53hqFliSzH5C0JnnocSJbJwalIxiHEUlR6US9yYQTpJUxXzEdkxk6gGz3pwo7m/63rGVP8xycS0m4Dbq1XYWc8DDsLDFRdnksmbuKN+i2ItIqknidHImszpJCop/5R3iVIolChRC94DrjTGzcLA//USqeQOR1oQiGym8xnfzeewl0ABMtkGjwUTP9yPmGbsnGU3yRKhXNgRL6Xfnd+EiWyLlvy1RYVaETjKsu+phDWnpSwxb2OkJaPZ4RZDf7tQi4ozHdii67ubzP2tZBLrQp9DpHZsn2g0IO2ZamOwKrKYzwUPONTo2k0WN+Ra8Q08hhnf3YS9dOmJVFJF2j8FHi6lkxIF8SZpj9cBwNE9pOC8TuT16jKwhqRtOUmYNp2EgeTmajxOEllX1ck8earOQLoTThLTqU86OdRwhQ+B8xs0xHrAby2XfAzpzEaDgFONffsBK/cS8bRE78dxhKmRdRRej1TsA/gTIXcjHnHMv9HIWR98bdLL1jO72klJJZBNJqOq/5hqjM3BZZ+MSWaLR8jDEqRtMRcjaxLcWrCzRTp5EKxOdIfhcSge/Yhu1N+oMKTB85eYN/AccJ0xpgYBJ/SQVBJAZ7bEwxznvCRjXpr+XtCtzEVtZBK71r8FUQrEZN7Xd0k7uexj2FaSGI06i6GbeBxYk4BHLL8dZolUbDReB+B0y2WfYJF6KsCFVHiHDp6lI+X8VqKEC0dbxtOvqaQC5lqFWURpTw/FY1XL758Qxeu4cLAxR8bRmZ3equJAtmQCCenElDxMh7MBpB3OqgixR+tClHPyFeAIi6qxPV6q4l+jqg5EatumxndP4WbqpYF1Gj5riXkFN6LU6uNywE968GU0EHiHDi50TPFL4/SqNmxJunLnpzkqDtRAJvsbu15hCVoakdHcKEfXv4vHACInf5tL7w+NNh8AHnP3tzDOsJQ8OpaQT5rQdol5F1OBH1nG+qlUGNDz3XHikoyXsm0eJ5LIj3Edl0kmcUTgswCrEDFWFZNJx7dsg7sW8cvAo5bvlwR+F4t/NjXpELxUlvpfNUE62Zq0c9pk7OJpiRJFcSJhatVxI3ouoK8IHiTyyrVhANELPon/QdUn7NlklLCJItagc6r/mNKJzbB6QEaTttB/iPw/PqcjFVAEUSqEnxoXdy9qinTyJyosbnx3OdmlE0uUcOF54C/G2PGAS3us8GcxZEkl37HYPgd0XdM5ZCCXLuNksZMgEuGWJOjMo1oBPqSDJRP7vw8sT2CdjgsCn9BRs7g3GViWgBmJ77bF494mWMb/iTjAuLmrA+Pq6GeJeRc+sClBqm7U4XicbxmnLxMtHfcHjqeSyrHaKkwDFidgluP3u6l0c/P4CFgKCGFKBVZ0GV+hgGQSH3wZRNbh5HJtFPmbTkuwjYOjplFfSoHBpI1X9zVJOtkfj+GWYKajSnWnRA04iTBFJIOB0yxT7D0i4rkVcQNiR+NFWS984E/IWQgPolw+LiJZlnQszivxfK3ADVlEEu9TCJ0WXNPOcJFl0mXph6dZgp6K4DgqKRdk23JuPbjYYhy7EGV6B5YoUcVDwO8tY+VPVBhs2f8Awm4BsJ9Dw97dABcgjiHkbMe8CIE/ZsyZg/BSMzfhpJmp4kBBMvE87yZi9/qv4bFU4rc3IeUjsjdeyhW9ilfJXt92YQmi5EVJjEE8UHNLaawG/NFyK35gMaaVKJHEZGAvi1r/LTwOsrxUL7csG6+Ne+GiKELoJBHTgFrFNcgovdeFCnCgMQdeIvIxA+430w242iiKURDF6pilIUyfkwWAIzKkk99lsOMUYH9Cq3PacVRSMUCHE1g8VGrHjy3qziRgH4f9p0QJgP0sL5zlgSssU+sz4EjL2L+kCQbaN+NtfewJjSB73u2FxyrGdwn3+VENdzAJScOq5bueU7qM4MdGdbDP1FUO1Lbd5ajsNzquKraUo4zozyzV0M5rUmnF9yUNsvT1+DpKlZaY+/EHSwW8inw97tj/e5axu18Tx9ZdCiHKS6AAAB/7SURBVPWm47fRGdX6kK/njf0nxn8DqdaqNYUJZUz1ZNsZN+ZXlpvyk4x6xNs4yn8GkobE+/zFQhJfSFrCaGth+foo704XxJWOm35NL6gFW6L34C6F8izj5DeOcXKzZVwtJF+f9FB/t82YiztZ5u6dXdeRayupota11ZHVf443RKnzUcoi/bOMbFL3Aw87OvSr+CgbJS4MnGW0OgU4vknG2O/iWSus/YCw4bIbJeYOvATsbllI2BaPEy1j5z1IuR8A/N7i59QKPIk7mxrAb4z5NAlYowbDa91QQjpZp4C6YRPtqtu3HCJeKOmB+K8LW1jae6wwT2djpqSvWtpfUr7eb9I5SvRNfCZpecvYWFG+PrXsP0f2sbSO/B6TdfesUUO4putfZxyODfV4fY2s/nOScfjZlhozx2ec4g7EOMv3HlEZgCyPukvoSJmtDmuKKRbmB26ngxWM7z8Gvk5A5mJ7ibkWM4FvEnTmQa1ifuA2OlI1nyByrzcl2gHADXT0iIP9a2Rnn/+lMT9nAMsU9Hg1UTOZJFMTfAevW36PN0nncFiPaDnZhZ/WSQBrAj+yZII6t0lrL0sCo+lIxQU9B3yNgOlNOUuJvoLZwC6EPG757R9UulVxqOI+xB8s4/E8KqzehD7dT6JingPHZhSR25D03HwU2DL67v5khc+WQdKIqhx0kWFYWs8iNt2TY0m+sU6Bz2aMHSBfr9fVmh2jHYa24Qo0q4nnKdF74Uv6lkNVONKhqr8vaTHL/rs3afXmtnhOreRYyJCku3Pm3fWWefd217/DW04kCUJ5W4p0wiWNTo5JdVHaMuOiVpKv2XXe1JssN2wj+U1dzP2n46HsrEBzmnieEr0PgaR9HESyiwLrVJ4paQPL/kPk64sm9MmXtFLc5h8cL+LZklbJmHMbWGw2j3b9O6YeTmgkUu4kiPKiHms0c6ZFsDovQ0d8Czg7Qz2ZDHwtzmdpYlc8vm+0/BTw2ya6mv0Ajz9bbtVtiL3LejpzNd4F7rKMpR3wuI6K1d3sAMJUbp5+wI10pArM1YPP4n6tib3iAkTz6Y2MNs6xzMcVu/4d2VAH64GkCZI0VdLCBvM9qjQOzLAqZ/mKPKXISW6gQ4X5XNIyRnv95OvZDHavB2c6JJTtFWh6k89VovdgnKRFE897U9kdKiXpLMcY+UeT126ekZxq9vuSBmZIJXta5PZHuv4d1eNEEpNJp+3kFOMmbmQRAD/KuciDM5STfWMi+o5jn/ssD3FN+TXZNW5RqEsVZqpcv3QQ4qby9XkN5yrRtzBO0iLxuJ7i2OdeharUYFdpFfbLeGn3l6+3LMe80/XvkLaQSUwoEyRpuqSljI5famHj32UYhTz5etpxg96T9DUFOi2D4Y+23MSDCj7IgxPHbi5f0zL2PdbxsIbK1weFzlaiL2KspMmO356UtJBlTOyooEep5H9Kh7okN1toyP1dc2pU24gkJpOjqj250CCKJS2Tcqa6jEe2bSuLRFMUsyStaWnzrzki5seWB5C3WnOSg1CWk6+X676CEn0RzyqSWsyxsJZ8Te3BfsyRtF7G3LLNx4/VjSCHNMIFDacq8zzvHGK/k0PwuqVe/Bj4rWGMnR84M+O0DwJ/q9N4Oh9wlcUk9mPCzPX4AUTZvJMYg9jLUkSpilOoWK/jPWATAh4s1uUSfRwvAdsSdMtPApGf0l10OMu/tAKnOZxAqzidSmqcP4qq+V0vy8rv2mOQNLxKbbcY0kl/+ZEeZGCTDAZt1FfkCosqtZj85Bp6Cpc6/En2yRFT/6ZQHZbj+snX2WVw4FyNV5V2i0C+FlFzjf9/VagVHPOoihcl9cuYU8OUXgp+WdIkSb40Re20lZiQdFO1k5sbF2Jz1Hlask7e6taor8hhFjVkHbmNZ1LaAa+67a8gkxbuVWgVc5GvbyvoUVG3RM9gkqKYF5NMFpKvJ5t4nv8mjLp3OkZhnnqDfN1vOe7Srhk2st380Q2ShihapbXmO7E5sh2TYXVG7nDuKiZKOleh1bYxW9Kmlja/mUMMf3EQyl45DmqvSFrRcR1ryteLmVdSoq9hWOezDTpfJANkd4loBNVUH/tmvFpd9rvq9kPLsQ/FsyCIHMlt2SXbC0kjq501o4VtbvazJK2WcRPyfEV+EZ/D5aI8UekVJuTrsByZ53wHoXxTgWZmHPeJpG0c1zJQzfc1KNEemG4IX1agwfL13xY8338r1O4KnH4tY5Wt3qwkuxH48a6+HtVu3nAivj5NlNTfuDDbsu7jknVtPvlWd93IpxLn+LvjQT4qWW0av84hlL84bChbOR5OFXMk/SjjTbGvgtIfpY/jGXWXvBeRrwfa0I85ktbKUW8eshx3Z9e/Y9rNF5lQwhh7omVS2ZZNj8sR047ImPhXKVQ/+RqZ8Va4wCFpnJPzJrk+bts8bj35+jDzSOlihZrfcT1fismvlFP6Lk6Ox+xK8vVMm/rgcqCsbj+yzJsXFNl75kSO60PazRe5kDRKUYdTPiUbK21VzlN3kK/bM6be61Km+iFJv3LceJtjXRJ3KrTmsl1W+Rb75yUNzbim9dW8hE4l5i08pGyJfiWHRN8n1JskJA1WbIx9RulVm7PqUHcWUeOpBWwrPBX5ui6HUB5X99iMpB1kdM6xMyT9OOMN4snX4QqaEk1aYt7A+7IvSeepN7fFY3W29FC7OaImKOEZ+3NjMi0g+5r5L3LEtjWUvbRbBCMc58iSfKRoTX45y3EVRatOeSrL3Qo7E2XbtmUKkFqJvoPzFNb08gsk7ahAQ+VnrhrOlj29QZ5Z4DlF6k2MIe3mh5qhOF+sr7ShaEvZV3fWzrlRtkzatcCXPSdmP/m6IWcyf6CuJUFz20FBbob8GYrUrSzr+xYFiK1E78bx8fhaQb7eK3jMofExS8q3zIwuHJDzwrWpNzMkPdY1pka2mxfqgrpq7YSvKK3G2GJmXlJ2vR3k69QCk220wk6xzsQcRUGDZrsd8nVlTtvTJO3geKBfkq+Hc3sWSTlZpQeQr3Xl69rSSNvnYE72Lyu/nMU4RatD8znUkypcLgvVbX7ZA2VvikfRHOm5dnNCQ1AiTcFpxo1eSL7etVz89Tk3zVP2mn4gda6k/M2x3wy5XfovyZnCvqQTFFiXjjvk6xcFUzpeqVBL5xDnqvE1lCkiez/2drwgDsmRpmdJ2k2Brs4Yd48r7WphbldZjn9S3dSbYe3mg4aheHVHSqsJ2zpu9Ak5b+48g2zVu7Yi99LdZNkJxSso/dyr0OoUhyL7ThG36imSjlKg+XIGypKKbDNlioPeh+lyS5p5fklFUMTg+lPLPJos6dG+rt6YULS6M1aSPpRSE+c4y40I5FYnqttacufUDCXtr0Dzy9cLGQ9qitwSyncV5Oam/Vh2lalKZL8qmCf2LUU5VWwOdqbks5MC3aCwzD/bC/CFpI0dz2r7JmQymZHRfnXbUnY7y/ldRJJbdLxPQZH9ZIpkT9B8rUUSmCx3vEvyRro8ZItiitwJr7eUr88KtPEXhU4x9NAaBtUbikIR8kgFRTaanyvIJMsSrcPbcgfY2VIj1gpf7hdVdVtG9uJfF3SfT31fvTGhhP3E1C8Hytc4y00Zp3yD7DccWcJrwVRJuzge3GoqlvDoadnJb8U6eve2IlXNzK3r2jZW5L/ztLIrIZZoDu7IiBTPyu53n8LCLgBZ1TCR2+B6n8KknWREu+d9y6CEd+yqlklnY9k8gyzy9f0mvAlCuV2UB6lYINdkSd822mjkLTVF0jkKc30LkttgRWU4/qRQT0gNE22J7sjyhzo541n/K473qii/tMuROUSC7AbXdySNq6PoeJ+EEvaTiUrnzdxadv0vL34HRasoRTBZykyUdI1CDbC036HiCY/+qlDbKdAxTcxn8pwiacVl9HVtC8nX1xXotwp1i0K92aT+9AW8L+kIBdomvge2vB5F8YHSuXqSmyvYVIoGfHX179iccfqHAi9PV7zaTV19GNPuud4jUGQ/+VySHrDcOJtlOpS0VwFC+UuByb5p/Hb4ZcZDfUp2j9eqFNTOhEe+opih7yvIzPafRzBbytd+CnSCAl2gUKMV6jlprkjm9IakHypI2bGWVX0Fw8fIvaIySPlhFY8ril4/JodI/l2ASHZ2ZP/7V8KfRL0xR0mroIT9xJbc5QrLw5mjrmQxrs2T33lTXTg50cYFGft+knG+FeTrvl5gnZgu6TKF2kOBFqyTWGzbIooy021jbL09J8vLihzHXAbs/sp2V7fhNxkTfA01rxztnY4UoMltc9nLt4yO/8YpGOc+g2selPA/2cly42xZq6YqPzahQ75uzRn0Z8SrL2fm7BcoW8U6rBelZZylKM3fkQq0TkyszSKX6paXB6YdCBVNxF0cjoTJLStVhYnxsmfrq25fb+KzHyNZVevkNlR2V4hn1M0xbbd2z+u2QAn7ySxJyxo3b7B8PW+5eZ8ou44qKhZr85rcVdFMXKfQubKyolqTZatRfKYoUvQEBRquwBr53JfJ5AtJf1ao1Qv0e0cFeqKGtk932M2qW95LqBbcmZH7prqtLF8TLce+JiWLavWNtAKtghKE8onSLsNLydd4y018S9KXch5AkVibWvCqsjNbjVDgLNLUW/CBogjmsxXqpwq0uwJ9Vb6WVjFJpjeQyVhFRtUiat12CmrKyzpO0roZ7a0uuwtDFU9JOk1h4QC/Kx0JuMw5YFsweFvSI13je1S753KvgCJCeU6SJihdYnEFBys/p3SNY3Pz5OuyJhLKdEkHZag9X1LfTSUwW9Kbkh5UNMjPUKhfKNDhCrSfAu2iIDeZVKvwkaSzFeamKaxuW8rXgzWeIy9z2WEZuVilaBVwULzvuQXu00WO1KDJbWG5pfPEOJu7PFwbhRIrPI8rnd1+qPykXtiJB5Wva3ryk67FuThRgf6Qs/8Vjgxs1W17BXqp8Blrx00KNVKhrlU41+aU/ULStQr17Zy0DdVtAUUOY/+r8TyPSpmq0lLy9Z8CtrWqqrJ7gTy/eRnlURRFbItCnybp13F/wmjOzDsrN0WhhMv9bUoTyldlrwF8n0JrnVdzy1oKrmKGuhJQ76EgM3z8TUlbZ5yvQ75+rMDqiNcIzCDIfor8c05X2NTiTz2NjyXdoFBHKdAG8jMz7yW3NRXl862VVF+TtE/OpN4lZwwkcYbCXDUwULZkW93mzyCw38ffz7MrN0WhBKHYKvMNdwTO/U/qFDGztr0KBO+dkzjvSQUI6J8KtUTGOQfJ1x+bqB6YnsPmtoyiIMUzFeo+hb0+JeRpCnOLSJnbQEXF0epZnn9XXcmIXNtiynZCqwczJX2zAJEsKHe2+7+URFIb1M0HJU0oezqcdp6RPVeruW0tP9dQOkHSbxXqtYIDZZLyB+jKsrtA14pdCwzI5OYpStLzPQU6XaH+rVAPKTLgtducelcBJ62kBPZNBbpCoabXca6PFRlu885zsAKrSt0IJkvarMA1DpY7dcVlJZHUB3URSniMZcD9wDENnpcypYTqtoaya7fWixcl7ZwzYL+ixrLSf6ooCCwvALLoBF0pJtg9FeiHCvQrBTpbof6lUHcp1MdNujc2/D6HTDoUpbI8r4F+TFKkGuat/qwtX4/ntHWVQv1eYaFI8ipel7RGgWexlNzpMq4tiaQxKEEoh1gG3a4OleVlScsUeHiLyHemdmwUD0n6Ss75hyvQjQrrlg5mKlrmPU6Bhqk1TmpVwsnzKq4XDyhtG1tZUUnL6xpU0SYoCsobnHN9y6hYdr0DEy+JPB+mKu5JrPBkbavJd8ZM/bMkkuZA0jmSFErhfpY3/vYKrCLve8r3lK1uRxSwoyRxjUKtqWKV7q9SmOtgt5J8/aEJqzITJV2uUIcr0CbymyK5JN+arcJtCnVyHB9UVK3Mws0K9Y0C6syi8X0vkg/nP4mX2QiH3c7EnyxuDrZtG/nOZ//3kkiaC8U1jEMpPNUioWwq+7LxDBULDkRRQayiMRY/iducPx6MeZgj6UKFKQ9fcxsoX/+nINMpqhb4iiq4/UuhfqZA2ylwBi/mbYNbSCbNwERJpyrU8gWuZTH5OkVhTXaRQNHEtiXxMjFN0r4Fx91+Gbl4LiyJpDVQwih7hoVQ1pXdsU2KDKlFHuxCKubg5sd96FAkIhfFDElnKtTiBfqyuZpjrLVhiiJPzStjX5XvKdBmioy0iymtLvVTc93Hm4k7FVpLl7gkQFeC8WbheeWvtqFo2TvrRXRbSSSthSJCcaZ+HCK33nmTwsJRtXsXdIt/QarJEFfFdEUxJWbpVJco/n0FulZhjwUUBoo8LF+W9LDUq0IEpikyRv5AQSFbBPI1rAZifln5pWZd+EuBGJvqS8tVG2myoixuUkkkLYcSfij3WAhlKdlT2UnRW6PIBEaRC38tMR31YlQNLuIoilT98/+3d/5BcpRlHv+8s6GMSfglSUiQJBsNBJEci4clqFQWS0pAEIKgwnFmT9BS4byUqKDxRwKFZVn8iMf9YXmeJlJYiHoGEO60lJqkTgpBZVcwiSSQjXDRJEQT2JiA0/31j+ed2d6he6a7Zyb7I/2pemumdqa739nufvp9n/d5vo9CbT8IfRsr7JQN+c/PuCR+QYY4lJ2SPqZAJVV0bUaX+G5J707Zt25VEiOjt8lUBaVaZGthSDqNmogrTVFyFu9f1FwTpdq6ZDJ8ebwF9ynUzQr165TfL8uWe5uVvIi203z/0pTUGE8MyaQUblLYUAIgaST3SQX6fYbjvaRh4aNJyhas9uOU01ZkjtakkWy/hkckhSE5yCiSHLhd4SuW/w5TcsZwIOnTGZ5ypyi59k4S0WXhGzNcnLtlsn0LMt5EM2RxIv/uQ+rHpocjnt9K+k+FusrrsGT53dV2rgLdk/NXh7KSse9XoKdSbrNTyUW34trHGzyUygo1oBEqad2jfX8dcigiX7Bbio0nWNngAvuhkjVK4kYpn0pYho5js4bLFJyRa2xjSYyfUNC0AFNcO0JWX+eLsho7nQjQy8o+WYW5OxXqcwp0toJUOVVJ7WwF+g+FiY73TvE9ham1YWaocZLgf41cVVqtcZy050a7A63i//mrgKX7gXMI+QUa8Z134vgBJY6M2f5Z4HICfpHyePOAO+nirJTf7wdOAKam/H4SP0PcjViL2J1zH0cDp+KYDcwGZuGYBRwHHOvfT2+xn1XWAxsRmxAb/Ptn27Dfc3EswXEpjtdk2O4pYBUhn6XEnJzH3gRcneFauRDHtylxTMxne4C7ER8dvgVXOudW5OzamGDcG5MqMnGYpQBfQtxIOOLz+cCP6OLUuG2BOxDXE3Ig5fGuwHELJWa30Oc9wAbgTLKdiEeB/0X8mJDHWjh+Eq/FjE0WA/hn4I/A823uy1TMgLwXx4U4pmXcfgfwXgIexs7z53HcRCnTPvYCKwi5AxGk+P7hwO2UuCrhrD4BbEJchqMC+ybBlc65tZk6VdBZZEvHeyVpXYwf5VWKF6quslnSP2YYZk9VRTcpzL2UeKWfBr1BFd2cM6x+l2y6tlyBzlfQNDBurLdTVNG/+GjYdjiWn5BJSkyVqcRlOVd/k/T1Jhnh9a1XQcMyKt+J+EcCy7UsHK1jFdlKT82P0hPjJFuqwNaWYwhkDtBmgkvR1q186mq/0chC7llWIBqxU7Ya8hWFukKBTh4DRiKuLZBJJdyqUOulWK2adrBZyuRXCWUBffMz/JYpquiOBtfAXkn/NtI/UtY49o/EMWGmOVEU8aMAfApxa920Zx7wfbp4c8I+tgBXEvDLDMc9HbiBEpfgMv1jnwQ2I5Z0+HQ8BjyFeAbYgnga8TTwpw4e8zjgeGA+jhOBhThOwHEKMKXFfe8AfoD4KWII+Bmllv+D9yNuIGRDhm3eAtxNF90Jnz8M/ATxSZyOtHtujXOur8WujjkmpDGpIquzegcw7RHEeYTsqfvOF3DcmDCHDoGvIZYTsj/DcRcCn6HEB3FMytPxCC8BlxMyCViM4304ZrS4zzj+gN2cO5B/hZfrHNkADsdUYFqkHQFMwXF45G8vQ0v+pDScTsCv/fsFwCa66MqxnwAzSjcT8kSG7Y4AvkqJD+MSvTC3EfImHL04Ahjqgn91zq3O0c2C0UZSt/y0Z0hSb8y05zTFK+BX2ZqwXbN2vKyYeCvD9xc0shh63mXmicgahTpPgW7LKZa0T5bWkCY5sL5dqUA7G+z7cZlWS2Ra068ifmRiIC9lIEk3J0TN3tLECXqfQp2Y48I7WhUtz6AlWs/Lkh6SVe1rlLW6UVa4eryzXZaZvVCWEBenzt4KO2VVHdNGrkbbQsWLPEf58ivD+FeM9vVf0GYkXSy/2vOYwljnbI8a10WpyDz8eQLJJquijyhoOArKS79U0854vSq1HI/xyLWR8zJN2aOPk9gkk9ZMk4xX346R1bFupGOyXlbfuDoa8dGsxWrNREU27SlXL4DbE5S4bmgS7TokaXkKKcC4VpIVh/qWwsRVpay8INOGrd4o728wxvqmTJKxLOWaHuTlIYU6268uHaXkhLc/yqQaftKGTOlAJlPwHjUvHZq0SrNcQUPFtz0ybdkfFaORQxNFYlL2yopd119Ic1WpJV8lsUPSNUpX1yVptPI+Bbq/yVMvLQdkSv1JZU83aKRM4rsaGJ2PKNAVCvQlBTXpwDhuVVgrbH6SKokZzdGyEtNV0aaUvykPz8l0bObkPC9dMqGqPzU5zncVamkxGimQ5fbUfCnlhKnP+SkSwLZI+kDOp1/0BrtGgR7Oewel4G+y0hIXyuoPJ2mfBtII2cdJSnb81tcOSlKs2yLpFoVap/yaIY3YLXPKXuClBPKcg8NkhbyeaXKsQUkfU1jvG1k12tf0aDKhl4bTInuSrAIWg+VwrEQjlpEPA67FsZIShzfYVz9wPSE/jVlWzcJ8LGT/g5Q4saU95edR4EEfn7MQx+UJl8sOLPcGYCouMXanEzwOPIh4gJBfQl00UXomA1fhuIESxzf43gvANwmZgeOfh/8f24A+51w55+ELJhqyqc8Lks2D46Y+01WpaXM24klJV+d09tW3BTK19nsU5l4RmijskSmtfUhB08L1adpRquizKaYzf5UVZ4su9/pw+L7Rvm4Lxiiqm/qsT5j6zJWFTzdTNt8lEzqe1YYLH5k+66mq6DoFeqCNDtyxyn7ZKslNCnWW92W04/+4SBV9I8X5kywW5RMj/SJDMpHzCRUOX9AhZDk+tVWfssLYwLWZqujLal7f5WVZvsc7W/Sr1LdJquhM2YrDz1PeHGOZ/5fF81yvQG9TJZPyXBp/yGUKhk9qA16UrSgtUVCvKzyuNUc6SeEzaYJsGLsCS+ehjFiJKNf5RI4ArsFxXYJ+RZRtwLcJ+VabND6iTAJOBN6I4xQcb/TvT4BcoeadYgjTGNmI6EcMAL9C/KUDxzodWEqJf8JxdJPv7gJu92H11/kweM86zC8y2IEuTggKY5KSOKOyCnFvnVGZDPR5R968JvsMMdGj7yJ+6JPVOsVhwBygG0c3lnjXjSXhTfP5NlOg9po1Ce8A8CJmJIb89tFcn+2IrVQTDO2m7SRzgA/guDqlA/sZ4BZCtgPLRhqRAWBZ4VxtTmFMMiKpFzMqiwEGMeGcNXVGpQu4FMdySixKsd+XMMGje7yB2tfOTufAMWxUooZmMrCfkYbjRfKvorSTBcAlOC6hxFtSbvN/wDcIKQErKEUzf7cBK4qkvPQUxiQnaY0KwNl+GfFyHJNT7PsAttz5oJ9OPd22Xk8sJgFnAOdS4iIva5CW/0bchViEYxmOiBNkHWZEym3t7CFAYUxaxBuVZcBFYEZlNWINYrDOsBwOXIajj1JqDVmA54B13rCUEVva0vPxyUnAOTjOwfEOPz1Ly2+BuwjZCpyPo2/k5b8GMyKD7evtoUVhTNqELL18BV6QCcyvstpPW+p1VOYCH6LEEhz/kPFY24H1iHW+bWyl42OYV2PO0zNxnInjrThmZtzHduBOxF1eV6Qv4g8J4cUS3Aascs7Vn6KCjBTGpM14o9LnW80Hu9ory9c7bMHElC7FcSkl8iR17MKMyyPesGz0zs7WYnAPLjOARTgW+ddTcfRALnGp3wH3Iu4jZBaOi32LTGUGMAOyug1dL/AUxqSD+ClQn+ASZ7Mc9gCrCVkD9Mfc7vOwqdB5fhifl/3A7xkuN7ENU1PbhvgDUMm95/zMxNIE5uN4nX99PXAyjmNb3Pd64D5Cvo84Ld6AgE1lVhf+kM5QGJODgA9yuhjzrdSqbQxCbXm53r8CJn/4DhzvwnEBjrlt6k+I6b5uBZ5HPA++2ftdwF7EXyG2xXE0w7V4ZmN+jZnATP86C1uebhdDwAOI+xH/gzgr2YDcC6wF1hZTmc5SGJODjJ8GLcOMS20a1F9zsJqzNe6qX4gZlzNwvN0/3Q8VDmCJh494AemfIy5KNiADWOJmYUAOIoUxGUW8YbnYt8XRz9IYl2OBXm9YTveO3FYV38cKvwEeRzyK+JVX1F+MowdHL0SDyqqsY3gEMnhQO1sAFMZkzBCZCvUCS7AI/RpV47IWMy5JzAbegGMhJhtwMjAHx0md6ngL7Mamek8hNiCeBH6H2IxF6i4GejDD0VN3qYbwbAkewgxIuRiBjD6FMRmjeOdttS2u/7zsc1oGcfR7B2uc3yXKa7Al6bk45gDH4ZgOHANMx3GMf9+OEhVbMd/LTsRO//45xKDv5yDU0geOwmogd2OGo9e/j+FeoIwZj/42dLOgjRTGZJwgE3DqpfqwJj71p9/fqP0M37QDCdOkZhyJTZteHXmdDOxjOJR+CBMMakY3jnlAj/dv9GBGJGa6UmXA/4x+CuMxLiiMyTjFT4t6GTYu9oBvQDXTuRzzWX+MwYkzQtVRRD09r3SC1jpVP0WJYQBqNrBcLN2OTwpjMsHwTt1uzMhEX5slMXeaASzMpuxf+4HBwlk6cfg7kS1fp9DvzRAAAAAASUVORK5CYII="

var menued=false;

var 窗口N;

var 打开次数=0;

function 主要按钮() {
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
ctx.runOnUiThread(new java.lang.Runnable({
run: function() {
try {
 var 坐标x = 0,
坐标y = ctx.getWindowManager().getDefaultDisplay().getHeight() / 1.5,
坐标x1, 坐标y1, 坐标x2, 坐标y2;
窗口N = new android.widget.PopupWindow();
var layout = new android.widget.RelativeLayout(ctx),
按钮 = new android.widget.ImageView(ctx);
var 群 = android.util.Base64.decode(logo, 0);

按钮.setImageBitmap(new android.graphics.BitmapFactory.decodeByteArray(群, 0, 群.length));
按钮.setLayoutParams(new android.widget.LinearLayout.LayoutParams(ctx.getWindowManager().getDefaultDisplay().getWidth()/1,ctx.getWindowManager().getDefaultDisplay().getHeight()/1));
按钮.setOnClickListener(new android.view.View.OnClickListener({
onClick: function(v) {
if (menued == false) {
 UIRotate(按钮, 0, 360, 50, 50, 360);
主菜单();
if(打开次数==0){
 打开次数++;
 水印();
}
menued = true;
}
}
}));

按钮.setOnTouchListener(new android.view.View.OnTouchListener({
onTouch: function(v, e) {
switch (e.getAction()) {
case 0:
坐标x1 = e.getX();
坐标y1 = e.getY();
break;
case 2:
坐标x2 = parseInt(e.getX() - 坐标x1) * -3 / 10;
坐标y2 = parseInt(e.getY() - 坐标y1) * -3 / 10;
坐标x = 坐标x + 坐标x2;
坐标y = 坐标y + 坐标y2;
窗口N.update(坐标x, 坐标y, -1, -1);
break;
}
return false;
}
}));
UIFadein(layout,0,500,2100);
layout.addView(按钮);
窗口N.setContentView(layout);
窗口N.setWidth(dip2px(ctx, 40));
窗口N.setHeight(dip2px(ctx, 40));
窗口N.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
窗口N.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.RIGHT, 坐标x, 坐标y);
} catch (err) {
 ERR(err)
}
}
}));
}

function 水印(){
 Ui(function(){try{
 var layout=new 线性布局(ctx);
 layout.setOrientation(1);
 var 小标题="§r§3Your HackV5.0.0§r\n作者:§r§6Mr.XiaoHan§r\n加密:§r§9沐白";
 
 var 功能=new android.widget.TextView(ctx);
功能.setText(FontColor(小标题));
功能.setTextSize(20);
功能.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 
 }}));
 layout.addView(功能);
 UIFadein(layout,0,500,2100);

 
 窗口显示3(layout,false,false,"RT",0,0);
 }catch(err){ERR(err)}})
}

var 按钮个数=0;
var 是否同意=false;
var 阅读协议=false;
function 公告FU(){
 Ui(function(){try{
 主标题="公告";
 var layout=new 线性布局(ctx);
 layout.setOrientation(1);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("－|"+主标题+"|－");
功能.setTextSize(29);
功能.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 
 }}));
 layout.addView(功能);
 
 var 公告=FontColor(
 "JS版本:§r§6"+"5.0.0§r\n"+
 "JS名稱:§r§6"+"Your Hack§r\n"+
 "JS作者:§r§6"+"Mr.XiaoHan§r\n"+
 "§r§2本JS完全免費\n"+
 " §r§4－|更新公告|－§r\n"+
 "1.新增\"衝\"按鈕\n"+
 "2.新增\"綁背繞\"按鈕\n"+
 "3.新增噴氣背包(2种)\n"+
 "4.為防止倒賣新增閱讀協議(複選框)和水印文本\n"+
 "5.新增\"穿\"按鈕\n"+
 " §r§4－|用戶協議|－§r\n"+
 "1.禁止倒賣本js\n"+
 "2.禁止解密本js\n"+
 "3.務必不要使用魔改版,可能含有病毒\n"+
 "4.禁止在相關平台騷擾本js作者\n"+
 "5.本js上傳群需要得到授權\n"+
 "6.如有違反,掛狗處理!"+
 "§r§c祝您玩的愉快!§r"
 );
 
 var 功能=new android.widget.TextView(ctx);
功能.setText(公告);
功能.setGravity(android.view.Gravity.LEFT|android.view.Gravity.TOP);
功能.setTextSize(23);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 
 }}));
 layout.addView(功能);
 
 var 阅读协议=new 复选框(ctx);
 阅读协议.setText("我已閱讀併同意用戶協議");
 阅读协议.setTextColor(android.graphics.Color.parseColor("#ffffab00"));
 阅读协议.setChecked(是否同意);
 阅读协议.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener(){onCheckedChanged:function(v,isChecked){
 是否同意 = isChecked;
 if(是否同意){
 阅读协议=true;
 }
 else{
 阅读协议=false;
 }
 }});
 layout.addView(阅读协议);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("Close");
功能.setTextSize(29);
功能.setBackground(bg);
功能.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
功能.setTextColor(android.graphics.Color.parseColor("#ffff0034"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(阅读协议==true){
 menu.dismiss();
 计时(function(){
 挂狗墙();
 },100);
 }
 else{
 menu2.dismiss();
 顶部提示("§r§l§4請先勾選\"我已閱讀併同意用戶協議\"!");
 }
 }}));
 layout.addView(功能);
 
 窗口显示(layout,false,true,"CC",0,0);
 
 }catch(err){ERR(err)}
 })
 }

function 挂狗墙(){
 Ui(function(){try{
 主标题="掛狗墻";
 var layout=new 线性布局(ctx);
 layout.setOrientation(1);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("－|"+主标题+"|－");
功能.setTextSize(29);
功能.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 
 }}));
 layout.addView(功能);
 
 var SM="倒賣狗QQ:§r§43150727335§r\n倒賣狗QQ2:§r§4783707637§r\n授權狗QQ3:§r§41808743964§r";
 
 var 功能=new android.widget.TextView(ctx);
功能.setText(FontColor(SM));
功能.setGravity(android.view.Gravity.LEFT|android.view.Gravity.TOP);
功能.setTextSize(23);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 
 }}));
 layout.addView(功能);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("Close");
功能.setTextSize(29);
功能.setBackground(bg);
功能.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
功能.setTextColor(android.graphics.Color.parseColor("#ffff0034"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 menu3.dismiss();
 if(按钮个数==0){
 主标题="Your Hack";
 menu2.dismiss();
 顶部提示("Your Hack·點擊右側按鈕打開菜單");
 主要按钮();
 }
 
 }}));
 layout.addView(功能);

 
 窗口显示3(layout,false,true,"CC",0,0);
 }catch(err){ERR(err)}});
}
验证();

var 百度="https://m.baidu.com/?from=1014243b";
var 听歌="http://m.kugou.com/";
var 直播="https://m.huya.com/";
var 爱奇艺="https://m.iqiyi.com/";
var 矿坑="https://m.iqiyi.com/v_19rxkihqyk.html?vfrm=2-3-3-1";
var 温柔叙="https://chushou.tv/room/1265604.htm";
function 浏览器(网址){Ui(function(){try{
var layout=new android.widget.LinearLayout(ctx);
var menu=new android.widget.PopupWindow(layout);
menu.setFocusable(true);
layout.setOrientation(1);
var layout = new android.widget.LinearLayout(ctx); 
var webview = new android.webkit.WebView(ctx);
webview.getSettings().setJavaScriptEnabled(true);
webview.loadUrl(网址);//
var Web=new android.webkit.WebViewClient();
webview.setWebViewClient(Web);
layout.addView(webview);
var mlayout=makeMenu(ctx,layout)
menu.setContentView(mlayout)
menu.setWidth(1000)
menu.setHeight(1200)
menu.setAnimationStyle(android.R.style.Animation_Dialog);
menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
menu.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT | android.view.Gravity.TOP,0,0);
 }catch(err){ERR(err)}})
}


var catColor=android.graphics.Color.parseColor("#ff00ffd7");
var mod=1;
var 显示位置="靠左";
var 飞行mod="模式一";
var 顶部提示次数=0;
var 变速开启=false;
var 回=null;
var Px,Py,Pz;
var 坐标显示=false;
/*——移动按键分割——*/
var 飞按钮显示=false;
var 飞按键;
function 飞按钮(){
 飞按键=移动按键("飛",H() *0.1,H() *0.1,function(){
 if(飞行mod=="模式一" ){Entity.setVelY(getPlayerEnt(), 1);Player.setFlying(true)}else{Entity.setPosition(getPlayerEnt(), Player.getX(), Player.getZ()+2, Player.getX());Player.setFlying(true)}
 },false);
}
var 踏按钮显示=false;
var 踏按键;
function 踏按钮(){
 踏按键=移动按键("踏",H() *0.1,H() *0.1,function(){
 Entity.setVelY(getPlayerEnt(), 0.6);
},false);
}
var 上按钮显示=false;
var 上按键,下按键;
function 上按钮(){
 上按键=移动按键("上",H() *0.1,H() *0.1,function(){
 Entity.setPosition(getPlayerEnt(), Player.getX(), Player.getY()+5, Player.getZ());Player.setFlying(true);
 },false);
}
function 下按钮(){
 下按键=移动按键("下",H() *0.1,H() *0.1,function(){
 Entity.setPosition(getPlayerEnt(), Player.getX(), Player.getY()-5, Player.getZ());Player.setFlying(true);
},false);
}
/*——移动按键分割——*/
var MENU;
var Px2,Py2,Pz2;
var MeNu=false;
var 暗杀显示=false;
function 显示坐标(){
var Thread=new java.lang.Thread(new java.lang.Runnable({run:function(){
 while(true){
 if(坐标显示==true){
 Px2=Player.getX();
 Py2=Player.getY();
 Pz2=Player.getZ();
 }
 Thread.sleep(200);
 }
 
 }}));
 Thread.start();
 
 Ui(function(){
 var layout=new 线性布局(ctx);
 MENU=new Class.PopupWindow(layout,dip2px(ctx,75),dip2px(ctx,30));
 var layouT=new 线性布局(ctx);
 layouT.setOrientation(1);
 
 var layout1=new 线性布局(ctx);
 layout1.setOrientation(1);
 layouT.addView(layout1);
 
 var 功能1=new android.widget.TextView(ctx);
功能1.setText("x:"+Px2+"\ny:"+Py2+"\nz:"+Pz2);
功能1.setGravity(android.view.Gravity.CENTER | android.view.Gravity.CENTER);
功能1.setTextSize(20);
功能1.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能1.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能1.setMarqueeRepeatLimit(-1);
功能1.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能1.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 
 }}));
 layout1.addView(功能1);
 
 var Layout=new 线性布局(ctx); 
 Layout.setOrientation(1); 
 Layout.addView(layouT); 
 MENU.setFocusable(false);
 MENU.setTouchable(false); 
 var mlayout=makeMenu(ctx,Layout);
 MENU.setContentView(mlayout);
 MENU.setWidth(dip2px(ctx,220));
 MENU.setHeight(dip2px(ctx,320));
 MENU.setAnimationStyle(android.R.style.Animation_Dialog);
 MENU.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0))); 
 MENU.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.LEFT|android.view.Gravity.TOP,0,0);
 });
 }
function NewText(text,gravity,size,color){
var _T1 = new android.widget.TextView(ctx);
if(gravity=="LT"){
_T1.setGravity(android.view.Gravity.LEFT|android.view.Gravity.TOP);
}else if(gravity=="LC"){
_T1.setGravity(android.view.Gravity.LEFT|android.view.Gravity.CENTER);
}else if(gravity=="LB"){
_T1.setGravity(android.view.Gravity.LEFT|android.view.Gravity.BOTTOM);
}else if(gravity=="CT"){
_T1.setGravity(android.view.Gravity.CENTER|android.view.Gravity.TOP);
}else if(gravity=="CC"){
_T1.setGravity(android.view.Gravity.CENTER|android.view.Gravity.CENTER);
}else if(gravity=="CB"){
_T1.setGravity(android.view.Gravity.CENTER|android.view.Gravity.BOTTOM);
}else if(gravity=="RT"){
_T1.setGravity(android.view.Gravity.RIGHT|android.view.Gravity.TOP);
}else if(gravity=="RC"){
_T1.setGravity(android.view.Gravity.RIGHT|android.view.Gravity.CENTER);
}else if(gravity=="RB"){
_T1.setGravity(android.view.Gravity.RIGHT|android.view.Gravity.BOTTOM);
};
_T1.setText(text);
if(size!=null){
_T1.setTextSize(size);
};
if(color!=null){
_T1.setTextColor(android.graphics.Color.parseColor(color));
};
return _T1;
};

/*————*/
var 搭按钮显示=false;
var 搭按键;
var 脚下方块=false;
function 搭按钮(){
 搭按键=移动按键("搭",H() *0.1,H() *0.1,function(){
 if(脚下方块==false){脚下方块=true}else{脚下方块=false}
 },true);
 
}
var 破按钮显示=false;
var 破按键;
var 脚下消失=false;
function 破按钮(){
 破按键=移动按键("破",H() *0.1,H() *0.1,function(){
 if(脚下消失==false){脚下消失=true}else{脚下消失=false}
 },true);
}
/*————*/
/*——*/
var zimiao,bang,bei,rao,rao2,回弹,喵=false,lang=java.lang,mode=false;
var shield=["闪电侠","超级跳跃","末影使者","点我使用展示功能","跳跃信标","entity"];
var 绑背绕按钮;
var 绑背绕按钮显示=false;
function 绑背绕(){
 var command;
 var 背按钮=NewView("LL",W()/19,H()*0.1,"CC",0,2,null,null),绑按钮=NewView("LL",W()/19,H()*0.1,"CC",0,2,null,null),绕按钮=NewView("LL",W()/19,H()*0.1,"CC",0,2,null,null)
 var ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
 var view=android.view;
var 坐标x=W()-W()/2.744,坐标y=H()/3*2,坐标x1,坐标y1,坐标x2,坐标y2;
绑背绕按钮=new android.widget.PopupWindow();
ctx.runOnUiThread(new java.lang.Runnable({run:function(){try{
var 绑按钮1=NewText("綁","CC",14,"#000000"),背按钮1=NewText("背","CC",14,"#000000"),绕按钮1=NewText("繞","CC",14,"#000000");
绑按钮.addView(绑按钮1);背按钮.addView(背按钮1);绕按钮.addView(绕按钮1);

var layout=new android.widget.RelativeLayout(ctx),界面=NewView("LL",-2,H()*0.1,"CC",0,2,"#ffffff",15);
界面.addView(绑按钮);
界面.addView(背按钮);
界面.addView(绕按钮);
 var 绑杀=false;
 var 背杀=false;
 var 绕杀 =false;

 绑按钮.setOnClickListener(new view.View.OnClickListener({onClick:function(){
 eval("绑();绕按钮.setBackgroundDrawable(roundBG('#ffffff',[0,15,15,0]));背按钮.setBackgroundDrawable(roundBG('#ffffff',0));");
 if(背杀){
 背杀=false
 }
 if(绕杀){
 绕杀=false
 }

 if(绑杀){
 绑按钮.setBackgroundDrawable(roundBG("#ffffff",[15,0,0,15]));
 绑杀=false;
 }
 else{
绑按钮.setBackgroundDrawable(roundRect([hexColor("#DAFFCE"),hexColor("#BBFFEA")],[15,0,0,15]))
绑杀=true;
}
}}));


 背按钮.setOnClickListener(new view.View.OnClickListener({onClick:function(){
 eval("背();绑按钮.setBackgroundDrawable(roundBG('#ffffff',[15,0,0,15]));绕按钮.setBackgroundDrawable(roundBG('#ffffff',[0,15,15,0]));");
 if(绕杀){
 绕杀=false
 }
 if(绑杀){
 绑杀=false
 }
 
 if(背杀){
 背按钮.setBackgroundDrawable(roundBG("#ffffff",0));
 背杀=false;
 }
 else{
背按钮.setBackgroundDrawable(roundRect([hexColor("#DAFFCE"),hexColor("#BBFFEA")],0))
背杀=true;
}
}}));


 绕按钮.setOnClickListener(new view.View.OnClickListener({onClick:function(){
 eval("绕();绑按钮.setBackgroundDrawable(roundBG('#ffffff',[15,0,0,15]));背按钮.setBackgroundDrawable(roundBG('#ffffff',0));");
 if(绑杀){
 绑杀=false
 }
 if(背杀){
 背杀=false
 }
 
 if(绕杀){
 绕按钮.setBackgroundDrawable(roundBG("#ffffff",[0,15,15,0]));
 绕杀=false;
 }
 else{
绕按钮.setBackgroundDrawable(roundRect([hexColor("#DAFFCE"),hexColor("#BBFFEA")],[0,15,15,0]))
绕杀=true;
}
}}));
//界面.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(50,0,25,15)));
var 背景=new android.graphics.drawable.GradientDrawable();
背景.setCornerRadius(15);
背景.setColor(android.graphics.Color.WHITE); 
背景.setAlpha(255);
界面.setBackground(背景);

绑按钮.setOnTouchListener(new android.view.View.OnTouchListener({onTouch:function(v,e){ 
 switch(e.getAction()){
case 0:
坐标x1=e.getX();
坐标y1=e.getY();
break;
case 2:
坐标x2=parseInt(e.getX()-坐标x1)*-1/10;坐标y2=parseInt(e.getY()-坐标y1)*-1/10;
坐标x=坐标x+坐标x2;
坐标y=坐标y+坐标y2;
绑背绕按钮.update(坐标x,坐标y,-1,-1);
break;}
return false;
}}));
layout.addView(界面);
绑背绕按钮.setContentView(layout);
绑背绕按钮.setWidth(-2);
绑背绕按钮.setHeight(H()*0.1);
绑背绕按钮.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
绑背绕按钮.showAtLocation(ctx.getWindow().getDecorView(),android.view.Gravity.BOTTOM|android.view.Gravity.RIGHT,坐标x,坐标y);
}catch(err){print(err+"\n"+err.lineNumber);}
}}));
 }
function 绑(){
if(rao2){
 rao2=false;
 喵=false;
 }
 else{
 bang=false;
 rao2=true; 
 }
 } 

function 背(){
if(bang){
 bang=false;
 喵=false;
 }
 else{
 rao=false;
 bang=true; 
 }
 } 

function 绕(){
if(rao){
 rao=false;
 喵=false;
 }
 else{
 bang=false;
 rao=true; 
 }
 } 

function 穿墙(实体,x,y,z){
var a=getYaw()*Math.PI/180;
var b=getPitch()*Math.PI/180;
xx=-Math.sin(a)*Math.cos(b);
yy=-Math.sin(b);
zz=Math.cos(a)*Math.cos(b);
 Entity.setPosition(实体, xx*x, yy*y, zz*z);
}
/*——移动按键——*/
var 走按钮显示=false;
var 走按键;
var 脚下虚空=false;
var 悬浮窗=0;
function 走按钮(){
 走按键=移动按键("走",H() *0.1,H() *0.1,function(){
 if(脚下虚空==true){脚下虚空=false}else{脚下虚空=true}
 },true);
}
/*——*/
var 长臂=false;
var 长臂开启=false;
var 杀戮开启=false;

var 冲按钮显示=false;
var 冲按键;
function 冲按钮(){
 冲按键=移动按键("衝",H() *0.1,H() *0.1,function(){
 冲刺(getPlayerEnt(),3,2,3);
 },false);
}

var 退按钮显示=false;
var 退按键;
function 退按钮(){
 退按键=移动按键("退",H() *0.1,H() *0.1,function(){
 后撤(getPlayerEnt(),3,2,3);
 },false);
}

var 跳按钮显示=false;
var 跳按键;
function 跳按钮(){
 跳按键=移动按键("跳",H() *0.1,H() *0.1,function(){
 Entity.setVelY(getPlayerEnt(), 1);
 },false);
}

var 缓按钮显示=false;
var 缓按键;
var 缓降=false;
function 缓按钮(){
 缓按键=移动按键("緩",H() *0.1,H() *0.1,function(){
 if(缓降==false){
 缓降=true;
 load("§r§b緩降開啟");
 }else{
 缓降=false;
 load("§r§b緩降關閉");
 }
 },true);
}

var 穿按钮显示=false;
var 穿按键;
function 穿按钮(){
 穿按键=移动按键("穿",H() *0.1,H() *0.1,function(){
 穿墙(getPlayerEnt(),3,2,3);
 },false);
}

var 喷按钮显示=false;
var 喷按键;
var 喷气背包=false;
function 喷按钮(){
 喷按键=移动按键("噴",H() *0.1,H() *0.1,function(){
 if(喷气背包==false){
 喷气背包=true;
 menu2.dismiss();
 顶部提示("§r§b噴氣背包開啟");
 }
 else{
 喷气背包=false;
 menu2.dismiss();
 顶部提示("§r§b噴氣背包關閉");
 }
 
 },true);
}


var 喷按钮显示2=false;
var 喷按键2;
var 喷气背包2=false;
function 喷按钮2(){
 喷按键2=移动按键("ο",H() *0.1,H() *0.1,function(){
 if(喷气背包2==false){
 喷气背包2=true;
 menu2.dismiss();
 顶部提示("§r§b噴氣背包2關閉");
 }
 else{
 喷气背包2=false;
 menu2.dismiss();
 顶部提示("§r§b噴氣背包2關閉");
 }
 
 },true);
}
function 主菜单(){
 Ui(function(){try{
 var layout=new 线性布局(ctx);
 layout.setOrientation(1);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("＜|"+主标题+"|＞");
功能.setTextSize(29);
功能.setGravity(android.view.Gravity.CENTER | android.view.Gravity.CENTER);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f3ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 menu.dismiss();
 menued=false;
 }}));
 layout.addView(功能);
 
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("___________________________________________")
功能.setTextSize(9);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){

}}));
layout.addView(功能);
 
 var 功能1=new android.widget.TextView(ctx);
功能1.setText("戰鬥 ");
功能1.setGravity(android.view.Gravity.LEFT | android.view.Gravity.TOP);
功能1.setTextSize(18);
功能1.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能1.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能1.setMarqueeRepeatLimit(-1);
功能1.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能1.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 menu.dismiss();
 主标题="戰鬥";
 mod=1;
 主菜单();
 }}));
 layout.addView(功能1);
 
 
 
 var 功能2=new android.widget.TextView(ctx);
功能2.setText(" 動作 ");
功能2.setTextSize(18);
功能2.setGravity(android.view.Gravity.CENTER | android.view.Gravity.CENTER);
功能2.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能2.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能2.setMarqueeRepeatLimit(-1);
功能2.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能2.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 menu.dismiss();
 主标题="動作";
 mod=2;
 主菜单();
 }}));
 layout.addView(功能2);
 
 
 var 功能3=new android.widget.TextView(ctx);
功能3.setText(" 其他");
功能3.setTextSize(18);
功能3.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.TOP);
功能3.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能3.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能3.setMarqueeRepeatLimit(-1);
功能3.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能3.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 menu.dismiss();
 主标题="其它";
 mod=3;
 主菜单();
 }}));
 layout.addView(功能3);
 
 
 var 功能4=new android.widget.TextView(ctx);
功能4.setText("上網 ");
功能4.setGravity(android.view.Gravity.CENTER | android.view.Gravity.CENTER);
功能4.setTextSize(18);
功能4.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能4.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能4.setMarqueeRepeatLimit(-1);
功能4.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能4.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 menu.dismiss();
 主标题="上網";
 mod=4;
 主菜单();
 }}));
 layout.addView(功能4);
 
 
 
 var 功能5=new android.widget.TextView(ctx);
功能5.setText("設置 ");
功能5.setGravity(android.view.Gravity.LEFT | android.view.Gravity.TOP);
功能5.setTextSize(18);
功能5.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能5.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能5.setMarqueeRepeatLimit(-1);
功能5.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能5.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 menu.dismiss();
 主标题="設置";
 mod=5;
 主菜单();
 }}));
 layout.addView(功能5);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("___________________________________________")
功能.setTextSize(9);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){

}}));
layout.addView(功能);
 
 if(mod==1){
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("穩定飛鷹|切換模式");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 飞行mod=="模式一"?飞行mod="模式二":飞行mod="模式一";
 load("§r§b當前飛鷹模式為:"+飞行mod);
 if(顶部提示次数==0){
 顶部提示次数++;
 顶部提示("§r§6模式一為設置Y坐標飛行,§r\n§r§b模式二為設置Y軸速度飛行§r");
 }
 
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("穩定飛行");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(飞按钮显示==false){
 飞按钮显示=true;
 飞按钮();
 }
 else{
 飞按钮显示=false;
 飞按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("2倍·變速");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(变速开启==false){
 变速开启=true;
 ModPE.setGameSpeed(40);
 load("§r§b變速·開啟");
 }
 else{
 变速开启=false;
 ModPE.setGameSpeed(20);
 load("§r§b變速·關閉");
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("|方框-透視|");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 load("§r§b暫未添加-2333");
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("切換|聯/租");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(mode==false){
 mode=true;
 load("§r§b切換為聯/租模式");
 }
 else{
 mode=false;
 load("§r§b已關閉聯/租模式")
 }
 
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("攻擊|增強");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(绑背绕按钮显示==false){
 绑背绕按钮显示=true;
 绑背绕();
 }
 else{
 绑背绕按钮显示=false;
 绑背绕按钮.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("長臂猿");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(长臂开启==false){
 长臂开启=true;
 长臂猿();
 }
 else{
 长臂开启=false;
 关闭长臂();
 }
 
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("偽·殺戮-光環");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(杀戮开启==false){
 杀戮开启=true;
 长臂=true;
 load("§r§9已開啟偽殺戮");
 自动长臂();
 }
 else{
 长臂=false;
 load("§r§9已關閉偽殺戮");
 杀戮开启=false;
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("血量·歸零");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 Player.setHealth(0);
 load("§r§b秘數·血量歸零§r");
 }}));
 layout.addView(的);
 }
 
 if(mod==2){
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("噴氣背包");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(喷按钮显示==false){
 喷按钮显示=true;
 喷按钮();
 }
 else{
 喷按钮显示=false;
 喷按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("噴氣---背包");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(喷按钮显示2==false){
 喷按钮显示2=true;
 喷按钮2();
 }
 else{
 喷按钮显示2=false;
 喷按键2.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("踏·空");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(踏按钮显示==false){
 踏按钮显示=true;
 踏按钮();
 }
 else{
 踏按钮显示=false;
 踏按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("高~跳");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(跳按钮显示==false){
 跳按钮显示=true;
 跳按钮();
 }
 else{
 跳按钮显示=false;
 跳按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("|上－下|");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(上按钮显示==false){
 上按钮显示=true;
 上按钮();
 下按钮();
 }
 else{
 上按钮显示=false;
 上按键.dismiss();
 下按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("緩·降");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(缓按钮显示==false){
 缓按钮显示=true;
 缓按钮();
 }
 else{
 缓按钮显示=false;
 缓按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("自動·搭路");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(搭按钮显示==false){
 搭按钮显示=true;
 搭按钮();
 }
 else{
 搭按钮显示=false;
 搭按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("|·破·|");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(破按钮显示==false){
 破按钮显示=true;
 破按钮();
 }
 else{
 破按钮显示=false;
 破按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("穿·墻");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(穿按钮显示==false){
 穿按钮显示=true;
 穿按钮();
 }
 else{
 穿按钮显示=false;
 穿按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("|自走-虛空|");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(走按钮显示==false){
 走按钮显示=true;
 走按钮();
 }
 else{
 走按钮显示=false;
 走按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("|衝－刺|");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(冲按钮显示==false){
 冲按钮显示=true;
 冲按钮();
 }
 else{
 冲按钮显示=false;
 冲按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("|後－退|");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(退按钮显示==false){
 退按钮显示=true;
 退按钮();
 }
 else{
 退按钮显示=false;
 退按键.dismiss();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("回·家");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnLongClickListener(new android.view.View.OnLongClickListener() {
onLongClick: function(v,t){
 回=true;
 Px=Player.getX();
 Py=Player.getY();
 Pz=Player.getZ();
 var vibrator = ctx.getSystemService(android.content.Context.VIBRATOR_SERVICE);
 vibrator.vibrate(100);
 load("§r§b設置·成功");
 return true;
 }});
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(回==null){
 load("§r§b您還沒有設置家,\n請先長按\"回·家\"按鈕設置家");
 }
 else{
 Entity.setPosition(getPlayerEnt(), Px, Py, Pz);
 }
 
 }}));
 layout.addView(的);
 }
 
 if(mod==3){
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("彩·蛋");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 load("§r§4"+Server.getAllPlayerNames()+":§r§cYour Hack作者NB!§r");
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("開|關·坐標顯示");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(坐标显示==false){
 显示坐标();
 坐标显示=true;
 load("§r§9已開啟坐標顯示");
 }
 else{
 坐标显示=false;
 MENU.dismiss();
 load("§r§9已關閉坐標顯示");
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("坐標·傳送");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 坐标传送();
 }}));
 layout.addView(的);
 
var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("JS解密");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 load("§c還沒有開發出來哦§r");
 }}));
 layout.addView(的);
 }
 
 if(mod==4){
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("科學查閱");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 浏览器(百度);
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("科學聽歌");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 浏览器(听歌);
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("科學直播");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 浏览器(直播);
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("科學追劇");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 浏览器(爱奇艺);
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("作者喜歡");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 浏览器(矿坑);
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("作者喜歡2");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 浏览器(温柔徐);
 }}));
 layout.addView(的);
 }
 
 if(mod==5){
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("加載JS");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 File_Select();
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("關於·-·作者");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 对话框(null,"關於作者","作者Mr.XiaoHan\n加密by——沫白\n此JS版本:5.0.0\n作者官方Q群快加!\n點擊複製QQ可以複製我的QQ,點擊複製Q群可以複製Your Hack官方群(查看最新更新哦!)","複製QQ",function(){复制("2632588830")},true,"複製Q群",function(){複製("1013882618")},true,"關閉",function(){});
 
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("切換懸浮窗");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnLongClickListener(new android.view.View.OnLongClickListener() {
onLongClick: function(v,t){
 var vibrator = ctx.getSystemService(android.content.Context.VIBRATOR_SERVICE);
 vibrator.vibrate(100);
 load("§r§b重置·成功");
 窗口N.dismiss();
 悬浮窗++;
 logo="iVBORw0KGgoAAAANSUhEUgAAARMAAAETCAYAAAAVqeK4AAAABHNCSVQICAgIfAhkiAAAIABJREFUeJzsnXeYHVX5xz9zN4EQIIQqndCkhBJA6SU0GyBNQEEhlB+CioACgiIERRBRmgpSlKAgvRcDUkIHaSH0Egid0BJIT2bm+/tj5u7OnjlnZm7bu5vM93nm2b33zpw5M3POd973PW/xKDFPQNIwYJH44zBgcPz/cMvuQ+LNhgnxZmKM5buxwGTP8+4v1MkSfRpeuztQonmICWMlIrIYEm9J4mgnJhORy4R4K4lmLkNJJn0QkgYD6xNJFcPoIo++iiTRjAXu9zxvbFt7VKJmlGTSBxBLHNvQRRzD2tujHsFkItVpLDCmlGB6P0oy6YWQNISIPHYjkj56g5rSGzCmupXk0vtQkkkvgaRdiYhjN7qrLCFQaUOX+gLGxNvNpVrUfpRk0ibEdo9dichjtzZ3Z27ABOAm4LKSWNqDkkx6GLEEshswIvG1D/RrS4fmTowFRhFJLBPa25V5ByWZ9AASBLIbXfaPUn3pGZTE0kMoyaRFiNWYI4kkkCHx1yWBtBc3xdvNnudNbndn5jaUZNJkSBoOHEB3NabXwgdmA3Piv7MTn+ekfhNzABlteEQ62gA85gPmB5Yncrft6IFrqAOfA5cC55bSSvNQkkkTkDCmHkWXD4joJfd3NvAa8BLi5c6/0f/TW3zuhYClgGWA5fBYBVgZj5XjvysB/VvcBwuSz2YUEamURtsG0SsGe19FQpU5il7gCzIVeImILKIt+n88ELS3a050AF8G1sVjHTzWjf9fhR4fnGOAUzzPG9Ozp517UJJJHegNJDIVeBp4EnVur7WjIy3CIGATPDYDNsVjUzwW7ZlTTwBGep53Wc+cbu5BSSY1wEIiPWZQnQ7ch7gD8QDiBdK2i7kdawHD8dgRjx3wWLi1p5tAlwpUGmsLoCSTAohJ5Gy6lnZ7hETGA3fEBHIvYnarT9iH0AF8FdgRj29QYTNaNpgnA+dQkkouSjLJQDskkVeBaxDXEPJcK080l+FLwK547IHH9njN9ACsGmsnUKo/mSjJxAFJBwAjiXxEWkoir9NFIM+26iQx+gMrAkPwGEK0hLsQHgOBBeMt+r/ru+TfgdgHzSTgA+BDxAfALOBDYCJiIvA+4k3gPVqvni0CfBuP7+HxdbxmP7gxwNHl6k8aJZkYiP1EzqbFYf5TgKsR/yDk0Ra0vySwDh5D479rxcuxy9Fer7mZwBvA+Nhg/BJiLOI5IgJqNpYB9sPj/6jw5eY2PYqIVErVJ0ZJJjHisP+qXaRleBD4ByHXoKb5ePQDNga2w2M4HhvgsViT2u4pBMArwFjEU4iHEU8ROdU1CxsCB1FhBB4LNqfJL4CzPM87pTnN9W2UZAJIOpkW2kWmAKMQfyZsyvKtRzQxtsVjOzy2bt7k6FWYATyGeAi4H/EQaor0MggYgceRVFilsaaS9pSjPc+7qeHO9WHM02QSZzC7lEilCWiy9/cbwF8IuRgxtcG21iCSPLaPt7Z7yLUBM+haHr8N8VaD7XnA1/E4Eo9vNGcqjAEOnFdd9OdJMkms0oxsRfsPAGcTcjOq29g4ANgej71iv4plm9i/uQUvAaMRt8e+N3MaaGsYcCIV9sBrdFJ8Dpzsed65jTXT9zDPkUlsYL2UFqzS3IM4kZDH6jx+UWAnPHbD45vxakpfwRxgNQJ8YHVgfTzO7UFT71Tgv4hbETcjPquznbWAX1Lhe3iNiqk3EUkppYF2boSks9UC/EehviJf1LF58rWdAl2jUHNa0bkewgxJyySua1H5zn1PU6ht5OvbCnStwqb3ZZakKxVqOwXy6nwuq8jXFQob7d1kSfNMFr15QjJRd9tI06J570P8nJBn6jh2MeAAPH7SuBGw1+EVIn8W13UNJeDFxOfP6GhZ3M144BJCRiE+rOP4YcA5dLBNY904hyiIcK6WUuZ6MpFUtY00zWb5LnAsIVfVYRFZA/gVFfaJc3/Mi5gMXIt4D7EOHt9xDMO/IkYjtsZjdzxWa+Ccc4BbEBci7q7DlrUjHmdRYZ36uzCWSO0pnd36GiQNlnRjoyJzErMkna5QA+sQm7eUr1taINLPzVgjcf8GytfUJrX7uqRfKNBiNT7DinwdpkCTGjv9ye2eG63CXCmZKFJrbiQysjZlyfduxA8JeaOGYzxgFzx+TYWvNNqBeRATgesQ9yBWB85oskH3C+BsxFmEfFHDcUsAf4id32qcQFUVewxz4RLyXEcmkkYQ2UeagveAowm5tgbBuD+wLx4nUGGNZnWkDZgJTIu3qfHfJelddUinACsQsBzwYyrsW4cPziTgTELOrdEreWPgYjpYr8bzxfgcGD43qT1zFZlIupQo92rD0ogPnIf4NWHhATYQOBiP46iwfCMnbyE+JDJKjke8gXgdeBfxBV2EMRWcb+qT8DilF+XEngQsTdCZnmFvPK6us38fA78n5K81eNp2AEfi8Vsq9Szlfw4c5XneqNoPLdESKLKP3BfrpA0bJh6WtHYNunQ/+TpCgT5u9MRNxlOS/qFQP1WgbeRrcJ3LpMntJAXtvqwUZkm6U6F2UaDbmmCXelfS/ylQRw33ZVn5Gl3/uY9s9xwqQWQfkfRm/FDczg0FMFvS8TX6JmyvQC81ctIm4TNJNyvUsQq0aRNIoy+RSRFMlfSgVJMvzxuS9lJQ0/3ZTYHeq6+LTVPNS9QBSbtJjRrXI7wpaaMaBs0q8nVjm1dnRivUUQq0TgvJY24hk5/EpLCafN1c43N7TNL6Ndyjhes4R4xnFIV69En0WZuJmmhovRxxOGGhYLz5gFOo8HO8Hi/R8D5wcxyLci9iRgNtLQCsCqyCx5rAongsBMZm+65v4kHg6wSd9+x5Ohhaw/EhcDHiBEImFTzmJ3j8iUqt/kTPAfv3RcNsnySTBJE0ZGidChwc5xYpgq8A/6aD1es9YR34DLgScTUhD9bZxtrAhnGekw2A1fF6rYG4lfiAyFnudcQ5VOoy034O/IKQCwuOmQ2A6+lg5dpP0+dWevocmUjNWbF5AdiVgPEF9l0Q+B0Vftp4RGkhTCHyr7gS8d8afTU3oIs4NsJjGFEEconmYgziQEImFNh3YeDvVNir9tFzYLnS0yJIujTWLRsyVlykUPPXYGB9p5GT1YDrFdZs8Ntcvk5TqCd6qI9zM8ZJOlRB4Xs5VdJPazDYH6mgnmDOEe2ed3Md1EUkdVsAp0nareBknU++/tB41Ggu3pJ0uAItVHBADpCv3RXocoX6tMV9m9dwhkKhKJJ7fwWF3fcflLRCwef3Vfn6oHiXqsNvRLvn31wDdfmQ1L30+5KkVQs+8NXla1yBNmdLOkehFlUUrl4LXpD0vRqkkK8p0GUKmxafUiKNqZJ+pkD9FfkOPVvDsZNV/EW1pHyNKd50SSjNgrokkrqJ5BFJixSctP+nQDMKtDlT0tD4mI4algKfkLRTwUE3TL7+pFAT673wNuHqWI1cML6GfRToJAW6QqGeVCQh9ma8pcjHpB5cWFCFrsjXqOIvoJJQGoWaQCTXKNR8BR7uIqrNb+RTSevI1/LydVeB416W9O0CJLKcfB2nQC/We8FtxnSpUFT1mvJ1sAL9XaFebnenm4znJa1Z8OX1u9oV6RHtnpd9DrIQyW8UakoNd/2PsQ6ct20kX2/X+kgL4i1J+xcgkU3k6/a5IEXBW1Jh1S25LaEo89qfFBZSMduFsZIuLfCcpkj6VkEJ9CcKan3yI9o9P/sMZCGSw+IHs4n8XEIJ1eXxmLV58nVMfRb2XHwi6cgCfdhRge5vwfnbiW3qIBNzW0aREfRyhfqk3ReUQPXa9lOgyTn7hpJ+WZBQ9lCg2bV1ZUS752mvh5Re/j3JeCBZhDJb0q4FHuBC8nVHgffBaIU1TfYZkn6nMHd1Zg8FerqGdvsSpil6ex+kQJur8QBDT742lK/TFdYb99I0XJ94thurmPZ9jUINKHCd2yvQ9OJd+UJR3p4SNkg6Kr5RnbP8HIuqspGDTKZJ2rrAQ1tWvl7IeVIz1GXjWKrgoLlMYbekyi4S6c1ifKvwoaQxki5QqB8r0CbyC/v6mMSyjXxdrDBXMmgVXpP0dQX6eQ1eCmMlLVXg+jaVr8+Ld+VzlYSShqQR8Q3qnLn/sBDJevKtkX2fShpW4GGtJ18fFnhKxyakm+NzBs1HypeGvq2gpqXGeQFzFE2yvyvU4Qq0YUwWRYllPvnaW4EeaveFFMSbklYrOEZrUO0mqySULihKI9DtRfMfC5GsJd/qqPWOivmQbKug8LLkP+NyDH/OUYVuVpiZS3Qj+X1msPcGfChplELto0CLFiSV/vI7c1D0dnwiaYMC17S6/FpUusmKamXP25A0REYagaellI65unx9ZLmL76mY9+EIBWoo2YmBScp2OltaNfkRlLDAV5So6lcKcl8WV/eSez1D0qs5+0yV9LUCdr0NlL/YkEDb0xe0NdAvvvj7iMqTAPA6sBkBnyT2GwI8QgfLGMd/CmxOwKs55zkIj0uoNO1i70aMIOQ9x+8n4HFifWn82gqfKM3Bu0SpHN8CphmBhpW40mAyJcEgYHE8liHKEduqQfUscA0h/0bdAuwqwDt09IoSqj8g5HLEXnhcSsVZUN4H9i2QW3gT4F46io6lUZ7nHVhLf5uJdpPJfcDw6udPgQ0JeDuxz6LA/+hI1UyZAmxFwLM55zgKj7ObmLP0qDjxsA3rAlfQwbpNO1vz8RHwAmIc8CbiXeCd+O8HUHdt5Cr6AUvF2xA8hgArG38XbvAcEBWhuSPO67I/Hvv3kgD4MYivETIH2BmPWzPGnoBDCPlHzl3fErizOKEc7XneOYU73ES07QlIOoeoeHgnNibgCWO/h+hgC+O72cC2BDySc44T40S/LnwK7EHAp8BzdGTejBeA7xDwsuP306hwQi8Z0FV8DjyGeBjxMDC2gRq8zcQqwBZ4bI7HFngMpYkFn3sBHgS+T8AQ4P4CWTKOJuScAoTyXzqKppPY1vO8McV27eNQlG5RSiwBH2jRIa+y6MG+pF0K6Jun5+jQL0laPmEkzdr7ZoVawHGeofJ7jTv4HEXLr8co0HqqbWWkndsgRYGMIxXqHoVNtW31FZxawFt7u4JxY4qWjIe0e563HIpWbroZXP9muZGnOqb39wsQydkFjHEXxef8ds4DOirjfEf0gnyoMyT9W6H2VqBBvYAYmrEtrijg8u55jFhGFiCU3Yq73ve4QbZH5XJZDK6PAFsQdNtvRGy8MnFqXMcmC6dT4fgCl+V3ntueru1jYE8Ca6rExYDLqLBzm9SakEg3vxxxLSqUu9aGCrAMsCKwIh4rE+WCXQQ6t0Hx50Hx54WBGUQ2q6nxNgX4JC4M/kHnX3gDMR4K16CxYUlgTzz2xmMbvLlKHbLhcEL+lqPy/ByPPxa7Ez1qkO1pMqmmXAQiY+C6BHyU2GddYJxlel+L2DuHSE7GY2QThtt4YHsC3rL8tjlwDR0s1/BZasfLwD8JuQzxfo3HDgQ2x2M9YD081ottFa0uni6iFaI3iAp/vRLbcB6HzsJZRbE0cAAeP6bCCs3uaA/hdsT8wA6OqSdgP0KuzCGUC6lwaLHpO/elflSXh2unbrCFIcItIl9vWeS1exSqX474l+elWhRPSE4ntOPaoNZMV5Qj46s1qgoD5GtnBTpToR5XgwWFWoCZku5XFAm+gwKnTcq2VWL1tEjqh96GgXH/787ouy9p5xx1vqJCUebVHeYeD1lZPFxt0ZT/tdycFyUtmDO4DmzSJL/JEZC1mIoFBTYT70s6sQYvUBRl8DpIgW5WqJk92tvGUXVQO76Ag1pyW0O+zlWoL9p9AQVxesIu8kjGfjMlDc8hlAHyi+arnaw+XI+nGxQZgzpxr8XQ9GsLIUxRvpv8ZvIz37qjFGpx+fpnDhlc5DB+rSRfrxd7YE3BW4pWtvoXnExD5OtoBXpADSTH7YUYJ+nkGgqMLagonURfyIt7eFx6NItMpGhJJi/J0rKyh5hYcGOr53nLbSaSRgInVz9PBIbGvh1VbI19PX5nQm7P0B2HAE/TwaKO329C7EGIgAuocJjjci9A/Mhij1kXuJsOlnL2oHl4H/gdIRcj5uTsuxjwAzz2p8KGTTr/FOAt4O3Y8/UDxDRgumVT/Ey82Bt28XhbB48D8OjXpD5VMR64CnE+Ya6taGEiR8VjqDCozvOdhTiJkEWJnBC3rrOdZuA9YCMCJmbsszVwHx1FrIW7e553U5O61rNQpN5IiZfmVhbR3BZzc3rOMtkg+bkxENV0BD/IeGe7luO2kN8jovMMSccpKBSOv4MCXaVQs5pw3kmKJKD11ZyC5tVtgxbetzmSrlCodQv0Y1FFKRFrzTf7iqRKop1+ivLwthPjlK/qn1BMLu276o4M9eZMy8S12UnuV/cHam4VFas4/7CkszN8FX7u0El36SGF4UaFnY5zrq1DUZh9s3OgFHH8q3c7vwcm330KtVOBmjVLyNc5CgtnMbvd8XL5dg2lL1qB0Qoz5wTydVux+z6q3bxQMySNTF7B60rnBj3aMmnfl3s1pbrlebcWgSut43d7gEjeVJRcJ49EfqhAE1rUh7yB2ch2QQ++yV+T9H+xDSKrT0Pla2yB9iZJWtbRxurKl4ZbCdvLOLktJF/jizU1vN38UBiyqDfm0uY6sssLeaHZOzVhsh/jOMdPWkwksxWldMxTab6tQK+0tCfSRi0ikvXkF3X5tuJKhdpVgf6oUB/XcNx4RYm7s0ilnyJDf56U8rHc92dB1VbFoCjmKEqwdZyCzFGYJ1FuLr/IKH5LfUXdUY56M0C+dbL8NYd5V1VN+R2sMPPJVrdmSDtZeFjSGjkTcZj8Hksu/bSk7RWon6LcK5vJ174K9EsFulih7or9U55XJElNVJSHw7xLkxVJnY8oigtqxJ5zu8Juaks/+dpVgW6pwa3+FUV5ZrIkr6Hy9WROOzNkjxdDUczTZU0eL7660joemkEHU5Sfre20Yn0b2W6eyIW68rhKihLFmL4b51oudrxlv+S2gHy9lHFn7lKop3Lu3h8cZHVyCyWS2Yp8J7IG9wrydXnBUqShoms9RWFRHbnPIKsi3jLy9RuF+qxgWy9L2jOjvQ5FRss88rtIoXWZ3pOvi5p8/x+VOp33ssjuRWXXJqqhGmHvdWZTV9a0ztm5mXGhG1jeMXMkbZjDtlnlN6+L32hDM95f1zmI5LAWEsl4Zafom0++fquwkFowTZHktorRRtFKgn0BPypgFF4gfmYFbQO6Q6G+lNHeusq3g4yRtLDj+Ly0nrXiPoX6jgJrnuMkrsmR4teUX0RKfKbdnOGEpBuTPb3McsHPW64oL1rygIwJP07qtEG4xLtHZC8M9b0WEsn1CjPfHl8pMIilSH/P8oRt5TX0ND6TtHEOmSQlgz0UFEr/8JmyC6EtmPOykqJx5souf2abCP3gHPK1LXBYMLLdvJGCpOFx5wIpEk8WNy7uV5aLe0HKjLsZIj/TV+CemIj2dty48ZZ+oChupRUIJP0i4yEvEA++vOH3uSIP0Lz6O0fNRWQiRWrcg4q8RPNW9VDkJrC/AmtMl4k7FDpXapCvQ3Lq1rwuaXXHsXWU+WwYUyV9OYdwc2ozheqNuU9kGF0PMSbUEKVVkFDS+hk3o5/87o068IhkHQRTHDd7YzW24uDC55K2yyCSLZSfRX26IoN1kYm0jmrKYN7nMEcRAexRwJ+kv3z9uIB68IWkAzKe0VrKlhg/U9rxskpqNp+pVuM5KbOW9lD5RSpW3tdu/uiEuiKCJdnVCtsqxbk56k2j4qNtGW1V1VSTpDDelNvKPkCRF2Xe1dygMDfTvqfIE/ZGhXOZTJKNFyTtl2PIRlFipYsK3Ot/yl3QfkH5ujajhWmSNrcct4B8PdzMiy6Is3Lm0SnF5tHwdvMIkgZL3V+4ptHxO5Zh/66UGXa+bfGMUlacbbnBi8ue4qBRPCw5bRory9eLOce/qXwntgXk60cK2uo01RvwhqK603kpKTaUn7u696Tk9ED25OvvGSNwquwSykLKrxZZK/6kUKvK19sZ+2yfMX76qZB9rv3SiQxP16stk9jmxZl18fOpsaJKD8tucH2sgTZd+HdGrpVvKsiMU5mjyPic5cTmKbIJFKlCOC/hbUV2lazo6g7lh118IjspVLesFKCzZE8TsLKaK/1WjcdZdr7xUua92ETZeY5jDG8nkQxWZGvtNIisZFzEzyw34IYcsez3GZf9kpRp7/hYstb7bUW8yN8NJ6vklmeQe1X5ld22kK/nmt7ruQvvS/phhk1lXeW7u82RdGTGyy0riM6l8mwgv2mxPO9Lncvbd2aMq1/lSLcFisK1TzqRNCrZE9MGMkjpIsyzJa2YccFD5c5PcmMc7JS1HGqTePZtgXXBpkahyBB4TcZDCyX92ZGEqbqtIl83zEX+Iz2BR2VfadmoAJlUcXmGlHl4htr9hewLCdspKGL8LIRnJO2VE2w4U9nVLZeVXyRp1vB2EEm3+JvPlbYb2ETEP2VIJR1yL2VNVVcAoCuG5i+Wtou8mWqFqyzBQPkak3FcKGmPHH+H3/XBLGm9BTMl/TphTxmo2ldY7lToDPffNyNu5hNJQy3HuFwWWoVbcqT+kfn3w5ZDveVk0k0qOcW4iJUsk/gzuT0JUXbpiBvj9teWb10Gfl5pO0kNUZSF4cqzsrjyo1LvzHjQ2yrQ+03u67yKdxXZzeqN43padt8k5OvgjDH6oeySQcFcI03DThkvrIGy5w8yMLwniWRIfNI5UuQbYSbYselnP864yIXlZ8ZdBIpUC9vKyAzZRdxmqwouIllGvl4rcLzNBbqfIhtRqdT0LrwmaYhjrGaRwwuS1dGwJ4vYvyVlGvVH5JNbz9lOZEglpuqyikUqeU3KDA//YwM3+1gLSWW9QeqBay1/NWUv2SXxuaRFEseuoPzo1RLtw0TJmdXtLxnjdbTFMN8heyhJq5BljPXkF0m2NbwniGRwfLJOxljC6Ozllhu9b8bFrSS/cCYsEzb1ZnU118P1KgeRDJVfU84NSXpWkZv8jaVtpE9gkuy2EE++bs0glDMsY+acJksnVyp0ZqefJvuqZnUrkE2w9dKJDL+SCwtIJS8pO7PX1Q3c5GGW9pqZ4vB+2dfvhypbLSsx92CipJUtY2ABZZeaOCjxAu2n5i7zv6zoJTpYbkfMf+cYYx/NP83wVhJJ1a+kE6ZeeaWFGLLySmxqIZ+isK0MndhE9eYlyVq/d1hJJPMc3pY9neMSynawvFmhdlSgfzdZKpmjLjthVt0omw9MdduxydJJTaUuJB0FnF39fB1ir0SJiC8DrxglK54Fhhm1hJO4lwrbWroxGfgPYg885rcc9w7wZQJmJr5bE3jJWjm4dkwFNiDgdeP7ZYBn6WDJppylRF/CK8CmBEw2vl+DqOTKwB7uz/+A4QQMAV50jPt7EDtklNV9lA42zT7Ntp7njSnSn1oL8x6Z/HCK0ckjLc2dmHEhW4GVSCAq4LwvIX911M35GWE3IgG4rElEArAvYYpI5gfuKIlkrsanRKRhwxrAnXSk6jO/AhyYUwe7FdgYGE8Ht2eM++3xMmsrHZ/xoo8xovae5UBGZPD96m74XFjpvCMvyx4jU90ed8hW/5PkKVoTf8cme1nUmx81Ub1xebdmebaW6NsIFSV0rq7CfC8jpePNspeduLCXjo/bcmwnBWLWCiWfrkUyOTn54UyDiQ+Lq7sl8YcMtt4Rj40dvz0X14z7KR7LW34/3Gh3YeDUmoUsO54EjrX0+xg89mp9AcQSbcIjwM2dtQrhSsSehNYR/G0863g7kpBnW9nJOrETHkMzfj8rX6oaUeQ8hWaHosSzzwAB0PEysJYhHr1LB8slPk8CliZgtqPNx+hgE9f5gKeAr1h++zPip8bFn0WFo5sw0acB6xLwpvH9psBDdDRRiSrR2/AMsKFF5B+Bx6WOF9XXCbnLUMPXAMbSwYAW9LER3BCTow0V4C06rC/uGBM8z1s57xxFX+cj4r8dAJcYndoLrxuRAJxL6CSSLcFJJBAxnI1IpgG/Ns69IjSFSACOIEwRyVLAzSWRzPXYAPiq5ftRiOMdk/BqKqxkfPcKcFQb7Cd52B2PNRy/hcA52X0eogLLxEXJ5IDkh38ZbHyE0cxs4LyMguNH1amSnI343PjuvCapN9cjLjX6XAGucxQuHwdsRkCFgOEEqX6V6Hu4gQ6WsHx/hmVsAAwGbrUYZC9E3Jox/luFAHgAmGX5zQOOzZgrFyGmZzc/ov6exZC0W9ISc2uBgL5/ZBh8llehimMpTFZ3V3QUZXhvBj5ROrYIuevpTFQ6U/nh81QSxbkXT8ieAbB/hpOXLf3oEvL1aU92XNIlcT/2cozFWXJn2Ef2elYGMg2xRV7ruyU/jDIY90eWJi7MEJmOolKXLHEWYertf3aTlI+fE6Z8BzYGTrL0NAB2JeAj4/tXm9KTEu3GV4BrqKQU5znYnztECwU7GUd8AvxfD6s734oXQa5FjLX8Ph/ZWsFfm2SItUJGHM4kpZd6zdiU1yz7VLeB8p1pDF+PNxsmKR2JuUOTJAHbMvNCcrsouzJy9dZlwRL1wVUkfFPZs71/JmnpXuBOcEQ8Pl1xQF8oO/eyy10jhmlS7IY8IaEqlXQAXG5IJbvipXTM8zLYbX88FrZ8/xmwPgFbOhxozkNMNb47vQm2ktnAQZb+nkmFFS3734A416ILfwOPQ8tl47kKx+DxPcszfQz4rWXMLAqcaxmThxHyaQv658JpVLiACj92jMeFgYMzxurF+YbY+kqKyqiFY/r5m1GTM2WPZalurnD7ap6QnSzSxnSlE9V8q0lSia328CYOO8xkSz+Qr+Xk59ZqKdE3MVP2FASVjLFsqzLww15mTxsrt/awoHJz14508YXz9a6oytcwwAd4i8ixp4olgZ0NhrsO8YWjvXWBjRy/XROz4SEWxvwHSjH7L5sglXxC+g3TD/ghkJMBAAAgAElEQVSXww5zlOUN0w+4kQ4KuQeW6HOYH7jNssITAvsYcWFVXEKFBYzvLkK82JIe1of1weliPw24KnslalfXD1mzsqri9MNyAps3qG35rIpDMk51HBWuosJuljb/aEz4rwBbOFsqjl8QMsX47hg8Vrfs+wBpwzPAKVSsvgkl5h6sCFxuGbvjgWMsKsHyROMiCQE/yo+B6VEcnDEf/5Gt6gyTo5yoU3lSVCG9Uz/agKCbhXgMHWyT+PwZsBSB9Zb1Bz6mg0WyumjB1YjvGhd2K5WURFQrniW6niQ9LAO8bon8nEnk7TvB+H4j4Ak6SkvJPIKDCFMvS48oWtg0IswB1rZEnN/oeGG2A5OBZRzSFcAHdLC0+/CjPc87x/zSSk+K1pM7VZw3oBuRfAm6EQlETl8u7t0Dr2YigUg8TOLLpFWrenACYUrO+AMVawj5aYQpIhkAXF0SyTyFP1uM8gJ+aBn1/YHzHRH0Pe/KZsdg4DsZI/ia7J7uZvvSJet0U3GuNhrex9KJ6zJOvm8d0+5t4F6jzZ83wVbyEFGelCQ2Ab5v6eObwOmW6zqTCqs23JMSfQkLApdb7Gn/w64C74jHN40x9QJRMGFP4WZEB4HT/GBbrariumxVZxtZHNhcs3N48sMdRsN7G4dNIUrCYsMCREunteICy8Xs1wRZ4GjLm+S3jttwEGEkmiWwGfCTUiaZJ7EV8EPLsz/OYn8D+J1lXNmWlU1MJ3rpfVJzD7tjCpGx+DTHOXfAY5Dj2IeAD7ObT0knLjLp1GImxw1XsTRpA+h1GSrOt/FSsQtFcLFBTvvisWAd7STxX8STxnebEr1FTPwbMcZCkOeXIX/zNP5IJWVL+Jh0vBpEwYOmWv40ZMbtPAasQMBWBKxP0JCPyl6xX9frRFKRifmAXRwvRhH5VWUgn0wUOaUMIbaX3Gk0+DXLyW/MOOmejs5egNjD4sYOcJNlOfjAJkgDf7T08zcWPg2BkyxsPgIvZWwrMW9hIezOaR855oBtfP0mQzo5joDP4v/fB2emwSKYHxgZG33NqP4q9siYVzlkkloitkkmw+O//SBtX/i6cfKAtG2jivmwG0xFlPLxRsQbluOuNNpbhkgkawSvQCr3xCbYpZKrEOON7wYSGWlLlNjb8I7tD+zlGBsbEMXMJPEkcJ9jzpijcVSD8T0/w+NGKk5fqG/ipfxiqngIWSOQq5CRlsB2B7qJL6ONizYn3/2IaY6Tfd3R0f8iJhLlCtnA+G0mcItxzhFNkEp+b3kotpBsYZdKTqBS5n4t0Yl/UuHPVDiFCs/SkZnJ7FjL+P2dg0xMe+SbRH5OrcICkDIUVzELty00xvDkBxuZbEMkcPACMDHxw0aQmlCmGpSEq5P94+37eKk9rkepte/vNSgRfEpkA0liCFHCGBM3WKSSxWleAqYScwf6ERniT8JjrZx9h+OxnvHdPcia4nFfPPob3zUqneQha4Eka36TRSaSugX23Z+j4kBacknCZdzZFo936OCPFpIwVZxViFzxG8HfUSrr27GOVAjnW67nl1QaNv6WmLdxgmW0XeoIGDTTGVxjecE2E7Z5XUXW/IbuJkTzCrv9aJKJqeJ8TJRxzIZVISunJF8irR9OBm43zpnl9lsEIp2nYSDuyMnxxvmXBn5USiUlGsTeeCmp/jLEHMu++xvjbRq5TmQNYUVwpnR8lcjny4FFlIgiziSTu1MGy+4XmcVatlWfPPzX0l6WY00R3INSN+NAR2EvgMOMW3IOlV6XHLhE30MFOMAYy5OxLxPvjMeixnem42g9GEckANiQNV9zpJPh1X9MMlm/+s+r0LlEBZGh1DSmPtxkMjE7PRTITYmdA5v33+EZ0s7xePyVCifjcRsVq7dviRL1wCZl27xn+5P2Gr8nZ2UlD08Q5Qw61GF/yZqvjxVUdTqvLnaPHULsX/KA0cCmlpM96jhJBdiujkloruK4DLhFMYe0D8xmkGl5h0itGUklpbuWKNEI1oRUrajRiEmWfc24mVmkNYVaUJV0/oNSXt0QzVfXK9Y1z2N0Orgmj68yTD+Ap3PIZCbwvKP1dcDppuvCONLuw42SyW2IGcZ3Pyh9RUq0ESOM8TcHuz1kK0twrGlPrAWrEdn/ZhF54ZoYCE6HzJfBmaeIKPvaEOhOJsOTezyTQyYPI+eC1eYOErgWMYjA6qZuqjgLUJ90k4T5kDzgu6W0UaKN+C5eKiDjCstM6iD9Mm20fMb5VDgBz1qTCtzzFnKlk2Fgl0yAKEagikFE4f/dG3fD1akLEFMgVegKSBFMox6vAZFkksQ2FsNWiRI9iUVJ+3U8SOQ6b8J0rXgXtzZQBLvjcVpGdYhmkkmn8dVMMbex5SSPZzTu6lTVkGOuCgE8aLS3bYNkMsaShDorf0OJEs3AvYilCBhAwP6E1sJWtnQXd1jm004WKaYRVScPWWTymPMXwEImQ4g9X00VZx3L0c85LmpxsOb6ENGK0NcsHoPjIDXxt2pw4psxRWD3eC1RolkQsB8hHxPZJv6FrMGlu1g8v23jdRHSEfrmwkgzsRJYKxoCjMs+70oQk0kiYKcDYGyKTLpf+nSiBNM22KQOiOwVD9PBnZYCRw8Z5xuAvdZwLTCZfl1g2QbbLFEiCwHpHCC2JEMLkq61facjjYcpoZtzpdlwSScf0N1VxEA3yaSbveRlY891jRO4vF7BLsXkwbxBWzYoQbwLvGR81+jKUIkSeegHqRic54jGownTm3waaVUfYDNjvy9Iz89mIsttIsteI2lIlUy6RSi/kqPmuFScqDO1T9onjPYaVXFs4d31ZHsrUaJWmOkGwG4P2cFiBn3Y0p5JJgCPNCid3IWcAoGphSSRNe+BIVbJ5LXE/ytDKtHy800kk+mQyuLtqulRFCbD96NxgipRogh2spCEjUw2h1SYho0kBgFrF9ivKGYD3yRkK0duxKz5mzXvgWEpycQUoda2NJ4l7tQa4WtLJ2eqVbXCJJMNiT3xSpRoMbaAlLPZvRafrH6kfbdc9hBTOmmETOYDFiNSl2wuGmuCMzFpDpl0SiYrVb951ZICwMRrjkZXjTtbC0zRaWCyM3XgM9KEaBMVS5RoBTzS9rkp2F/AWxqfXfYQc/y+RHr1sxasH7c3wTKP5yfylrXhNcf3MTolkyFEqU9TBwwxLsQH3nG09mXHpL0BsRyBVSc0yaRRFedJyw2yxRVBFEF5P5GlukSJZmG4ZbzZgmJtCw2m/RBgA8t+jRhhL6LCxVSs/QT3PJ4IqfCUBFaqJOpfVAA+sGQkSyIjt4FTorgc8T52A85zxudGVRybYcm2XP0EsDwBwwlYniAvo1SJEoWxTQNk8qxlP9sKy8sNjNdViOp6u2ZalmbgcgkhVnO6GV8nmnsYp7SJRl2dsHfv3fgYm8r0ptHemg2SiU1tsqUxOJWwM/taCPyyxanxSsw7WJPIeTMJG5ksCKxgfDc2tVekepjZ5V9qqfOaew5mzf+U6TlNJmZjbpjlE6tYEo/VgK9aOmlmp280f0lRtckUJzOiIkuUqBmmCjEBu51jPWO/pxyTdQ1jv1b6mrjmMWTP/wpGtPCHiYtZgMjy272x2iWT26nwGh2pIDubyGRKQrXCjCta39LeLNJ2klVKI22JJsJm57Cp4Obq52TsQX9mWsU+J5nYGMp2oV2dqA0TLN81kjz6PUhlo7I54ZiEA+mo6BIlGoEtY/0Lloloc72wLdmaksmr0DLFPGsev5fxWwXD+/WjxP+m3gfu+qceab0uD6a9xBVkVLy9NIZYvrMtba9eSiYlmggbSdjIxCaJm/MCYCNjvw7ctX2L4EPgPEc80NKkk71XkRGfQ8oAm8TiliY/dYg5i2Z0wAWT5bKy2ReBTQSzPSzbenkpmZRoJlYn7fxlk4iHWL6bYPluS7rXbjqpwYyBPyXkSEJnKkhXwTnX/IcccqtFMrHtm4dPjI4t2aB0YJNMbCJbKZmUaDU6SL+g3raMu+VJk45NMgE4iwrj6eB1OvhVg+O1WujLpba45nNWIfWaycTVmGmoLQKTmBpVc0wfmSVJZ9SHNJl0YH9DlCjRCJa2ZEoz4ZF+4WU5Ua6CPV9QrVgm/jvZ8btrPjdAJmn2c0smdqa8HLE0QSolAKRreDRKJkXbM5ejV8Udj1CiRL1Y2vg8DbsLwlLG5yxVolk4iArfxEulQqjCNZ8n4Tb8ZpKJuZT7BTgv0yUWPUJUpNwsOQFpNWeJBkU3k+hcfTLZ2HzoJUo0A7ZxZVMrzHGf9fZvFtYG7qDiXD3NMlvYSnNADpmYBZSz6p0u7Pi+ysS2Wr3mTWs02fPHBjktZiGnkPR1LFTaS0q0AF+yLmCkYUrQLum/J+Gaz5B2v6iiQsayshm2bxb/TsIVLVyNQLSt1JjikkletcJkTJve97nlu6wbV6JEvTBTIHZgt3eYZPI5OLKN9Byyov9dPFAhw/Zo2hHqIZORVPgfHexpYWlT8Wm0PJbJmDZpaIrlu5JMSrQCWwE/icf9CsBlVDoNn0mYycfA/fbvKdRDJpk5g5pBJgBfdXzfajKxFSe3xUeUZFKiVfgzFf6cs898eJizYRZ2kukp2PpURZZk4kRtZNK43aHZZGIjOJtkslCD5y1RohHYxmlflExqIpOsC6w1wxrUL5m8/D946Kb093OMz6ZkMvljuOcs0c8wnCzcAwbYD96El5+o/bjpX0TXG7ZbiW4Arz4VXX+t+OxDeM6WUauP45n74IuEX3o7yORDYFECDnQs9GbNZ1ffMtUcc3JmoR6pwjS42qqz2/Dk3fDcg7Dlbtn7mWT16Qfw0EiP/nuCn0jUWV0Gm/4FHLJBwU5Y8KOzYMtd7b/dcyU8ehv89ZHa2nz9WTh+J7jmbVhosH2f3+4LLz1eW7tVLLsq/PGu+o4tiguOhY12gO//srbjnrobLjkRrp5g//3ZB+CMA+vv1xHnwWY72X+76ky45W/1t33JMzBwkP23X+0Kv7kevrJj9Nnm42Sb4kdsCfsc6x5jteBNohKeLue0lYBtHL+Zl3UtYi88+hFlArCu6JhkkrXakqUCuWCyX6NsvADd08rZSjPa0JkkKYykl/1OgJVsYZ8ZOOMgmJ2R066VmDoJVt8QdtyvtuMevQ1efaY1feoJzJkVPa/j/g79alwKzHteM6ZEZDDi5Pr6Np/N9dp1Lst3tsMnf9y8MTYNcT9uZ803iFKa2mDOq+pCRz+iuCIrmZgEka1HCVuo3zWISxH/sFiyTTUky4+lCAbQ/cEUve8maa67Jay3VW3nPvOQ2vZvNpZdJV9SM/H+G32bTKrYfBeYz6wbkYMiz2vhRWu/p/XA9tKrgYvqQtXD1eXblSUcmLxdrdGZqZ3UIpm4pIp/IkYjaxp/k0yaIZkkUVQyKbpfiRKtwHTL3Gg1mWwAPEEHFzkoYFaGS78pVFR5oiabST1qTlVWsRFFWs2xSzdFYb6cipJErXlYSpRoJmwSdD0LGrUiq5531ovdZevMlExqUXNcJ68aeGzHzm8QRzPUnCRcas5IKp03ZGtgn9KdvkQbYb702ulfUkUtak5SMnFFITPN+GxWKkvCNXFPo8L6iJ0tE9Z0Fms0qbPZP5tPCcABeBxCB++SLjRdokRPwyST3uBEmfViNz3LvxRrFP2IsutbF5smG2rHgvEnmzblSue2HPAzx5vfjEkwUwjUimWN3r2fofctRn05WEqUaDY+jP/2/wxW+lu0UHG5Zb/prrdjC5AVuWzO2yrxZNpMbKHGS5EuhxGdvPYcDGkyaSyPw7LGZ1flwRIlehOqdaX6T4LVf+/BZvCyRddZaxNY3Bbc0wK4IpcHkbZqVrWSmslkUVxkUjuWMCSJRiWTxd73WPna7t9dTpdl/NMPzSPmPlxxOtz412L7zpkFS2UVSWkBHv8PjB2Tvc8iS8B3j62t3Qeuj5zY8rD+1rD1nrW13WqYzsFLnx9y6qqNBpdk41bEtYi/UEk5oUF2rmcThchksqVB17p0PTkYTMnkI+teaXztB3YvwIXfgjV/XWHK2hDGFt/76b7Mttow6G+LAJxLsNXusEoN9UIW6OHApKmTYWJGjUmISK5WzJwO02z5JSz79SZ8Rtrz25YHpdn4M+K/iN0QexTMuwJ200C/hM3EaYC12UEWc1hNmkEmRaWbpcyaikZ7T10dMCN2w/s1Fb4xD63WrLhmtOUhDCGY0/PEuv33oq3Z+NoPoq2vwZYX1kzj2Ap8FM9hM09tFa75vKhl/yEJp7Vu5U2TKe5taodpl6hCuMngX4j/Wb5fxtKxrCJfebC1V0d82TyBB2+A3b/U7l6UeMfyYnbNsWZiDpHtw1aOdyrupWEb0Tmd1paji0RsJoYVMvIcvI09d+ShhPjAbDq6TXdb1qnXqP9m2pzPnmvQEa5EiVbiOct3PVF25Vo6eBFZkzVlaaGmUjCDLjJJSSbLGxdiNpxlr3PV+1iSSC80DbeLko5AfLXJmbnH9UCm7xIl6sVYy/jsiQTnawPfcZDWWxlzxuSHd+mq513xPG8yidSo5tvd1Okc5grArVKsGp/MtgpkqvfNJpOx+buUKNE22Mik3ahFMvkAVesLP1tdf+qcc8ulmKf7xa5QR4X0k/EYRYX1Lb+tZrRnK93ZCKZhL7dYokS7MR14pd2dsMA1jyE9/2d2fZ5cJZMJ1W/MLPKmZGIz2FThkkyG43GAg4RWMz43WzKBUtUp0Tsxrt0dcCBLMjH5ITGrx6TIZFVj0o83JmI/S4NV1EMEQ43z2Sr/NYqnSzIp0QvRW8flG45+LQiYC4AzuvadkFJzzGLLL1saXdMhZbxG7RnXNrS0VUeq1G5Yw/g8ppc+tBLzNu6z1LzuCYxGqXMn4bIzrk16XTSxIDMhJZmYluSXLCfNymj4fMZvNqxGOuT6yQYn/1eMS34YdxTka8AehAwn4DhnFdUSJZqPu41xbrMpNhuzgV0I2Sl21zAxHnfuZ1OLgG5VM8dWADzP60ZGGyb+/5B0rZm1Moywz9dBBGZdnacaJJONjP75wIOONkcQcGOcD/PiUoIp0UN4k7Tr+Vd7wL/kWaL5MB/2WJos++LalprIVcnE87zJyWiiTrvLl42DTGkjy1vbRSaTgb8iqxpkqjqNkontodzraLNRlapEiXrwrGU8mhJ1K1C1h2zqOJfNia6KocbnhFPr/dCdnCYQJ5beAI+rEhf7P9Tt5DY7RxVPOb6/BfETQl7B4zwjwdvmeJydON84Immo3hi05eMtuRJ1j4NM1iJtVb/rVnjrxdrOGRSoazNlEvzXlqgiA+++Wtv+JZqHzz+p/XlVsdEOsFiG95lpfO0ANsbjcuDhW2GwGbgWo998sO3e9fUJ4Ft4/ImKtVwvRHPdhY2NYz6ik2AmQHcyGUNcKmMjo5EnDZf0RYiMnLY18kcRIel8kFUX4VsQ5xm/bWt0MiQymtqysxXFN/G6qS1PEAUvmc9od7xO0U4dMGVNeGwMvD6mtvMtvzosmJGKbuFFof98UT2WWrHMylDpKetcCQAGLQ6eV9/zAlhutWwyMYsCbI3HoPmiZz36UvdxAxdujEwWxp2sDOABB5msSHruTOnihQndfpB0lGJMkoT8zm1N+TLxfQXd9kluY1N7S7MlLRD/PsPy+5eNNn6uwLJXNt4fL533U+nzT6XrFab6dYnC1DHjjGt1XW9vxsO3SM8/Utsx774m3XpRa/pj4tHbpdeeqf24d1+T7rnS/funH0S/B7UPFd13jTTxrdqPawZOHxVqwLvdx9wZlrHZ03hV6blQ3fa0zMd7u/q8m0kmw5M7rmI0Nt1o6FzLZK1uf3PcmIcl3eT47WCDnDZqcEJPldRh9Gs3B0ENtVzDow2dvUQJNw6xvIifbXenJP0zY07/3pi30yU90/XdYEhoI57njUmSi7ki8pgh/pj6UxKPOkSlzYFdHcdtbXz/DOlVpFqwYHy+JP6LrEvE+1qS9P+9XCYu0QIIuM2YH0vSOxKbu+YtpFdcnwSGRXP22Ti+LzWLOisCmmRirnpsZDm4SKdc2MphN2kE3zV6OI2oLqqJH1gI7l/ImSS7RIl6cRdKpfbYt5ekyDAFhiTMlabENXS6lZh8MKb6j90I24X+uJ1sXqX2shUrQyq3gms5tyj2xUvV+PiHpc0ViOrnJDELuKj0OynRZFxqfZm1Nt8rRDmKdiTkIcfvM4l8UGz4MulUIZWu6xjT9V13dP5gMtETlpuQpeq4nMSyYK7eXN/gZB4MqfyW9yNrQOJPLA/0HMJS2SnRNHwO3GCM6ZVJv7hbgZsRdyNGOkb04+Ac6za/rYQX/JjqP91mUNJuMpjuEcITSCQ9iZFFJvWoKHsZ7b1N405lBxptCrjUctv2xEsFMU0EriilkxJNwuUo5ap+SA9IJRDF44CbuO7NeG2a83wKkTdsCO94njeh+r3tSjrtJpsYjZiOX1mJmm/NmISj48zYJrbDS2W/vrZB2eBreKk0kKNQ6uwV4AjL7fhtKZ2UaBJMo74HjOghe8mHiAqwq4O8suarOc9fiP9W4Onk97aWx1T/2dFo5D/GCZclqqZuwyu485scQsg3CFPpBjqInMiSuLpBycADDjbafAe4ydLuD/FS1edfA64ppZMSDeIh0o5qW9EzyaMBbqGDN+hIrXACfEC6b1WsTDqTQGixl4CdTG6q/rOLMQlHWyaVuU8SLpvH5pGIZF1+tak6TzrPUAw/ppIKajrdcu4lgEMt1/PbUjYp0SDOsIyhI3tIxYGo3s1Kjt9uzHhZ2rzQE9nWxiS/T11NHEH8BUTr38l6Tu+SDvrbOeOG3OqYhFWj6HjLbzvgpQo3N6rqfAnYz7LUbbPrHGchnheBf5fSSYk68Spwu8XwulsvWRK+JWNsf8uSVnUFQPCFmW3AxQT3Vf8x9SVTOvkqaZ/9Kh4kbbQF2AePv1NhlOX0HcDexjltviG14heWc53hqFliSzH5C0JnnocSJbJwalIxiHEUlR6US9yYQTpJUxXzEdkxk6gGz3pwo7m/63rGVP8xycS0m4Dbq1XYWc8DDsLDFRdnksmbuKN+i2ItIqknidHImszpJCop/5R3iVIolChRC94DrjTGzcLA//USqeQOR1oQiGym8xnfzeewl0ABMtkGjwUTP9yPmGbsnGU3yRKhXNgRL6Xfnd+EiWyLlvy1RYVaETjKsu+phDWnpSwxb2OkJaPZ4RZDf7tQi4ozHdii67ubzP2tZBLrQp9DpHZsn2g0IO2ZamOwKrKYzwUPONTo2k0WN+Ra8Q08hhnf3YS9dOmJVFJF2j8FHi6lkxIF8SZpj9cBwNE9pOC8TuT16jKwhqRtOUmYNp2EgeTmajxOEllX1ck8earOQLoTThLTqU86OdRwhQ+B8xs0xHrAby2XfAzpzEaDgFONffsBK/cS8bRE78dxhKmRdRRej1TsA/gTIXcjHnHMv9HIWR98bdLL1jO72klJJZBNJqOq/5hqjM3BZZ+MSWaLR8jDEqRtMRcjaxLcWrCzRTp5EKxOdIfhcSge/Yhu1N+oMKTB85eYN/AccJ0xpgYBJ/SQVBJAZ7bEwxznvCRjXpr+XtCtzEVtZBK71r8FUQrEZN7Xd0k7uexj2FaSGI06i6GbeBxYk4BHLL8dZolUbDReB+B0y2WfYJF6KsCFVHiHDp6lI+X8VqKEC0dbxtOvqaQC5lqFWURpTw/FY1XL758Qxeu4cLAxR8bRmZ3equJAtmQCCenElDxMh7MBpB3OqgixR+tClHPyFeAIi6qxPV6q4l+jqg5EatumxndP4WbqpYF1Gj5riXkFN6LU6uNywE968GU0EHiHDi50TPFL4/SqNmxJunLnpzkqDtRAJvsbu15hCVoakdHcKEfXv4vHACInf5tL7w+NNh8AHnP3tzDOsJQ8OpaQT5rQdol5F1OBH1nG+qlUGNDz3XHikoyXsm0eJ5LIj3Edl0kmcUTgswCrEDFWFZNJx7dsg7sW8cvAo5bvlwR+F4t/NjXpELxUlvpfNUE62Zq0c9pk7OJpiRJFcSJhatVxI3ouoK8IHiTyyrVhANELPon/QdUn7NlklLCJItagc6r/mNKJzbB6QEaTttB/iPw/PqcjFVAEUSqEnxoXdy9qinTyJyosbnx3OdmlE0uUcOF54C/G2PGAS3us8GcxZEkl37HYPgd0XdM5ZCCXLuNksZMgEuGWJOjMo1oBPqSDJRP7vw8sT2CdjgsCn9BRs7g3GViWgBmJ77bF494mWMb/iTjAuLmrA+Pq6GeJeRc+sClBqm7U4XicbxmnLxMtHfcHjqeSyrHaKkwDFidgluP3u6l0c/P4CFgKCGFKBVZ0GV+hgGQSH3wZRNbh5HJtFPmbTkuwjYOjplFfSoHBpI1X9zVJOtkfj+GWYKajSnWnRA04iTBFJIOB0yxT7D0i4rkVcQNiR+NFWS984E/IWQgPolw+LiJZlnQszivxfK3ADVlEEu9TCJ0WXNPOcJFl0mXph6dZgp6K4DgqKRdk23JuPbjYYhy7EGV6B5YoUcVDwO8tY+VPVBhs2f8Awm4BsJ9Dw97dABcgjiHkbMe8CIE/ZsyZg/BSMzfhpJmp4kBBMvE87yZi9/qv4bFU4rc3IeUjsjdeyhW9ilfJXt92YQmi5EVJjEE8UHNLaawG/NFyK35gMaaVKJHEZGAvi1r/LTwOsrxUL7csG6+Ne+GiKELoJBHTgFrFNcgovdeFCnCgMQdeIvIxA+430w242iiKURDF6pilIUyfkwWAIzKkk99lsOMUYH9Cq3PacVRSMUCHE1g8VGrHjy3qziRgH4f9p0QJgP0sL5zlgSssU+sz4EjL2L+kCQbaN+NtfewJjSB73u2FxyrGdwn3+VENdzAJScOq5bueU7qM4MdGdbDP1FUO1Lbd5ajsNzquKraUo4zozyzV0M5rUmnF9yUNsvT1+DpKlZaY+/EHSwW8inw97tj/e5axu18Tx9ZdCiHKS6AAAB/7SURBVPWm47fRGdX6kK/njf0nxn8DqdaqNYUJZUz1ZNsZN+ZXlpvyk4x6xNs4yn8GkobE+/zFQhJfSFrCaGth+foo704XxJWOm35NL6gFW6L34C6F8izj5DeOcXKzZVwtJF+f9FB/t82YiztZ5u6dXdeRayupota11ZHVf443RKnzUcoi/bOMbFL3Aw87OvSr+CgbJS4MnGW0OgU4vknG2O/iWSus/YCw4bIbJeYOvATsbllI2BaPEy1j5z1IuR8A/N7i59QKPIk7mxrAb4z5NAlYowbDa91QQjpZp4C6YRPtqtu3HCJeKOmB+K8LW1jae6wwT2djpqSvWtpfUr7eb9I5SvRNfCZpecvYWFG+PrXsP0f2sbSO/B6TdfesUUO4putfZxyODfV4fY2s/nOScfjZlhozx2ec4g7EOMv3HlEZgCyPukvoSJmtDmuKKRbmB26ngxWM7z8Gvk5A5mJ7ibkWM4FvEnTmQa1ifuA2OlI1nyByrzcl2gHADXT0iIP9a2Rnn/+lMT9nAMsU9Hg1UTOZJFMTfAevW36PN0nncFiPaDnZhZ/WSQBrAj+yZII6t0lrL0sCo+lIxQU9B3yNgOlNOUuJvoLZwC6EPG757R9UulVxqOI+xB8s4/E8KqzehD7dT6JingPHZhSR25D03HwU2DL67v5khc+WQdKIqhx0kWFYWs8iNt2TY0m+sU6Bz2aMHSBfr9fVmh2jHYa24Qo0q4nnKdF74Uv6lkNVONKhqr8vaTHL/rs3afXmtnhOreRYyJCku3Pm3fWWefd217/DW04kCUJ5W4p0wiWNTo5JdVHaMuOiVpKv2XXe1JssN2wj+U1dzP2n46HsrEBzmnieEr0PgaR9HESyiwLrVJ4paQPL/kPk64sm9MmXtFLc5h8cL+LZklbJmHMbWGw2j3b9O6YeTmgkUu4kiPKiHms0c6ZFsDovQ0d8Czg7Qz2ZDHwtzmdpYlc8vm+0/BTw2ya6mv0Ajz9bbtVtiL3LejpzNd4F7rKMpR3wuI6K1d3sAMJUbp5+wI10pArM1YPP4n6tib3iAkTz6Y2MNs6xzMcVu/4d2VAH64GkCZI0VdLCBvM9qjQOzLAqZ/mKPKXISW6gQ4X5XNIyRnv95OvZDHavB2c6JJTtFWh6k89VovdgnKRFE897U9kdKiXpLMcY+UeT126ekZxq9vuSBmZIJXta5PZHuv4d1eNEEpNJp+3kFOMmbmQRAD/KuciDM5STfWMi+o5jn/ssD3FN+TXZNW5RqEsVZqpcv3QQ4qby9XkN5yrRtzBO0iLxuJ7i2OdeharUYFdpFfbLeGn3l6+3LMe80/XvkLaQSUwoEyRpuqSljI5famHj32UYhTz5etpxg96T9DUFOi2D4Y+23MSDCj7IgxPHbi5f0zL2PdbxsIbK1weFzlaiL2KspMmO356UtJBlTOyooEep5H9Kh7okN1toyP1dc2pU24gkJpOjqj250CCKJS2Tcqa6jEe2bSuLRFMUsyStaWnzrzki5seWB5C3WnOSg1CWk6+X676CEn0RzyqSWsyxsJZ8Te3BfsyRtF7G3LLNx4/VjSCHNMIFDacq8zzvHGK/k0PwuqVe/Bj4rWGMnR84M+O0DwJ/q9N4Oh9wlcUk9mPCzPX4AUTZvJMYg9jLUkSpilOoWK/jPWATAh4s1uUSfRwvAdsSdMtPApGf0l10OMu/tAKnOZxAqzidSmqcP4qq+V0vy8rv2mOQNLxKbbcY0kl/+ZEeZGCTDAZt1FfkCosqtZj85Bp6Cpc6/En2yRFT/6ZQHZbj+snX2WVw4FyNV5V2i0C+FlFzjf9/VagVHPOoihcl9cuYU8OUXgp+WdIkSb40Re20lZiQdFO1k5sbF2Jz1Hlask7e6taor8hhFjVkHbmNZ1LaAa+67a8gkxbuVWgVc5GvbyvoUVG3RM9gkqKYF5NMFpKvJ5t4nv8mjLp3OkZhnnqDfN1vOe7Srhk2st380Q2ShihapbXmO7E5sh2TYXVG7nDuKiZKOleh1bYxW9Kmlja/mUMMf3EQyl45DmqvSFrRcR1ryteLmVdSoq9hWOezDTpfJANkd4loBNVUH/tmvFpd9rvq9kPLsQ/FsyCIHMlt2SXbC0kjq501o4VtbvazJK2WcRPyfEV+EZ/D5aI8UekVJuTrsByZ53wHoXxTgWZmHPeJpG0c1zJQzfc1KNEemG4IX1agwfL13xY8338r1O4KnH4tY5Wt3qwkuxH48a6+HtVu3nAivj5NlNTfuDDbsu7jknVtPvlWd93IpxLn+LvjQT4qWW0av84hlL84bChbOR5OFXMk/SjjTbGvgtIfpY/jGXWXvBeRrwfa0I85ktbKUW8eshx3Z9e/Y9rNF5lQwhh7omVS2ZZNj8sR047ImPhXKVQ/+RqZ8Va4wCFpnJPzJrk+bts8bj35+jDzSOlihZrfcT1fismvlFP6Lk6Ox+xK8vVMm/rgcqCsbj+yzJsXFNl75kSO60PazRe5kDRKUYdTPiUbK21VzlN3kK/bM6be61Km+iFJv3LceJtjXRJ3KrTmsl1W+Rb75yUNzbim9dW8hE4l5i08pGyJfiWHRN8n1JskJA1WbIx9RulVm7PqUHcWUeOpBWwrPBX5ui6HUB5X99iMpB1kdM6xMyT9OOMN4snX4QqaEk1aYt7A+7IvSeepN7fFY3W29FC7OaImKOEZ+3NjMi0g+5r5L3LEtjWUvbRbBCMc58iSfKRoTX45y3EVRatOeSrL3Qo7E2XbtmUKkFqJvoPzFNb08gsk7ahAQ+VnrhrOlj29QZ5Z4DlF6k2MIe3mh5qhOF+sr7ShaEvZV3fWzrlRtkzatcCXPSdmP/m6IWcyf6CuJUFz20FBbob8GYrUrSzr+xYFiK1E78bx8fhaQb7eK3jMofExS8q3zIwuHJDzwrWpNzMkPdY1pka2mxfqgrpq7YSvKK3G2GJmXlJ2vR3k69QCk220wk6xzsQcRUGDZrsd8nVlTtvTJO3geKBfkq+Hc3sWSTlZpQeQr3Xl69rSSNvnYE72Lyu/nMU4RatD8znUkypcLgvVbX7ZA2VvikfRHOm5dnNCQ1AiTcFpxo1eSL7etVz89Tk3zVP2mn4gda6k/M2x3wy5XfovyZnCvqQTFFiXjjvk6xcFUzpeqVBL5xDnqvE1lCkiez/2drwgDsmRpmdJ2k2Brs4Yd48r7WphbldZjn9S3dSbYe3mg4aheHVHSqsJ2zpu9Ak5b+48g2zVu7Yi99LdZNkJxSso/dyr0OoUhyL7ThG36imSjlKg+XIGypKKbDNlioPeh+lyS5p5fklFUMTg+lPLPJos6dG+rt6YULS6M1aSPpRSE+c4y40I5FYnqttacufUDCXtr0Dzy9cLGQ9qitwSyncV5Oam/Vh2lalKZL8qmCf2LUU5VWwOdqbks5MC3aCwzD/bC/CFpI0dz2r7JmQymZHRfnXbUnY7y/ldRJJbdLxPQZH9ZIpkT9B8rUUSmCx3vEvyRro8ZItiitwJr7eUr88KtPEXhU4x9NAaBtUbikIR8kgFRTaanyvIJMsSrcPbcgfY2VIj1gpf7hdVdVtG9uJfF3SfT31fvTGhhP3E1C8Hytc4y00Zp3yD7DccWcJrwVRJuzge3GoqlvDoadnJb8U6eve2IlXNzK3r2jZW5L/ztLIrIZZoDu7IiBTPyu53n8LCLgBZ1TCR2+B6n8KknWREu+d9y6CEd+yqlklnY9k8gyzy9f0mvAlCuV2UB6lYINdkSd822mjkLTVF0jkKc30LkttgRWU4/qRQT0gNE22J7sjyhzo541n/K473qii/tMuROUSC7AbXdySNq6PoeJ+EEvaTiUrnzdxadv0vL34HRasoRTBZykyUdI1CDbC036HiCY/+qlDbKdAxTcxn8pwiacVl9HVtC8nX1xXotwp1i0K92aT+9AW8L+kIBdomvge2vB5F8YHSuXqSmyvYVIoGfHX179iccfqHAi9PV7zaTV19GNPuud4jUGQ/+VySHrDcOJtlOpS0VwFC+UuByb5p/Hb4ZcZDfUp2j9eqFNTOhEe+opih7yvIzPafRzBbytd+CnSCAl2gUKMV6jlprkjm9IakHypI2bGWVX0Fw8fIvaIySPlhFY8ril4/JodI/l2ASHZ2ZP/7V8KfRL0xR0mroIT9xJbc5QrLw5mjrmQxrs2T33lTXTg50cYFGft+knG+FeTrvl5gnZgu6TKF2kOBFqyTWGzbIooy021jbL09J8vLihzHXAbs/sp2V7fhNxkTfA01rxztnY4UoMltc9nLt4yO/8YpGOc+g2selPA/2cly42xZq6YqPzahQ75uzRn0Z8SrL2fm7BcoW8U6rBelZZylKM3fkQq0TkyszSKX6paXB6YdCBVNxF0cjoTJLStVhYnxsmfrq25fb+KzHyNZVevkNlR2V4hn1M0xbbd2z+u2QAn7ySxJyxo3b7B8PW+5eZ8ou44qKhZr85rcVdFMXKfQubKyolqTZatRfKYoUvQEBRquwBr53JfJ5AtJf1ao1Qv0e0cFeqKGtk932M2qW95LqBbcmZH7prqtLF8TLce+JiWLavWNtAKtghKE8onSLsNLydd4y018S9KXch5AkVibWvCqsjNbjVDgLNLUW/CBogjmsxXqpwq0uwJ9Vb6WVjFJpjeQyVhFRtUiat12CmrKyzpO0roZ7a0uuwtDFU9JOk1h4QC/Kx0JuMw5YFsweFvSI13je1S753KvgCJCeU6SJihdYnEFBys/p3SNY3Pz5OuyJhLKdEkHZag9X1LfTSUwW9Kbkh5UNMjPUKhfKNDhCrSfAu2iIDeZVKvwkaSzFeamKaxuW8rXgzWeIy9z2WEZuVilaBVwULzvuQXu00WO1KDJbWG5pfPEOJu7PFwbhRIrPI8rnd1+qPykXtiJB5Wva3ryk67FuThRgf6Qs/8Vjgxs1W17BXqp8Blrx00KNVKhrlU41+aU/ULStQr17Zy0DdVtAUUOY/+r8TyPSpmq0lLy9Z8CtrWqqrJ7gTy/eRnlURRFbItCnybp13F/wmjOzDsrN0WhhMv9bUoTyldlrwF8n0JrnVdzy1oKrmKGuhJQ76EgM3z8TUlbZ5yvQ75+rMDqiNcIzCDIfor8c05X2NTiTz2NjyXdoFBHKdAG8jMz7yW3NRXl862VVF+TtE/OpN4lZwwkcYbCXDUwULZkW93mzyCw38ffz7MrN0WhBKHYKvMNdwTO/U/qFDGztr0KBO+dkzjvSQUI6J8KtUTGOQfJ1x+bqB6YnsPmtoyiIMUzFeo+hb0+JeRpCnOLSJnbQEXF0epZnn9XXcmIXNtiynZCqwczJX2zAJEsKHe2+7+URFIb1M0HJU0oezqcdp6RPVeruW0tP9dQOkHSbxXqtYIDZZLyB+jKsrtA14pdCwzI5OYpStLzPQU6XaH+rVAPKTLgtducelcBJ62kBPZNBbpCoabXca6PFRlu885zsAKrSt0IJkvarMA1DpY7dcVlJZHUB3URSniMZcD9wDENnpcypYTqtoaya7fWixcl7ZwzYL+ixrLSf6ooCCwvALLoBF0pJtg9FeiHCvQrBTpbof6lUHcp1MdNujc2/D6HTDoUpbI8r4F+TFKkGuat/qwtX4/ntHWVQv1eYaFI8ipel7RGgWexlNzpMq4tiaQxKEEoh1gG3a4OleVlScsUeHiLyHemdmwUD0n6Ss75hyvQjQrrlg5mKlrmPU6Bhqk1TmpVwsnzKq4XDyhtG1tZUUnL6xpU0SYoCsobnHN9y6hYdr0DEy+JPB+mKu5JrPBkbavJd8ZM/bMkkuZA0jmSFErhfpY3/vYKrCLve8r3lK1uRxSwoyRxjUKtqWKV7q9SmOtgt5J8/aEJqzITJV2uUIcr0CbymyK5JN+arcJtCnVyHB9UVK3Mws0K9Y0C6syi8X0vkg/nP4mX2QiH3c7EnyxuDrZtG/nOZ//3kkiaC8U1jEMpPNUioWwq+7LxDBULDkRRQayiMRY/iducPx6MeZgj6UKFKQ9fcxsoX/+nINMpqhb4iiq4/UuhfqZA2ylwBi/mbYNbSCbNwERJpyrU8gWuZTH5OkVhTXaRQNHEtiXxMjFN0r4Fx91+Gbl4LiyJpDVQwih7hoVQ1pXdsU2KDKlFHuxCKubg5sd96FAkIhfFDElnKtTiBfqyuZpjrLVhiiJPzStjX5XvKdBmioy0iymtLvVTc93Hm4k7FVpLl7gkQFeC8WbheeWvtqFo2TvrRXRbSSSthSJCcaZ+HCK33nmTwsJRtXsXdIt/QarJEFfFdEUxJWbpVJco/n0FulZhjwUUBoo8LF+W9LDUq0IEpikyRv5AQSFbBPI1rAZifln5pWZd+EuBGJvqS8tVG2myoixuUkkkLYcSfij3WAhlKdlT2UnRW6PIBEaRC38tMR31YlQNLuIoilT98/+3d/5BcpRlHv+8s6GMSfglSUiQJBsNBJEci4clqFQWS0pAEIKgwnFmT9BS4byUqKDxRwKFZVn8iMf9YXmeJlJYiHoGEO60lJqkTgpBZVcwiSSQjXDRJEQT2JiA0/31j+ed2d6he6a7Zyb7I/2pemumdqa739nufvp9n/d5vo9CbT8IfRsr7JQN+c/PuCR+QYY4lJ2SPqZAJVV0bUaX+G5J707Zt25VEiOjt8lUBaVaZGthSDqNmogrTVFyFu9f1FwTpdq6ZDJ8ebwF9ynUzQr165TfL8uWe5uVvIi203z/0pTUGE8MyaQUblLYUAIgaST3SQX6fYbjvaRh4aNJyhas9uOU01ZkjtakkWy/hkckhSE5yCiSHLhd4SuW/w5TcsZwIOnTGZ5ypyi59k4S0WXhGzNcnLtlsn0LMt5EM2RxIv/uQ+rHpocjnt9K+k+FusrrsGT53dV2rgLdk/NXh7KSse9XoKdSbrNTyUW34trHGzyUygo1oBEqad2jfX8dcigiX7Bbio0nWNngAvuhkjVK4kYpn0pYho5js4bLFJyRa2xjSYyfUNC0AFNcO0JWX+eLsho7nQjQy8o+WYW5OxXqcwp0toJUOVVJ7WwF+g+FiY73TvE9ham1YWaocZLgf41cVVqtcZy050a7A63i//mrgKX7gXMI+QUa8Z134vgBJY6M2f5Z4HICfpHyePOAO+nirJTf7wdOAKam/H4SP0PcjViL2J1zH0cDp+KYDcwGZuGYBRwHHOvfT2+xn1XWAxsRmxAb/Ptn27Dfc3EswXEpjtdk2O4pYBUhn6XEnJzH3gRcneFauRDHtylxTMxne4C7ER8dvgVXOudW5OzamGDcG5MqMnGYpQBfQtxIOOLz+cCP6OLUuG2BOxDXE3Ig5fGuwHELJWa30Oc9wAbgTLKdiEeB/0X8mJDHWjh+Eq/FjE0WA/hn4I/A823uy1TMgLwXx4U4pmXcfgfwXgIexs7z53HcRCnTPvYCKwi5AxGk+P7hwO2UuCrhrD4BbEJchqMC+ybBlc65tZk6VdBZZEvHeyVpXYwf5VWKF6quslnSP2YYZk9VRTcpzL2UeKWfBr1BFd2cM6x+l2y6tlyBzlfQNDBurLdTVNG/+GjYdjiWn5BJSkyVqcRlOVd/k/T1Jhnh9a1XQcMyKt+J+EcCy7UsHK1jFdlKT82P0hPjJFuqwNaWYwhkDtBmgkvR1q186mq/0chC7llWIBqxU7Ya8hWFukKBTh4DRiKuLZBJJdyqUOulWK2adrBZyuRXCWUBffMz/JYpquiOBtfAXkn/NtI/UtY49o/EMWGmOVEU8aMAfApxa920Zx7wfbp4c8I+tgBXEvDLDMc9HbiBEpfgMv1jnwQ2I5Z0+HQ8BjyFeAbYgnga8TTwpw4e8zjgeGA+jhOBhThOwHEKMKXFfe8AfoD4KWII+Bmllv+D9yNuIGRDhm3eAtxNF90Jnz8M/ATxSZyOtHtujXOur8WujjkmpDGpIquzegcw7RHEeYTsqfvOF3DcmDCHDoGvIZYTsj/DcRcCn6HEB3FMytPxCC8BlxMyCViM4304ZrS4zzj+gN2cO5B/hZfrHNkADsdUYFqkHQFMwXF45G8vQ0v+pDScTsCv/fsFwCa66MqxnwAzSjcT8kSG7Y4AvkqJD+MSvTC3EfImHL04Ahjqgn91zq3O0c2C0UZSt/y0Z0hSb8y05zTFK+BX2ZqwXbN2vKyYeCvD9xc0shh63mXmicgahTpPgW7LKZa0T5bWkCY5sL5dqUA7G+z7cZlWS2Ra068ifmRiIC9lIEk3J0TN3tLECXqfQp2Y48I7WhUtz6AlWs/Lkh6SVe1rlLW6UVa4eryzXZaZvVCWEBenzt4KO2VVHdNGrkbbQsWLPEf58ivD+FeM9vVf0GYkXSy/2vOYwljnbI8a10WpyDz8eQLJJquijyhoOArKS79U0854vSq1HI/xyLWR8zJN2aOPk9gkk9ZMk4xX346R1bFupGOyXlbfuDoa8dGsxWrNREU27SlXL4DbE5S4bmgS7TokaXkKKcC4VpIVh/qWwsRVpay8INOGrd4o728wxvqmTJKxLOWaHuTlIYU6268uHaXkhLc/yqQaftKGTOlAJlPwHjUvHZq0SrNcQUPFtz0ybdkfFaORQxNFYlL2yopd119Ic1WpJV8lsUPSNUpX1yVptPI+Bbq/yVMvLQdkSv1JZU83aKRM4rsaGJ2PKNAVCvQlBTXpwDhuVVgrbH6SKokZzdGyEtNV0aaUvykPz8l0bObkPC9dMqGqPzU5zncVamkxGimQ5fbUfCnlhKnP+SkSwLZI+kDOp1/0BrtGgR7Oewel4G+y0hIXyuoPJ2mfBtII2cdJSnb81tcOSlKs2yLpFoVap/yaIY3YLXPKXuClBPKcg8NkhbyeaXKsQUkfU1jvG1k12tf0aDKhl4bTInuSrAIWg+VwrEQjlpEPA67FsZIShzfYVz9wPSE/jVlWzcJ8LGT/g5Q4saU95edR4EEfn7MQx+UJl8sOLPcGYCouMXanEzwOPIh4gJBfQl00UXomA1fhuIESxzf43gvANwmZgeOfh/8f24A+51w55+ELJhqyqc8Lks2D46Y+01WpaXM24klJV+d09tW3BTK19nsU5l4RmijskSmtfUhB08L1adpRquizKaYzf5UVZ4su9/pw+L7Rvm4Lxiiqm/qsT5j6zJWFTzdTNt8lEzqe1YYLH5k+66mq6DoFeqCNDtyxyn7ZKslNCnWW92W04/+4SBV9I8X5kywW5RMj/SJDMpHzCRUOX9AhZDk+tVWfssLYwLWZqujLal7f5WVZvsc7W/Sr1LdJquhM2YrDz1PeHGOZ/5fF81yvQG9TJZPyXBp/yGUKhk9qA16UrSgtUVCvKzyuNUc6SeEzaYJsGLsCS+ehjFiJKNf5RI4ArsFxXYJ+RZRtwLcJ+VabND6iTAJOBN6I4xQcb/TvT4BcoeadYgjTGNmI6EcMAL9C/KUDxzodWEqJf8JxdJPv7gJu92H11/kweM86zC8y2IEuTggKY5KSOKOyCnFvnVGZDPR5R968JvsMMdGj7yJ+6JPVOsVhwBygG0c3lnjXjSXhTfP5NlOg9po1Ce8A8CJmJIb89tFcn+2IrVQTDO2m7SRzgA/guDqlA/sZ4BZCtgPLRhqRAWBZ4VxtTmFMMiKpFzMqiwEGMeGcNXVGpQu4FMdySixKsd+XMMGje7yB2tfOTufAMWxUooZmMrCfkYbjRfKvorSTBcAlOC6hxFtSbvN/wDcIKQErKEUzf7cBK4qkvPQUxiQnaY0KwNl+GfFyHJNT7PsAttz5oJ9OPd22Xk8sJgFnAOdS4iIva5CW/0bchViEYxmOiBNkHWZEym3t7CFAYUxaxBuVZcBFYEZlNWINYrDOsBwOXIajj1JqDVmA54B13rCUEVva0vPxyUnAOTjOwfEOPz1Ly2+BuwjZCpyPo2/k5b8GMyKD7evtoUVhTNqELL18BV6QCcyvstpPW+p1VOYCH6LEEhz/kPFY24H1iHW+bWyl42OYV2PO0zNxnInjrThmZtzHduBOxF1eV6Qv4g8J4cUS3Aascs7Vn6KCjBTGpM14o9LnW80Hu9ory9c7bMHElC7FcSkl8iR17MKMyyPesGz0zs7WYnAPLjOARTgW+ddTcfRALnGp3wH3Iu4jZBaOi32LTGUGMAOyug1dL/AUxqSD+ClQn+ASZ7Mc9gCrCVkD9Mfc7vOwqdB5fhifl/3A7xkuN7ENU1PbhvgDUMm95/zMxNIE5uN4nX99PXAyjmNb3Pd64D5Cvo84Ld6AgE1lVhf+kM5QGJODgA9yuhjzrdSqbQxCbXm53r8CJn/4DhzvwnEBjrlt6k+I6b5uBZ5HPA++2ftdwF7EXyG2xXE0w7V4ZmN+jZnATP86C1uebhdDwAOI+xH/gzgr2YDcC6wF1hZTmc5SGJODjJ8GLcOMS20a1F9zsJqzNe6qX4gZlzNwvN0/3Q8VDmCJh494AemfIy5KNiADWOJmYUAOIoUxGUW8YbnYt8XRz9IYl2OBXm9YTveO3FYV38cKvwEeRzyK+JVX1F+MowdHL0SDyqqsY3gEMnhQO1sAFMZkzBCZCvUCS7AI/RpV47IWMy5JzAbegGMhJhtwMjAHx0md6ngL7Mamek8hNiCeBH6H2IxF6i4GejDD0VN3qYbwbAkewgxIuRiBjD6FMRmjeOdttS2u/7zsc1oGcfR7B2uc3yXKa7Al6bk45gDH4ZgOHANMx3GMf9+OEhVbMd/LTsRO//45xKDv5yDU0geOwmogd2OGo9e/j+FeoIwZj/42dLOgjRTGZJwgE3DqpfqwJj71p9/fqP0M37QDCdOkZhyJTZteHXmdDOxjOJR+CBMMakY3jnlAj/dv9GBGJGa6UmXA/4x+CuMxLiiMyTjFT4t6GTYu9oBvQDXTuRzzWX+MwYkzQtVRRD09r3SC1jpVP0WJYQBqNrBcLN2OTwpjMsHwTt1uzMhEX5slMXeaASzMpuxf+4HBwlk6cfg7kS1fp9DvzRAAAAAASUVORK5CYII=";
 主要按钮();
 return true;
 }});
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(悬浮窗==0){
 悬浮窗++;
 窗口N.dismiss();
 logo="iVBORw0KGgoAAAANSUhEUgAAAC8AAAAvCAYAAABzJ5OsAAAABHNCSVQICAgIfAhkiAAAFlVJREFUaIGtenuQFfW17tfd+/3ee57Mk4EjAwxIVNBjeAVuiAKhEBPxGM25iZbJ1ZxKyvL6SAUS7i0rmkRLSkrF5FSOGsVELeIxKgfBQkaFIQyK4vAYZoaZ2cxzz3707u7du5/f/QNnm5jERM9dVV27967e3d9v/db6fmt9vxbw37WzZ/2H6+oWp/z+FUFBWBgUhGbYdgtctwUkhtNpJBIJSKHQ21IwmFbJDzOOc3DFm292Y+1aE4LAz/to4XP9i5TeyOWuaPZ4/q02ElnqlkotWrEIQ9chSRIikQjC4TA8Hg+8Xi8AwLZtaJoGwzRhui5cj6dghMO/Pa/rz6xOJo9AEOzPO4h/zLZtE9/O5dYOFotvFctlOo5DXddpWRZd16XruvykZbNZKopCTdOoaRpd16Vt2zRNk47jMKcqHJDlt97J5dbj+eelzwLnH/b83qmpuRcFgw/WiOJ6nyhCFEVIkoR0Og1BEGDbNsrlMlzXRTgcRiKRQDgchiiK0HUdmqZBVVXEYjEYhgHbtmFZFtpmz4Ku6yiZJmRBfHVAku5cG4ud+f8G/oSi3NYWCv00QCYMw6g83HVd1NXVVa4jWQHlui4EQUA4HIbrunBdF4qiIJlMwrKsSjiNjI3CsiwIgoBgMAj6fIVhCP92eSy26+/lw6eDJ4VzlvVoo8dzm0TCcRwAgMfjgSAIcF0XpVIJhUIBuq6DJLLZLHp6enDixAmMj49j3759qK+vx6JFi9Dc3IylS5cilUqhra0N0WgUktcDv98Pj+S58EgQtusibVrP/VMgcBMEwf3s4LdtE/vvvvuZBkG4wTRNOI4Dv9+PUCgEABgfH8fo6Ch6e3vR2dmJgwcPIp1Oo1QqQRRFNDY2oq2tDY2NjRgeHsbIyAj6+/sxa9YsxGIxdHR0oKqqCt++5WY0NDSgqqoKlmVB13UAgM/nw6jr7poTjnzz0wbwVwfVXyo9a5omXddluVxmqVSiZVlUVZWdnZ287bbb2NraSkEQOHv2bN5zzz08efIkSVLTNI6Pj7NQKFDXdcqyTJJUFIW2bfPFF1/kDTfcwFgsxmg8xpv+9Zt8dc9rHB0fY6ms03JsGpZJWSmyX1WfBfmPJ3K/ae48c+YMTdOkZVmcmJggSXZ1dXHNmjX0er2MRCL85S9/yXK5TFmWmcvlKMsyNU2jqqqVo1gsUpZlqqpK27ZJkq7r0jRNlstl7ntjP2vr6wgB/OKypez64xH2DfTTJTk4PMSh9DDP2fbjIP9+fp5QlNtMx+GZM2coyzKPHTtG27a5b98+AmBNTQ0zmQxHR0f5wgsvMJ/PU5Zllj+iTsdxaJomp2dtGqyu68xms8xkMlRVtUKlmewUM9kp9p8bYMfCBQyEgly2Yjn3vbGflmMzV8hTM8r8rzNnvvepwP9DVeszqprXdZ1TU1NUFIXZbJYbNmxgR0cH77//fp44cYKmaXJiYoLlcpmZTIa5XI6aptEwDOq6XuF1y7Ko63qF1xVFYbFYZLlcpmEYVFWVA4Pn6NClSzJXyNOwTM6Z2845c9t54OCbdElqeonHej7Mv6Io8/4Ur1g5I4UrTPNhyTQTAFBVVYV0Oo1Vq1ZhZGQEN910E+699160t7ejs7MTsiwDAKLRKLxeb4UiBUGosJFlWSAJwzBgmiYkSUIoFILf74ckXQjjqakp9PX1YSo7hWKxCEVR8NJLL6G1tRXr1q3DxOQEAGBmQ0MiOTr6878a/3sHB9eOTU2xWCySJAuFAu+8805WV1dz9+7dHB8fZ09PD/v7+5nL5eg4DhVFoWmaLBQKzGQylYQ0TZPZbJbpdJqlUomqqlYSfvr60dFRDg0N0SUrx/D5NAeHh2jaFo+99y5r6mq59Sc/5vsnPqBL8mTfWR7Sil/9c+SkNFwqvVUsFivL90svvcTa2lr+/ve/Z39/P0n+WaxOD9KyLJZKJWqaVklIx3Goqirz+TyLxSJVVaWu65VcKJfL1HWduq6zUJT59DO/Yc+pkywUZepGmbpRZl4ucPh8mhe1z+FPH7if6ZHz1PQShxSlE93dXgDwAMBLuVx7TTK5zNY0CIKAkZERvPHGG6ipqcG8efOQSqVQLpeRz+chy3Llmh07dmDTpk2QJAmCIMBxHJBEPB7H7Nmz0dLSAtu2QRK6rsMwDITDYYRCIaiqipGREWz7v/8HXq8XDzzwAGKxGLoOH8au557DV7/6VdTW1uLyyy/HwYMHMXfuXFyz8RrEy/ryPXNmXbEWeBsA8GZf3xOqqjKbzdKyLB48eJDr1q3jT37yE2qaxnK5zGPHjtFxHO7fv5+RSIRtbW2srq6mKIoMhUIMh8MUBIGiKPLiiy/mfffdx+7ubpbL5cpsKIpCWZZ54sQJ3nHHHQyHw5w7fx5nNDbQ6/exqqaarW0zGQgF2bFwAY8c/SNPnj7FxZcv4c8f/AU1vUSX5NGxscexbZsI9PT4eifHCjYdTslZnjs/yG9/52bOap/NgiZTt8vMqwU+/dxvuPjKJYQEBmMheoJe+sJ+igIoAGxsqOfsWTN56lQPH374IQoCaNsmC8U8Hdp06fAPr77MgcF+QgD/x9Vf5qbN1zKSijEYDzOUiNAb9tMb9rPln2Zy5Ze/RIhg77mzvP6mf2GyKsH3TxynS4ejcr6AdDoovpIIL05EwnHd0BGJRBAKhZBOp9He3g6Px4PTp09j7969+Ncbv4l8Po9lK5bD5/MhmUzC7/cjHA4hlUpgdHQcHR0dSCaTWLduHRYtuhjd3d0YGxuDpmnQShrq6urg9/tRV1+LFStWYOvWrTAMA7qiAQAcx0EqlcLy5ctxzz33IBKP4vTp0wiHwyiVSohEInBcBx668d2SdJnoc9xL4oEQSooKn+hBNBTGub5+fHHJFfAJEr7QsRAPPfBzrFy2DHv/8CpCHh98ECFnslBzRYQDQRRyBQR9XjTWz0BmchL33H03HNuGKAiora6BWlQQCYURj8YQCYVRLulYuWw5mmY0IBGKIBaJIBGKIOTxQcvLSIajmNXcCjWvYEZ1LdZ8aTUCPj/i0RjgEoJlo8q1V4ohx10ufZRsACBJErLZLBYtWgTXdTE6OgpVVaHrOjweD44cOYKpqRw6OjqQSiWQmcri4oULcNlll+HcuXPYuXMnMpkMbr75ZrS0tCCVSl3wvKYhGo3Csiwkk0kEg0Hce++9yGSy8Pv9KBQKcBwHjuNAkiRMTU1h1aqVWLBgATZu3Ij58+dDkqRKJVsbCneIiVCoia6DSCgM13EguIQEAS0NjXBNCxFfAP/18itQMzlsufNutNU3Yt7MNmQGz0PLFRD0+XD65CkcPtyFUz0nEfT4sOLKpVi5bDkS0Rgcw0RVPIGhwUGkkknQdfHtb30LIX8Abx/sREt1DS5qbEHCH4KjG/BYLp779VNYv+Yq9H54EgF/AP1nenGk6wi2P/wwHNtGY0MDggJaPJFAAKVSCdFIBJZlASQkSYIkSZUyuKWtDVu3boVpmmhubsb4+Di6Dh2G1+tF2bURCARQV1eHVCqFtWvXYt68eUhWpeAPhVDM55GsroblOhAEAdFoFNdeey1mzJiBrVu3Yu9Lf4DrukhVVSGfz+NrX/saisUiSkYZW7ZswfmhIeTzeVx11VfQ2dmJu+66C7ZtIxrwLxCmdI1WoYD6ujrYtg04Lqqrq7F/z17MmzcPZ06fxuDgIEJeP66++mq8sfd1HDp0CCtWrMDExARyZQ0zZ87EnDlzEA6HEY/HEYjFsOs3T2Pz5s0giXK5DMMyEQgEKuF5/PhxLFu2DKXJHNLpNBLJJBzHQXP7HJw6fhzHP3gfN9xwAzJTUxgYGMDY5ARuvvlmZLJTIInJkgaPJAhQymWYpvlRjeJA1UpQVRWO41SaiaeeegqHDh3CZYu+gFOnTiGdTkNRFMTqa/DWW2/h1ltvha7rWLt+Pc729OCdd97Bhg0b4PV68corrwCigE2bNuH06dNYvHgxdu7ciWAwiPbGVpw7dw7uwACCwSAOdB5EKBSCrusYGhpCVXU1UqkUrlixHNddfz0knw+uZQGuC4/tuGhtbQVIaJoGj3ChVhscHERHRwfy+Tw8Hg9WrVqFBx98EA21dfjhD3+IF154Addddx2a5szG3r174fV6sWjRImQzGciyjJMnTyKdTiMSieCxxx5DNp9DPB7HVVddheeffx6LFi3C8PAwLmvvgG3bePW115DL5RBLJhAIBGC7Dt555x384sEH0dDQgJdefBFNDQ2gbcNxHARCIXj8fh8URYFHkhCJRgECdbU1OHr0KDZs2IDa2loMDAyguroamzZtQlVVFRoaGnDttdeioaEB4ZoUvvvd76K7uxuBQADj4+NIp9Nobm7Gjh078N5772HGjBn45y9eiWPHjuHAgQPo7u7G6tWr8fXrr4cxmUMymcRFF12EQqEA0esBSbggRFFENptFS0sLrrjiCmQ+coxlWSj7/UVPyXXeifq8Sx3rgnRRlGVcfuU/41RfL3zhIBzLRtPMVjiGiaa2ViSTScTqqjE7Gka0pga6piAYjaK6rha+YACxZAKbNl+HhZd+AUNDQ/jyV9Zg4cKFgCTi3Xffha7raJ8/D3PmzIGiFBEOB9E0aybEoB8kEQgELtSK4oXSmh4R8EqAV0LJshBLJgAAQ3LhA0/RNNNVwSAM5wJ/5nI5rF69Gr/a+QRyuRwSsTgikQiqm5KIxWIVecPn8wGGgampKXhlGfX19XBdF9lsFlW1tWhpacGsWbMgfiRxQABqa2vh8VxQC0iir68Pc1svNOQerxfRaBTJZBKQJLiuA9d10X9uAP5QCJ1/eBkNDfUol8sAAEvypEXD6zmhmwZcEMlUCvWNDbjs8iXIFWX89sUXEK+pQqGkwp+IggEvilYZqmPCXxXHUGYM/mAA9c1NSNbWQNNL6Dp2FE/86gmcONmD4ZHzOP7+cbz/wfvI5XLw+f0ggMlMBiWjjLqGGSiLhBgJIlSVgDcWhuURYNCGZhlQDB3tHfORy+fwoy1bML+jA2XDQCgchuP19ogZxzlIjweiKMKyLUiShLa2NsybNw9PPvkkstksmpubYVkW+vr6wE/oN16vFyBhlErYvXs3fve732F4eBjZbBbV1dVoaGhAU1NTpQQOBALw+S7kmd/vh2VZCAQCSCQSCAaDcByn0pEFAgHIsoyuri5omobvfOc7KJVKmMzl0K/pB8XVwWg3RUmGJGIyO4WCUkQoGsG3br0FJcvAjp2PIVVTA0cSoFkGgvEoVLOMbLGAcDKOZE01SnoJ/nAIPadPYSqbxXWbN2Myk4EgigiGQ0ikkogl4hA9EgRJRDgaQTAShgOi7Now4cKEC4MObBGAzwNP0A9P0A/dNvHEr/8diy75Ar78lTVIVVchmEgUNxjGMRGCYAwoym9d10U0GkUoFILrurjmmmuwfPlybN++HWMTY/D7/Whvb4fjOFBVFZFIBAAw8ZH4BFwQiqqqqjB//nzs2bMH27dvR29vL0ZHRxGPxTGrbRZM04TrukjGk5AkCalkCsFg8KOGjvB6vfD7LuSEpmkoFot49dVXsWbNGsRjcRiGgTydXWhqMgAArxdzS/OWQtVSqNkqNVtlydJYsjQGYwF+69b/SZsW82qOslKgpqv8Y/cRarrKUknl0aNHuG/fXv7sZ/fz8ccfpevazGQmeNFFs/m9793GiYkxWpbBQiFHx7Go6xp1XaNlGewbGeTRD9+jQYfnxtPMKnkatHiy7zQf2vEw65tn8H//8C6e7j1FhzYVo8Q9udyyShv4lWjyyIBRfKdWEpeShCB8rO88/vjjuP3223HJJZfgxhtvRDwWx9j4GBobG9HV1YVdzzyLkZERrF69GitXrkR9fT1KpRI0TcPGjRuhqirOnz9f0eunBVjygoZaXV2N5oZmdL/XjdbWVhw/fhypVApbtmzBgQMH8O+/+hWampoQDAahKAoMn//ttQMDRz6WPgTBHnWcn9r8S1F2/fr1iMfj2L9/P3bv3o3zI+fx7rvvwuPxYGBgAJs3b8Y3vvENrF+/HosXL8aMGTPgOA5aW1tx9913wzAMnDhxArIsQxRFuK5b6XlFUUSxWEQml0EwGERNqgZnz57Fxo0bMTExgbfffhvXff06LFmyBKlUCg6AXtP+GRYvtj4GD2BZKLl3yuVr07E37ZlEPIFHHnkEmqbh+9//Ph577DEcPnwYruuiubkZixcvxjXXXIP58+fDMAzkcjlomlbRaVzXRW9vL1RVrThEFMXK7I6OjsLn86Fjbgce2v4Qdu3aBZ/Ph+3bt6O+vh56WYfruggGg7BCoVeXR6N7pu/jqdxREJz+YvHOuN9ZGhSl+PQgJjOT2LRxE7LZLCRJwuuvvw7HcXDLLbfg0ksvrQzSMAwUi8VKeEwftbW1FS9P06soihUHXXbxJXj5lZdx33334b3uY/jZg7/A5s2bUVtTg0wmAycQgOu6KIPyrqL+XVRXO38RHtPWXZZvl80iNVOlZqrsGzrLgXQ/y45OmxYXXXIxG5pmsLfvDF06nJwcpyznqSgyx8ZGaFkGy+US8/ks+/vP8umnn+RTT/0HJybGqCgySYeua7NcLtGyDA6PnydEEF6Bv37mSU4Vc7To8HT/GWaLORquSd0u87Ch3/hJrJ5P/rA4EH/sZLmwsEUQ/hcA1NXVYXh4GCShaAps28btt9+OZDIJly4eeOABLFiwACtWrMDMmTMhSRK6urrQ2dmJs2fP4gc/+AEkSUI8HoeiKBeaaMepzMbIyAiWfWkF9uzZg4AvgLN9vfB6PEgkEpX6f4zCzit9gef+psf/zEipV83tUg2FBw+9SZsWNVPl3T+6i00tjSwU8xybGK1Q5Rtv7OOjj+7gj3+8hXfc8QNu3vx1PvLIdk5NTXJ8fLRCkcPDgyQdGoZOyzJIOnz7j4fojwaZVfJUDI0jk6O06XB4LE2LNs+U5F0XNJrPYqRwqlR4LlOY5LnzA7Rp8eoNV3HJFYs5PjlGTVdZKOZpmmXKcp7Dw4M8efJDnjrVw/Pnh5nLTbFQyNE0yzQMvQLYcSy6rk3HsWjbJve9uZ+RZJTnzg9yWjvS7TIt2hzUlWempb2/Zn8RNhUTBM4jbzrn02nJ8g1qSUU2m8Xy5csRj8chCAJkWUY0/PGeaygUAkn4fD74/f7KvtXH/viYxabPI5FIRUkGLiQ0RRH9pvnzuV3dP8KqVX9zf/bTp0MQnDZP6MY+r/emrKrIIyMjldZuWsK2bRuiKCIUCiGRSCAajVaAT9PhJwH/6VGTqgIcF1pRAejCkkT5mF7eMNcXvPfTgP998B85bF3DzGePOu6VY7b92qVLllRqaq/XW6kCp0XW6dVz+vcLPhAqn396DgDJZBK2bSMryxgxjGd/64jzl4djr/x3tvX/uh044DmiaesHirm3SrbBicx4hRp1XWO5XKrEt65rLJXUyve/FfOKUSJm1O664+C+hZ9p4wyf992D7m7vwflzloRk9Ztza6pvgGXFhY/ob3rpnw6V6QVp2uuiKMICoNNN52z3tWMl/dHNyeSpz/PuwecDP23btolYudK377JFi6sFcWVC8nT4IbT46C4FAEkQ4IpC0XTxgQsIjsBhGULPWdv9z2unpvrw1FMmtm37THusf2r/D+pMUj/MnI5WAAAAAElFTkSuQmCC";
 
 主要按钮();
 }
 if(悬浮窗==1){
 悬浮窗++;
 窗口N.dismiss();
 logo="iVBORw0KGgoAAAANSUhEUgAAAC8AAAAvCAYAAABzJ5OsAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAWSklEQVRo3rV6e5BV5ZXvb+993u9z+vSDftIw0kCDHaWRMdAQuCEKhEJMxCGamUTL5GqmkrK8oqlAwtyyokm0pKRUTKYyahQTtQjXiAwChd3yaEKjaNs8mn6ffp/nPvv9+tb8AX10vImZmJlVtevss2ufs3/f+tb6fWv9vs3hb7XLl72nKitbE17vSj/HLfZzXB1sux6M1YMII6kUYrEYhEDguOD3p2Sij9KO077ynXe6sG6dCY6jz/to7nP9ikg4msstq3O5/rkiFFrOVLVeKRZhaBoEQUAoFEIwGITL5YLb7QYA2LYNRVFgmCZMxsBcroIRDP52VNNeWhOPnwbH2X+zIz/Tdu7kj+dy64aKxXeLuk6O45CmaWRZFjHGiDFGn7ZsNkuSJJGiKKQoCjHGyLZtMk2THMehnCzRgCi+eyKX24BXXxX+Rzx/KJOZf43f/3g5z2/w8Dx4nocgCEilUuA4DrZtQ9d1MMYQDAYRi8UQDAbB8zw0TYOiKJBlGZFIBIZhwLZtWJaFxrlzoGkaVNOEyPEHBgThgXWRyKX/NvDdknRvYyDwUx9RzDCM0sMZY6isrPxENFEJFGMMHMchGAyCMQbGGCRJQjweh2VZpXAamxiHZVngOA5+vx/k8RRGwP3zDZHI3r+UD58NnogbtKyna1yuewUiOI4DAHC5XOA4DowxqKqKQqEATdNARMhms+jp6UF3dzcmJydx+PBhVFVVoaWlBXV1dVi+fDkSiQQaGxsRDochuF3wer1wCa4rjwTBZgwp03rl73y+O8Fx7K8Hv3Mn379t20vVHLfVNE04jgOv14tAIAAAmJycxPj4OHp7e9HR0YH29nakUimoqgqe51FTU4PGxkbU1NRgZGQEY2Nj6O/vx5w5cxCJRNDc3IyysjJ8++67UF1djbKyMliWBU3TAAAejwfjjO2dFwx987MG8CcH1a+qL5umSYwx0nWdVFUly7JIlmXq6Oige++9lxoaGojjOJo7dy499NBDdP78eSIiUhSFJicnqVAokKZpJIoiERFJkkS2bdPrr79OW7dupUgkQuFohO78x2/SgYNv0fjkBKm6RpZjk2GZJEpF6pfll0H0X0/kftPcc+nSJTJNkyzLoqmpKSIi6uzspLVr15Lb7aZQKES//OUvSdd1EkWRcrkciaJIiqKQLMulo1gskiiKJMsy2bZNRESMMTJNk3Rdp8NHj1BFVSWBA31xxXLq/ONp6hvoJ0ZEQyPDNJwaoUHbfhZEfzk/uyXpXtNx6NKlSySKIp09e5Zs26bDhw8TACovL6d0Ok3j4+P02muvUT6fJ1EUSb9KnY7jkGmaNDNrM2A1TaNsNkvpdJpkWS5RaTqboXQ2Q/2DA9S8eBH5An5asbKNDh89QpZjU66QJ8XQ6d8vXfreZwL/N1muSstyXtM0ymQyJEkSZbNZ2rhxIzU3N9Ojjz5K3d3dZJomTU1Nka7rlE6nKZfLkaIoZBgGaZpW4nXLskjTtBKvS5JExWKRdF0nwzBIlmUaGBokhxgxIsoV8mRYJs2b30Tz5jfRsfZ3iBGRoql0tuej/JuStOCTePlPMssy03xSMM0YAJSVlSGVSmH16tUYGxvDnXfeiYcffhhNTU3o6OiAKIoAgHA4DLfbXaJIjuNKbGRZFogIhmHANE0IgoBAIACv1wtBuBLGmUwGfX19yGQzKBaLkCQJ+/fvR0NDA9avX4+p6SkAwOzq6lh8fPznfzL+Dw0NrZvIZKhYLBIRUaFQoAceeICSySTt27ePJicnqaenh/r7+ymXy5HjOCRJEpmmSYVCgdLpdCkhTdOkbDZLqVSKVFUlWZZLCT9z//j4OA0PDxMjKh0joykaGhkm07bo7PvvUXllBe34yY/pg+4PiRHR+b7LdFIpfvXTfC6MqOq7xWKxtHzv37+fKioq6Pe//z319/cTEf2nWJ0ZpGVZpKoqKYpSSkjHcUiWZcrn81QsFkmWZdI0rZQLuq6TpmmkaRoViiK9+NJvqOfCeSoURdIMnTRDp7xYoJHRFF3TNI9++tijlBobJUVTaViSOtDV5QYAFwDsz+WayuPxFbaigOM4jI2N4ejRoygvL8eCBQuQSCSg6zry+TxEUSzds3v3bmzevBmCIIDjODiOAyJCNBrF3LlzUV9fD9u2QUTQNA2GYSAYDCIQCECWZYyNjWHn//0XuN1uPPbYY4hEIug8dQp7X3kFX/3qV1FRUYEbbrgB7e3tmD9/Pm7ZdAuiutZ2cN6cZeuA4wCAd/r6npNlmbLZLFmWRe3t7bR+/Xr6yU9+QoqikK7rdPbsWXIch44cOUKhUIgaGxspmUwSz/MUCAQoGAwSx3HE8zxde+219Mgjj1BXVxfpul6aDUmSSBRF6u7upvvvv5+CwSDNX7iAZtVUk9vrobLyJDU0ziZfwE/NixfR6TN/pPMXL1DrDUvp54//ghRNJUZEZyYmnsXOnTzQ0+PpnZ4o2ORQRszS4OgQffs7d9GcprlUUETSbJ3ycoFefOU31HrjUoIA8kcC5PK7yRP0Es+BOIBqqqto7pzZdOFCDz355BPEcSDbNqlQzJNDNjFy6A8H3qCBoX4CB/pfN3+ZNm+5lUKJCPmjQQrEQuQOeskd9FL9382mVV/+EoEH9Q5eptvv/AeKl8Xog+5zxMihcTFfQCrl59+MBVtjoWBUMzSEQiEEAgGkUik0NTXB5XLh4sWLOHToEP7xjm8in89jxco2eDwexONxeL1eBIMBJBIxjI9Porm5GfF4HOvXr0dLy7Xo6urCxMQEFEWBoiqorKyE1+tFZVUFVq5ciR07dsAwDGiSAgBwHAeJRAJtbW146KGHEIqGcfHiRQSDQaiqilAoBIc5cBGL7hOEJbzHYddFfQGokgwP70I4EMRgXz++uHQZPJyALzQvxhOP/RyrVqzAoT8cQMDlgQc8xHQWcq6IoM+PQq4Av8eNmqpZSE9P46Ft2+DYNniOQ0WyHHJRQigQRDQcQSgQhK5qWLWiDbWzqhELhBAJhRALhBBweaDkRcSDYcypa4CclzArWYG1X1oDn8eLaDgCMAJn2Shj9io+4LA24WqyAYAgCMhms2hpaQFjDOPj45BlGZqmweVy4fTp08hkcmhubkYiEUM6k8W1ixdhyZIlGBwcxJ49e5BOp3HXXXehvr4eiUTiiucVBeFwGJZlIR6Pw+/34+GHH0Y6nYXX60WhUIDjOHAcB4IgIJPJYPXqVVi0aBE2bdqEhQsXQhCEUiVbEQg287FAoJaYg1AgCOY44BhBAIf66how00LI48O/v/Em5HQO2x/YhsaqGiyY3Yj00CiUXAF+jwcXz1/AqVOduNBzHn6XBytvXI5VK9oQC0fgGCbKojEMDw0hEY+DGMO3v/UtBLw+HG/vQH2yHNfU1CPmDcDRDLgshld+/QI2rL0JvR+dh8/rQ/+lXpzuPI1dTz4Jx7ZRU10NP4d6V8jng6qqCIdCsCwLIIIgCBAEoVQG1zc2YseOHTBNE3V1dZicnETnyVNwu93QmQ2fz4fKykokEgmsW7cOCxYsQLwsAW8ggGI+j3gyCYs54DgO4XAYt956K2bNmoUdO3bg0P4/gDGGRFkZ8vk8vva1r6FYLEI1dGzfvh2jw8PI5/O46aavoKOjAw8++CBs20bY513EZTSFrEIBVZWVsG0bcBiSySSOHDyEBQsW4NLFixgaGkLA7cXNN9+Mo4fexsmTJ7Fy5UpMTU0hpyuYPXs25s2bh2AwiGg0Cl8kgr2/eRFbtmwBEUHXdRiWCZ/PVwrPc+fOYcWKFVCnc0ilUojF43AcB3VN83Dh3Dmc+/ADbN26FelMBgMDA5iYnsJdd92FdDYDIsK0qsAlcBwkXYdpmldrFAeyokKWZTiOU2omXnjhBZw8eRJLWr6ACxcuIJVKQZIkRKrK8e677+Kee+6BpmlYt2EDLvf04MSJE9i4cSPcbjfefPNNgOewefNmXLx4Ea2trdizZw/8fj+aahowODgINjAAv9+PYx3tCAQC0DQNw8PDKEsmkUgksGxlG267/XYIHg+YZQGMwWU7DA0NDQARFEWBi7tSqw0NDaG5uRn5fB4ulwurV6/G448/juqKSvzwhz/Ea6+9httuuw218+bi0KFDcLvdaGlpQTadhiiKOH/+PFKpFEKhEJ555hlk8zlEo1HcdNNNePXVV9HS0oKRkREsaWqGbds48NZbyOVyiMRj8Pl8sJmDEydO4BePP47q6mrsf/111FZXg2wbjuPAFwjA5fV6IEkSXIKAUDgMEFBZUY4zZ85g48aNqKiowMDAAJLJJDZv3oyysjJUV1fj1ltvRXV1NYLlCXz3u99FV1cXfD4fJicnkUqlUFdXh927d+P999/HrFmz8PdfvBFnz57FsWPH0NXVhTVr1uDrt98OYzqHeDyOa665BoVCAbzbBSICA4HneWSzWdTX12PZsmVIX3WMZVnQvd6iS2XOibDHvdyxrkgXRVHEDTf+PS709cIT9MOxbNTOboBjmKhtbEA8HkekMom54SDC5eXQFAn+cBjJygp4/D5E4jFs3nIbFl//BQwPD+PLX1mLxYsXAwKP9957D5qmoWnhAsybNw+SVEQw6EftnNng/V4QEXw+35Vakb9SWpOLB9wC4BagWhYi8RgAYFgsfOgqmmaqzO+H4Vzhz1wuhzVr1uBXe55DLpdDLBJFKBRCsjaOSCRSkjc8Hg9gGMhkMnCLIqqqqsAYQzabRVlFBerr6zFnzhzwVyUOcEBFRQVcritqARGhr68P8xuuNOQutxvhcBjxeBwQBDDmgDGG/sEBeAMBdPzhDVRXV0HXdQCAJbhSvOF2dWumAQZCPJFAVU01ltywFLmiiN++/hqi5WUoqDK8sTDI50bR0iE7JrxlUQynJ+D1+1BVV4t4RTkUTUXn2TN47lfPoft8D0bGRnHug3P44MMPkMvl4PF6QQCm02moho7K6lnQeQIf8iNQFoM7EoTl4mCQDcUyIBkampoXIpfP4Ufbt2NhczN0w0AgGITjdvfwacdpJ5cLPM/Dsi0IgoDGxkYsWLAAzz//PLLZLOrq6mBZFvr6+kCf0m/cbjdABENVsW/fPvzud7/DyMgIstkskskkqqurUVtbWyqBfT4fPJ4reeb1emFZFnw+H2KxGPx+PxzHKXVkPp8Poiiis7MTiqLgO9/5DlRVxXQuh35Fa+fX+MNdxAsiBB7T2QwKUhGBcAjfuuduqJaB3XueQaK8HI7AQbEM+KNhyKaObLGAYDyKeHkSqqbCGwyg5+IFZLJZ3LZlC6bTaXA8D38wgFgijkgsCt4lgBN4BMMh+ENBOCDozIYJBhMMBjmweQAeF1x+L1x+LzTbxHO//le0XPcFfPkra5FIlsEfixU3GsZZHhxnDEjSbxljCIfDCAQCYIzhlltuQVtbG3bt2oWJqQl4vV40NTXBcRzIsoxQKAQAmLoqPs0IRWVlZVi4cCEOHjyIXbt2obe3F+Pj44hGopjTOAemaYIxhng0DkEQkIgn4Pf7rzZ0BLfbDa/nSk4oioJisYgDBw5g7dq1iEaiMAwDeXL2orbWAAC8Xcwtz1sSyZZEii2TYsukWgqplkL+iI++dc8/kU0W5eUciVKBFE2mP3adJkWTSVVlOnPmNB0+fIh+9rNH6dlnnybGbEqnp+iaa+bS9753L01NTZBlGVQo5MhxLNI0hTRNIcsyqG9siM589D4Z5NDgZIqyUp4Msuh830V6YveTVFU3i/7PDx+ki70XyCGbJEOlg7ncilIb+JVw/PSAUTxRIfDLiQgc97G+8+yzz+K+++7DddddhzvuuAPRSBQTkxOoqalBZ2cn9r70MsbGxrBmzRqsWrUKVVVVUFUViqJg06ZNkGUZo6OjJb1+RoAluqKhJpNJ1FXXoev9LjQ0NODcuXNIJBLYvn07jh07hn/91a9QW1sLv98PSZJgeLzH1w0MnP5Y+uA4e9xxfmrT/y/KbtiwAdFoFEeOHMG+ffswOjaK9957Dy6XCwMDA9iyZQu+8Y1vYMOGDWhtbcWsWbPgOA4aGhqwbds2GIaB7u5uiKIInufBGCv1vDzPo1gsIp1Lw+/3ozxRjsuXL2PTpk2YmprC8ePHcdvXb8PSpUuRSCTgAOg17Z+htdX6T7rNikD8UIbRWzOxN+OZWDSGp556Coqi4Pvf/z6eeeYZnDp1Cowx1NXVobW1FbfccgsWLlwIwzCQy+WgKEpJp2GMobe3F7IsfywW8XxpdsfHx+HxeNA8vxlP7HoCe/fuhcfjwa5du1BVVQVN18AYg9/vhxUIHGgLhw/O/I/rY2mVc/qLxQeiXme5nxeiM4OYTk9j86bNyGazEAQBb7/9NhzHwd13343rr7++NEjDMFAsFkvhMXNUVFSUvDxDrzzPlxy05Nrr8Mabb+CRRx7B+11n8bPHf4EtW7agorwc6XQajs8Hxhh0kLi3qH0XyaTzZyW/Ll28TzSLpJgyKaZMfcOXaSDVT7qjkU0WtVx3LVXXzqLevkvEyKHp6UkSxTxJkkgTE2NkWQbpukr5fJb6+y/Tiy8+Ty+88G80NTVBkiQSkUOM2aTrKlmWQSOTowQeBDdHv37pecoUc2SRQxf7L1G2mCODmaTZOp0ytDs+jdX16Qutvugz5/XC4nqO+98AUFlZiZGRERARJEWCbdu47777EI/HwYjhsccew6JFi7By5UrMnj0bgiCgs7MTHR0duHz5Mn7wgx9AEAREo1FIknSliXac0myMjY1hxZdW4uDBg/B5fLjc1wu3y4VYLFaq/yeI23Ojx/fKX1SJZxS0Xjm3VzYkaj/5DtlkkWLKtO1HD1JtfQ0VinmamBovUeXRo4fp6ad3049/vJ3uv/8HtGXL1+mpp3ZRJjNNk5PjJYocGRkiIocMQyPLMojIoeN/PEnesJ+yUp4kQ6Gx6XGyyaGRiRRZZNMlVdx7RaP5a4yIu6AWXkkXpmlwdIBssujmjTfR0mWtNDk9QYomU6GYJ9PUSRTzNDIyROfPf0QXLvTQ6OgI5XIZKhRyZJo6GYZWAuw4FjFmk+NYZNsmHX7nCIXiYRocHaIZ7UizdbLIpiFNemlG2vtT5vqz4DmOFhDdOejRyBLFrbIqI5vNoq2tDdFoFBzHQRRFhIMf77kGAgEQETweD7xeb2nf6mN/fMxiM+ehUKikJM8kNPE8+k3z5/M7u36E1av/7P7sZ08HxzmNrsAdfW73nVlZEsfGxkqt3YyEbds2eJ5HIBBALBZDOBwuAZ+hw08D/uRRnigDHAalKAHEYAm8eFbTN873+B/+LOB/GfxVh62vnv3yGYfdOGHbb12/dGmppna73aUqcEZknVk9Z65f8QFX+vzkOQDE43HYto2sKGLMMF7+rcMvbAtG3vxbtvX/tB075jqtKBsGirl3VdugqfRkiRo1TSFdV0vxrWkKqapc+v7nYl4yVMKsir33tx9e/FdtnH3udw+6utztC+ctDYjyN+eXJ7fCsqLcVfqbWfpnQmVmQZrxOs/zsABoxFI5m711VtWe3hKPX/g87x58PvAztnMnj1WrPIeXtLQmOX5VTHA1e8HVe4gtBwCB48B4rmgyfMgAzuFoRATXc9lm/+/WTKYPL7xgYufOv2qP9ZP2H+pMUj9Yhfm5AAAAAElFTkSuQmCC"; 
 主要按钮();
 }
 if(悬浮窗==2){
 悬浮窗++;
 窗口N.dismiss();
 logo="iVBORw0KGgoAAAANSUhEUgAAACwAAAAtCAYAAADV2ImkAAAABHNCSVQICAgIfAhkiAAAEKRJREFUWIW1mWtsXMd1x39z33v3xeXukubyYUoWJcsWZTtWYbuyHb+KwA7Qoi3SFE0f+dDEiZ18LloUrZA2KYJ8KJLUbtC0aVPAAYoU/dCkdtoAsp1YkhVFki3rYUqkKJErisvXksvdu/c9/XC5N5TixI+iAwyw2Ln3zn/OnDn//zkj+IBNguCTj5h88Z9/E027O9LMO2OhFhTTeEgIAUJALIkC74yI45biOUcVz32VQx85zL9c8QXEH3Tu9wf0kUc0OT/9pFxrvCDdznoc+DKOIhnH8Q19e4uiSHqeJ7vtTemurzXDlcUX5JXzT8lP36v//wEFIa9MPSk3mz+KfU9GUSTDMJTv1rrdbto9z5NhGCYLCgIpNzd+1Dl36kl5COW94hDvCeyR/xiQex/8VpwtfDSUEMfJbiqKgmma+L5Pp9PB8zyiKCKOY8IwJAxDNE1DCIEQyVRCCDRNwzAMdF3HNk1ke/37xtlTnxKPfnTx/wzYnT735IZuf2fDC/riOMa2bbLZLJqmIaWk1WqxtrZGo9Gg1Wrh+z6+7+M4Dq7rous/23UhBJlMhmq1yujoKJVKhXw+j2ma6HG4HjVmPmHdds+LHxjw7MmjT19aXPvGtaVlGo0GiqIwNDTE4OAgpmkShiH1ep2NjQ2azSau6yKlJI5jXNel2+0ipURVVVRVTa2bz+cpl8sUCgUqlQrj4+OMjo6iSklwffbZyr4Dz79vwP/97X985krHe252bh7HcfA8D1VVyefzFItFLMtCURSiKEJKmbpHJpNB0zSiKCIIAmzbTt3B933a7TbNZpP19XUcx2F0dJQdO3YwPDxMFEWsLS9jNJee/fXPfP4dQb8j4O9/8+8++/K56ednrlxh//79lMtl+vv7EULQbrdTILlcDtM0sW2bUqlEX18fuVwudZeeL/daz/Krq6s0Gg2azSbtdhtd1+l2u1y7do2lpSXiKGJnRnvmC//47b9/V8Df+9uvPPCtw68c9SLJQw89xIMPPkitVkPX9dTCvu/jui6FQgHbtlO/1XUdy7IIw5AoirAsiziOieMYXdeJooh2u41pmmiaRqvVotFo0Ol0mJ+fZ25uDs/zkl1Ckl9bOPgHh7589BcCPvW1L1VfXOpcvDg337d7924efvhhRkdHqdfrzM/PUyqVuOeee6hUKvi+n74npQSSqKFpGgBBEBBFUTpumia6rqfP9lwkjmM2NzdZX18HwDTN1P+1OLwyePHN+wd/71ON3jvadsDnY/2vVjtO34EDBzh48CCjo6PMzMxw+PBhpqam2L9/P7VajWw2m26xoiQh1DAMhBDEcYxhGKiqSrvdxjAM4jjG8zzCMEwtDWBZFlJKwjBECIFt2wRBkLrGwMDA+O2PfuSQhGcESOBnAfvkvz6398LC0tNhGFKr1VBVlVOnTvHqq68yPT2NrutUKhVM0ySKIhRFwTAMoijC932CIEj9tgdo+2KAFHQYhnS7XXzfTyOJEIJOp8P09DTHjh3j6NGjvPHGG9Q3u5/ZPH30gRssLEH8qDT0FS+e5dq1a7z88su8/vrrzM7OYlkWo6OjTE5OsmfPHorFIplMhjAMaTQarK+vo6oquVyOYrF4gwWjKLrhdxAEmKaZLsTzPHRdJ5vNYtt2ei7GxsbIZDIUCgXqiw3aSvysfOSRn4hXXglVgENvHdsbD4x9dX5hgePHj3P8+HFmZ2dxHIe9e/fy6KOPct9995HP59F1HU3TuHr1KkeOHGFmZgbP8wiCAADbttE0jTAM011YXV1lfn6eZrOZ/q9pGrquoygKQggURUlDY7lcxrZtOp0OZ8+e5YeHX56cLWr/9tIb55c1gLhS+6QeKpRKJSqVCqurq4yNjXH//ffz+OOPc/vtt1MsFnFdF4C5uTlee+01Tpw4QbVapVKp4LoujUYjjRy9cLa4uMjx48e5fPky/f397Ny5k5GREQYGBlIf7na76YEUQlAul9nc3OTs2bPMzMzw05OncEdv+byEZzR5L/oG2sfr9TmCIGDPnj3UajXuvPNOnnjiCSYmJnAch5WVFSzLAuDNN9/k8OHD1Ot1JiYmGBkZQVEUms0mjuOkfh1FEceOHeMHP/gBy8vLHDhwgFqthu/7eJ6Xsp6UkkwmA4DjONi2TbVaJZ/PMzY2huM43Hn77icJLhka//ST3dc3OreeOv82F6YvM3nXPnbt2sWO28YRQtBVQiJLIaMl7DZ3dYGpq/NculJnZWWF2tAg5f4+uq6LqgrW1laoVPopl0tcvHiRqUtvc+TYawwODrLjtnGqgxXazibRasx4fpx6vImW0diItghJUQlCB902+NUPH2TH+BiaKigWi7ee++NDB5QlzfzwT0+d5tKlS+TzeXbv3s3evXupDdSoVqsoipJqAdd1abfbqQqLoojLly/jeR7FYhHbtpFSphbudrvMzs4SRRG1Wo2JiQnGxsbSA9ZsNhPfJZlD07Qbeu9AKorCwtISU9cWPqw5bvvBmUtv4bWWmNx9gLFb+skZQLhJZ2ODQqGA224ThglbjQ0WeeBDd9BarvOTuEP9+gKbToehkWH6uiXiOEbVNWIkmqHTbm2iKSrFfIG+QpFyqR/f9aDZhCBiZDUANe4xEOgClJAoiFBC6BsbZ8fIGG+cP8vpSzP7tOn6/Fij0aBarXLXXXfR39+fsJKqUiwWMTSDwAxQlCQ8DQwMcPfddxPHkmw2Sy5fTFmsXC6nerjdbqOqKhMTE2xsbGCaJhsbG7iuSy6XA0gISFESoL20KmGkVOXZfX1MTk7SaK5y+vL0qHb1+lzei7tMVgYYNzPkT0wTRRHCiTBdl9jzyKsqbiVPHMcEd4xRFoL99+5jeHwIzxP0lcvEAnLFAqqqpno4l8vx2GOPJVIyn8fOZJBxjJ3JoIskhMlMojUCEaOqKqGAmBg/Uohjg1C4lHYNc+vKbk6cev1BbaHR2K8oSnoq/flmwkxiK6vIZkFV0XUdx3FQgUajwbTfotVqkc2WWV5exs5k6Ovro1RK3KK90SKXyzExMUE+nydr2wwODpLJZDBNE48k9koZJewnEo0RqQnJIJRkzo5DPptnfHyc4ZERtE4Uotk2+WyBKIhpX19G0zSKjXaqwACu5xWklFT2jrOytMqb16dptVoErkRKSV++gK7r9JdKSdBvbZLJZBisDuC6LvEW08VByFCthqkbhGGIbDaJPI9ACBTTJDITpoxME82y0EwdgUJ/X4k9E7ejNRYXiXUz1QFBEKBpGophYBUK4Hmgqphmom171GrbNuVymYsXLlMqlSgViqysrNBoNMjlcjRXVgnDkCuXZ/E8D0UILMvirn2TFAoFshk7mc91cV0Xf4uuQ5EYQG4ZytRMAgJUVaU2PITWb5VZ2ezQUBXG+0tkf/sJ8vk8nu8hpUzFdWbL51qej37rGLuz2UT07JBUq1UGK1UuXLjA4MAA5XKZ148cpVqtYhkmU1NTjI2O4vs+9Xo9IZh2hzNnzvD49AabV68SFbNshCFOKSGNTinL4J13EuVCVE3DUAzGS9WWNlQtH9n0w4NBEGAYBlnTSCWfZVlpaqTpSZarBGEqI33fR1VVLMvCMAwsyyKfz1MoFCiXy4yMjGBoOuvr6/T39yca2U+spes6fX19oGwmtKyqaaqVtiBANQpgGGRUhWIuf0YbH9kxN7vcOXi1scriepvh0SEkkvXIxbY0fCVGCIGlGgSKhshoGIV+1NU2HadF4HqYmo6h65hbOtjzkt3JZrPYVpLjua5LJpPBKhSwsjYZ06IyUIXdGnYhg2UlvmtlTYrFImbegv5+khxDgKKQNfR5baRSOdtXLFCv1zl9+jSKAcODwxTsAgoKwhBEcXKSpSoxdZO+vj6a2VWklPi+n/iclBiGgWmaqQbO5XK4Tjc9dLlcjkqlkuR9Qknisdoik8uBpYOUuLaBYZqJT3e7oFhJXI5A9Z1zWjVnvbpn9y4uXnib8z89ie04WPfcw3B1EGwbghiEkkj9CLBAN0z6K/3U3BqaGiCimLXlFdyOgyYULMMkl8uhqiorKysYhkGhUOCWoSGGajV0I4kQqmmw8dCuVAgpioKuaLiqihZLIlUniCJ0VUcGHprvvqJ+denYkvj4Z//Qcb1ivV5ncX6eer1O49oC60tLKFIi4hjNNBCahlSS+oKRyVAqlTB0Bd/3WVhYoNFopJpjfn6edrvNerNJLpdjx44djI+PUywWt1hYJvmfLtB1HV3XMVUTXdFQhIKqqEgkqpJkcZHbnjM+tetPNfHStNf5uv2Sc9eep6UaMDV/mZcvnKB7xqVSqXDHHXdQrVYZH7mVWq3GQK6UULJukTNstOERFsQCmxstnHYHp93Bdz2iIMTruti5LMPDwwzcMohlZ5BALGNiVYCiosQJgYgwRlUFqtg6dBJkGCK2Ckdea/1FXsLXAOzWxtd2jo4+XSqV6Jupsri4yKVz06ytrbGwsEB/fz97btvN5OQk+3ftTWpleiK2LctKMoRslsHBwTShrNVqDA8P03Y6DAwMpFmIqqqphT3PQzcMFKEQy0SDqEovkd+W0Ech8fTs1wXIxN5/c/9U9ZurL1YGR54ytAzuQYeJodswtnzN8zzUrmC9vkaz1GKgMgSaThCGaKqWCCDLplgspXJUCIGUkoGBW1KAUkp8N0mlhBAYQodAEsb+1vMQix5lS2JFJfQC5Mbqd3J/8dcX0yRUfJdIfmHhi4FuPeX7PoqiUKvVGBsbY2BgIM0eepmAbdsJK22l7T2QQJqb9UD2UqXt1cvtrZfP9X7/3HgcIa5OfUm88kqYAgZg7+QxuXD1G5ubm59ptVrYts34+Dg7d+5MS0495tM0jSAIbvh4b9Lt1u0tanuSeTOgm1svr+vtiNhofkN/8bEL6TzpSkCab538S29jfW5tbQ3HcVK/6xVMehMKIVK2ire063YL9UDd/P/293vP9OoYPR3d0zRSSmKnM6efO3lIHPrZ9cINlW/xkd9astcWftfvOsRxnAqdHhVvB9BLm24GdDMoTdPSZ7ePbbfozU0IgYgjjMXpT4gnfqOxfeznSvUf+p0/OmZvNp+NwoTzDcNIg3pv9b3eqwDd3HsAbwa6HWQPaG98+zNSSli48jmx58BrN+N7x7uFP/nq888X2mufU4W4of7b89Me4J41toPYDma7Bbdv9TvtSu+7URTB/PTn1PE9z70Ttl96Ajoz55+xRnc9p2xp0x7Q7f63vfdcYPv4zVu+3V16z6U+HPgb+vK1P7Mm9v3CCvy7NnfqzJPSd9ellNJxnPTmKAgC2el0pOM40vM8GQSB9DzvhpuiKIrS26YgCKTv+9LzPOm6bnqzJKVM3ulsXg3Onjj4bnje9brJ2rP/JX74n7d7y4svRkFSpezVfnuV9l8Wqn7hodrqke+xND31wtp//ft9+r5fOfJueN5zkx9Ddc+ffmrh4ts/Pn/mjLx8+bJstVqy0+lI3/dlGIbS933p+76Mti4aoyiSQRCkvTfueZ70HEe6q0s/Ds69/qD8GOp7xfGe7uluAP7pe/Xv7//4r1mDo7+/554DT5UHBov61gXN9kp8LxT2DicAUYgM/TnhukeU1vIL6pc/+T/iH04G72f+9w04BX4IhXMPmN4Xn39MZPseVnOFg1IoBaHpk4qSGCzyvbdkGLSQEul2jhjt1e/x558/Ccd88V2iDzLv/wLuq1jCE5JZuAAAAABJRU5ErkJggg==";
 主要按钮();
 }
 if(悬浮窗==3){
 悬浮窗=0;
 窗口N.dismiss();
 logo="iVBORw0KGgoAAAANSUhEUgAAAC8AAAAvCAYAAABzJ5OsAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAWSklEQVRo3rV6e5BV5ZXvb+993u9z+vSDftIw0kCDHaWRMdAQuCEKhEJMxCGamUTL5GqmkrK8oqlAwtyyokm0pKRUTKYyahQTtQjXiAwChd3yaEKjaNs8mn6ffp/nPvv9+tb8AX10vImZmJlVtevss2ufs3/f+tb6fWv9vs3hb7XLl72nKitbE17vSj/HLfZzXB1sux6M1YMII6kUYrEYhEDguOD3p2Sij9KO077ynXe6sG6dCY6jz/to7nP9ikg4msstq3O5/rkiFFrOVLVeKRZhaBoEQUAoFEIwGITL5YLb7QYA2LYNRVFgmCZMxsBcroIRDP52VNNeWhOPnwbH2X+zIz/Tdu7kj+dy64aKxXeLuk6O45CmaWRZFjHGiDFGn7ZsNkuSJJGiKKQoCjHGyLZtMk2THMehnCzRgCi+eyKX24BXXxX+Rzx/KJOZf43f/3g5z2/w8Dx4nocgCEilUuA4DrZtQ9d1MMYQDAYRi8UQDAbB8zw0TYOiKJBlGZFIBIZhwLZtWJaFxrlzoGkaVNOEyPEHBgThgXWRyKX/NvDdknRvYyDwUx9RzDCM0sMZY6isrPxENFEJFGMMHMchGAyCMQbGGCRJQjweh2VZpXAamxiHZVngOA5+vx/k8RRGwP3zDZHI3r+UD58NnogbtKyna1yuewUiOI4DAHC5XOA4DowxqKqKQqEATdNARMhms+jp6UF3dzcmJydx+PBhVFVVoaWlBXV1dVi+fDkSiQQaGxsRDochuF3wer1wCa4rjwTBZgwp03rl73y+O8Fx7K8Hv3Mn379t20vVHLfVNE04jgOv14tAIAAAmJycxPj4OHp7e9HR0YH29nakUimoqgqe51FTU4PGxkbU1NRgZGQEY2Nj6O/vx5w5cxCJRNDc3IyysjJ8++67UF1djbKyMliWBU3TAAAejwfjjO2dFwx987MG8CcH1a+qL5umSYwx0nWdVFUly7JIlmXq6Oige++9lxoaGojjOJo7dy499NBDdP78eSIiUhSFJicnqVAokKZpJIoiERFJkkS2bdPrr79OW7dupUgkQuFohO78x2/SgYNv0fjkBKm6RpZjk2GZJEpF6pfll0H0X0/kftPcc+nSJTJNkyzLoqmpKSIi6uzspLVr15Lb7aZQKES//OUvSdd1EkWRcrkciaJIiqKQLMulo1gskiiKJMsy2bZNRESMMTJNk3Rdp8NHj1BFVSWBA31xxXLq/ONp6hvoJ0ZEQyPDNJwaoUHbfhZEfzk/uyXpXtNx6NKlSySKIp09e5Zs26bDhw8TACovL6d0Ok3j4+P02muvUT6fJ1EUSb9KnY7jkGmaNDNrM2A1TaNsNkvpdJpkWS5RaTqboXQ2Q/2DA9S8eBH5An5asbKNDh89QpZjU66QJ8XQ6d8vXfreZwL/N1muSstyXtM0ymQyJEkSZbNZ2rhxIzU3N9Ojjz5K3d3dZJomTU1Nka7rlE6nKZfLkaIoZBgGaZpW4nXLskjTtBKvS5JExWKRdF0nwzBIlmUaGBokhxgxIsoV8mRYJs2b30Tz5jfRsfZ3iBGRoql0tuej/JuStOCTePlPMssy03xSMM0YAJSVlSGVSmH16tUYGxvDnXfeiYcffhhNTU3o6OiAKIoAgHA4DLfbXaJIjuNKbGRZFogIhmHANE0IgoBAIACv1wtBuBLGmUwGfX19yGQzKBaLkCQJ+/fvR0NDA9avX4+p6SkAwOzq6lh8fPznfzL+Dw0NrZvIZKhYLBIRUaFQoAceeICSySTt27ePJicnqaenh/r7+ymXy5HjOCRJEpmmSYVCgdLpdCkhTdOkbDZLqVSKVFUlWZZLCT9z//j4OA0PDxMjKh0joykaGhkm07bo7PvvUXllBe34yY/pg+4PiRHR+b7LdFIpfvXTfC6MqOq7xWKxtHzv37+fKioq6Pe//z319/cTEf2nWJ0ZpGVZpKoqKYpSSkjHcUiWZcrn81QsFkmWZdI0rZQLuq6TpmmkaRoViiK9+NJvqOfCeSoURdIMnTRDp7xYoJHRFF3TNI9++tijlBobJUVTaViSOtDV5QYAFwDsz+WayuPxFbaigOM4jI2N4ejRoygvL8eCBQuQSCSg6zry+TxEUSzds3v3bmzevBmCIIDjODiOAyJCNBrF3LlzUV9fD9u2QUTQNA2GYSAYDCIQCECWZYyNjWHn//0XuN1uPPbYY4hEIug8dQp7X3kFX/3qV1FRUYEbbrgB7e3tmD9/Pm7ZdAuiutZ2cN6cZeuA4wCAd/r6npNlmbLZLFmWRe3t7bR+/Xr6yU9+QoqikK7rdPbsWXIch44cOUKhUIgaGxspmUwSz/MUCAQoGAwSx3HE8zxde+219Mgjj1BXVxfpul6aDUmSSBRF6u7upvvvv5+CwSDNX7iAZtVUk9vrobLyJDU0ziZfwE/NixfR6TN/pPMXL1DrDUvp54//ghRNJUZEZyYmnsXOnTzQ0+PpnZ4o2ORQRszS4OgQffs7d9GcprlUUETSbJ3ycoFefOU31HrjUoIA8kcC5PK7yRP0Es+BOIBqqqto7pzZdOFCDz355BPEcSDbNqlQzJNDNjFy6A8H3qCBoX4CB/pfN3+ZNm+5lUKJCPmjQQrEQuQOeskd9FL9382mVV/+EoEH9Q5eptvv/AeKl8Xog+5zxMihcTFfQCrl59+MBVtjoWBUMzSEQiEEAgGkUik0NTXB5XLh4sWLOHToEP7xjm8in89jxco2eDwexONxeL1eBIMBJBIxjI9Porm5GfF4HOvXr0dLy7Xo6urCxMQEFEWBoiqorKyE1+tFZVUFVq5ciR07dsAwDGiSAgBwHAeJRAJtbW146KGHEIqGcfHiRQSDQaiqilAoBIc5cBGL7hOEJbzHYddFfQGokgwP70I4EMRgXz++uHQZPJyALzQvxhOP/RyrVqzAoT8cQMDlgQc8xHQWcq6IoM+PQq4Av8eNmqpZSE9P46Ft2+DYNniOQ0WyHHJRQigQRDQcQSgQhK5qWLWiDbWzqhELhBAJhRALhBBweaDkRcSDYcypa4CclzArWYG1X1oDn8eLaDgCMAJn2Shj9io+4LA24WqyAYAgCMhms2hpaQFjDOPj45BlGZqmweVy4fTp08hkcmhubkYiEUM6k8W1ixdhyZIlGBwcxJ49e5BOp3HXXXehvr4eiUTiiucVBeFwGJZlIR6Pw+/34+GHH0Y6nYXX60WhUIDjOHAcB4IgIJPJYPXqVVi0aBE2bdqEhQsXQhCEUiVbEQg287FAoJaYg1AgCOY44BhBAIf66how00LI48O/v/Em5HQO2x/YhsaqGiyY3Yj00CiUXAF+jwcXz1/AqVOduNBzHn6XBytvXI5VK9oQC0fgGCbKojEMDw0hEY+DGMO3v/UtBLw+HG/vQH2yHNfU1CPmDcDRDLgshld+/QI2rL0JvR+dh8/rQ/+lXpzuPI1dTz4Jx7ZRU10NP4d6V8jng6qqCIdCsCwLIIIgCBAEoVQG1zc2YseOHTBNE3V1dZicnETnyVNwu93QmQ2fz4fKykokEgmsW7cOCxYsQLwsAW8ggGI+j3gyCYs54DgO4XAYt956K2bNmoUdO3bg0P4/gDGGRFkZ8vk8vva1r6FYLEI1dGzfvh2jw8PI5/O46aavoKOjAw8++CBs20bY513EZTSFrEIBVZWVsG0bcBiSySSOHDyEBQsW4NLFixgaGkLA7cXNN9+Mo4fexsmTJ7Fy5UpMTU0hpyuYPXs25s2bh2AwiGg0Cl8kgr2/eRFbtmwBEUHXdRiWCZ/PVwrPc+fOYcWKFVCnc0ilUojF43AcB3VN83Dh3Dmc+/ADbN26FelMBgMDA5iYnsJdd92FdDYDIsK0qsAlcBwkXYdpmldrFAeyokKWZTiOU2omXnjhBZw8eRJLWr6ACxcuIJVKQZIkRKrK8e677+Kee+6BpmlYt2EDLvf04MSJE9i4cSPcbjfefPNNgOewefNmXLx4Ea2trdizZw/8fj+aahowODgINjAAv9+PYx3tCAQC0DQNw8PDKEsmkUgksGxlG267/XYIHg+YZQGMwWU7DA0NDQARFEWBi7tSqw0NDaG5uRn5fB4ulwurV6/G448/juqKSvzwhz/Ea6+9httuuw218+bi0KFDcLvdaGlpQTadhiiKOH/+PFKpFEKhEJ555hlk8zlEo1HcdNNNePXVV9HS0oKRkREsaWqGbds48NZbyOVyiMRj8Pl8sJmDEydO4BePP47q6mrsf/111FZXg2wbjuPAFwjA5fV6IEkSXIKAUDgMEFBZUY4zZ85g48aNqKiowMDAAJLJJDZv3oyysjJUV1fj1ltvRXV1NYLlCXz3u99FV1cXfD4fJicnkUqlUFdXh927d+P999/HrFmz8PdfvBFnz57FsWPH0NXVhTVr1uDrt98OYzqHeDyOa665BoVCAbzbBSICA4HneWSzWdTX12PZsmVIX3WMZVnQvd6iS2XOibDHvdyxrkgXRVHEDTf+PS709cIT9MOxbNTOboBjmKhtbEA8HkekMom54SDC5eXQFAn+cBjJygp4/D5E4jFs3nIbFl//BQwPD+PLX1mLxYsXAwKP9957D5qmoWnhAsybNw+SVEQw6EftnNng/V4QEXw+35Vakb9SWpOLB9wC4BagWhYi8RgAYFgsfOgqmmaqzO+H4Vzhz1wuhzVr1uBXe55DLpdDLBJFKBRCsjaOSCRSkjc8Hg9gGMhkMnCLIqqqqsAYQzabRVlFBerr6zFnzhzwVyUOcEBFRQVcritqARGhr68P8xuuNOQutxvhcBjxeBwQBDDmgDGG/sEBeAMBdPzhDVRXV0HXdQCAJbhSvOF2dWumAQZCPJFAVU01ltywFLmiiN++/hqi5WUoqDK8sTDI50bR0iE7JrxlUQynJ+D1+1BVV4t4RTkUTUXn2TN47lfPoft8D0bGRnHug3P44MMPkMvl4PF6QQCm02moho7K6lnQeQIf8iNQFoM7EoTl4mCQDcUyIBkampoXIpfP4Ufbt2NhczN0w0AgGITjdvfwacdpJ5cLPM/Dsi0IgoDGxkYsWLAAzz//PLLZLOrq6mBZFvr6+kCf0m/cbjdABENVsW/fPvzud7/DyMgIstkskskkqqurUVtbWyqBfT4fPJ4reeb1emFZFnw+H2KxGPx+PxzHKXVkPp8Poiiis7MTiqLgO9/5DlRVxXQuh35Fa+fX+MNdxAsiBB7T2QwKUhGBcAjfuuduqJaB3XueQaK8HI7AQbEM+KNhyKaObLGAYDyKeHkSqqbCGwyg5+IFZLJZ3LZlC6bTaXA8D38wgFgijkgsCt4lgBN4BMMh+ENBOCDozIYJBhMMBjmweQAeF1x+L1x+LzTbxHO//le0XPcFfPkra5FIlsEfixU3GsZZHhxnDEjSbxljCIfDCAQCYIzhlltuQVtbG3bt2oWJqQl4vV40NTXBcRzIsoxQKAQAmLoqPs0IRWVlZVi4cCEOHjyIXbt2obe3F+Pj44hGopjTOAemaYIxhng0DkEQkIgn4Pf7rzZ0BLfbDa/nSk4oioJisYgDBw5g7dq1iEaiMAwDeXL2orbWAAC8Xcwtz1sSyZZEii2TYsukWgqplkL+iI++dc8/kU0W5eUciVKBFE2mP3adJkWTSVVlOnPmNB0+fIh+9rNH6dlnnybGbEqnp+iaa+bS9753L01NTZBlGVQo5MhxLNI0hTRNIcsyqG9siM589D4Z5NDgZIqyUp4Msuh830V6YveTVFU3i/7PDx+ki70XyCGbJEOlg7ncilIb+JVw/PSAUTxRIfDLiQgc97G+8+yzz+K+++7DddddhzvuuAPRSBQTkxOoqalBZ2cn9r70MsbGxrBmzRqsWrUKVVVVUFUViqJg06ZNkGUZo6OjJb1+RoAluqKhJpNJ1FXXoev9LjQ0NODcuXNIJBLYvn07jh07hn/91a9QW1sLv98PSZJgeLzH1w0MnP5Y+uA4e9xxfmrT/y/KbtiwAdFoFEeOHMG+ffswOjaK9957Dy6XCwMDA9iyZQu+8Y1vYMOGDWhtbcWsWbPgOA4aGhqwbds2GIaB7u5uiKIInufBGCv1vDzPo1gsIp1Lw+/3ozxRjsuXL2PTpk2YmprC8ePHcdvXb8PSpUuRSCTgAOg17Z+htdX6T7rNikD8UIbRWzOxN+OZWDSGp556Coqi4Pvf/z6eeeYZnDp1Cowx1NXVobW1FbfccgsWLlwIwzCQy+WgKEpJp2GMobe3F7IsfywW8XxpdsfHx+HxeNA8vxlP7HoCe/fuhcfjwa5du1BVVQVN18AYg9/vhxUIHGgLhw/O/I/rY2mVc/qLxQeiXme5nxeiM4OYTk9j86bNyGazEAQBb7/9NhzHwd13343rr7++NEjDMFAsFkvhMXNUVFSUvDxDrzzPlxy05Nrr8Mabb+CRRx7B+11n8bPHf4EtW7agorwc6XQajs8Hxhh0kLi3qH0XyaTzZyW/Ll28TzSLpJgyKaZMfcOXaSDVT7qjkU0WtVx3LVXXzqLevkvEyKHp6UkSxTxJkkgTE2NkWQbpukr5fJb6+y/Tiy8+Ty+88G80NTVBkiQSkUOM2aTrKlmWQSOTowQeBDdHv37pecoUc2SRQxf7L1G2mCODmaTZOp0ytDs+jdX16Qutvugz5/XC4nqO+98AUFlZiZGRERARJEWCbdu47777EI/HwYjhsccew6JFi7By5UrMnj0bgiCgs7MTHR0duHz5Mn7wgx9AEAREo1FIknSliXac0myMjY1hxZdW4uDBg/B5fLjc1wu3y4VYLFaq/yeI23Ojx/fKX1SJZxS0Xjm3VzYkaj/5DtlkkWLKtO1HD1JtfQ0VinmamBovUeXRo4fp6ad3049/vJ3uv/8HtGXL1+mpp3ZRJjNNk5PjJYocGRkiIocMQyPLMojIoeN/PEnesJ+yUp4kQ6Gx6XGyyaGRiRRZZNMlVdx7RaP5a4yIu6AWXkkXpmlwdIBssujmjTfR0mWtNDk9QYomU6GYJ9PUSRTzNDIyROfPf0QXLvTQ6OgI5XIZKhRyZJo6GYZWAuw4FjFmk+NYZNsmHX7nCIXiYRocHaIZ7UizdbLIpiFNemlG2vtT5vqz4DmOFhDdOejRyBLFrbIqI5vNoq2tDdFoFBzHQRRFhIMf77kGAgEQETweD7xeb2nf6mN/fMxiM+ehUKikJM8kNPE8+k3z5/M7u36E1av/7P7sZ08HxzmNrsAdfW73nVlZEsfGxkqt3YyEbds2eJ5HIBBALBZDOBwuAZ+hw08D/uRRnigDHAalKAHEYAm8eFbTN873+B/+LOB/GfxVh62vnv3yGYfdOGHbb12/dGmppna73aUqcEZknVk9Z65f8QFX+vzkOQDE43HYto2sKGLMMF7+rcMvbAtG3vxbtvX/tB075jqtKBsGirl3VdugqfRkiRo1TSFdV0vxrWkKqapc+v7nYl4yVMKsir33tx9e/FdtnH3udw+6utztC+ctDYjyN+eXJ7fCsqLcVfqbWfpnQmVmQZrxOs/zsABoxFI5m711VtWe3hKPX/g87x58PvAztnMnj1WrPIeXtLQmOX5VTHA1e8HVe4gtBwCB48B4rmgyfMgAzuFoRATXc9lm/+/WTKYPL7xgYufOv2qP9ZP2H+pMUj9Yhfm5AAAAAElFTkSuQmCC";
 主要按钮();
 }
 }}));
 layout.addView(的);
 
 var 的=new android.widget.Button(ctx);
的.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(catColor));
的.setText("窗口|顯示位置|切換");
的.setTextColor(android.graphics.Color.parseColor("#000000"));
的.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dip2px(ctx,210),(屏幕高度/9)));
的.setTextSize(15);
的.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){
 if(显示位置=="靠左"){
 显示位置="靠右";
 load("§r§2當前窗口顯示位置為:"+显示位置);
 menu.dismiss();
 主菜单();
 }
 else{
 显示位置="靠左";
 load("§r§2當前窗口顯示位置為:"+显示位置);
 menu.dismiss();
 主菜单();
 }
 }}));
 layout.addView(的);
 }
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("___________________________________________");
功能.setTextSize(9);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){

}}));
layout.addView(功能);
 if(显示位置=="靠左"){
 窗口显示(layout,false,true,"LT",0,0);
 }
 if(显示位置=="靠右"){
 窗口显示(layout,false,true,"RT",0,0);
 }
 }catch(err){ERR(err)}});
}

function 坐标传送(){Ui(function(){try{
 var layout=new 线性布局(ctx);
 layout.setOrientation(1);
 
 var Scroll=new 滑动布局(ctx);
 
 var layout1=new 线性布局(ctx);
 layout1.setOrientation(1);
 
 Scroll.addView(layout1);
 
 layout.addView(Scroll);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("X:");
功能.setTextSize(25);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){

}}));
layout1.addView(功能);
 
 var 功能1=new 输入框(ctx);
功能1.setText(String(Player.getX()));
功能1.setHint(FontColor("§r§9請輸入x軸"));
功能1.setTextSize(25);
功能1.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能1.setMarqueeRepeatLimit(-1);
layout1.addView(功能1);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("y:");
功能.setTextSize(25);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){

}}));
layout1.addView(功能);
 
 var 功能2=new 输入框(ctx);
功能2.setText(String(Player.getX()));
功能2.setHint(FontColor("§r§9請輸入y軸"));
功能2.setTextSize(25);
功能2.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能2.setMarqueeRepeatLimit(-1);
layout1.addView(功能2);
 
 var 功能=new android.widget.TextView(ctx);
功能.setText("z:");
功能.setTextSize(25);
功能.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
功能.setMarqueeRepeatLimit(-1);
功能.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(0,0,0,0)));
功能.setOnClickListener(new android.view.View.OnClickListener({
onClick:function(v){

}}));
layout1.addView(功能);
 
 
 var 功能3=new 输入框(ctx);
功能3.setText(String(Player.getX()));
功能3.setHint(FontColor("§r§9請輸入z軸"));
功能3.setTextSize(25);
功能3.setTextColor(android.graphics.Color.parseColor("#ff00f9ff"));
功能3.setMarqueeRepeatLimit(-1);
layout1.addView(功能3); 
 
 对话框(layout,"坐標·傳送",null,"传送",function(){
 
 Entity.setPosition(getPlayerEnt(),Number(功能1.getText()),Number(功能2.getText()),Number(功能3.getText()));
 load('§r§b傳送到X:'+功能1.getText()+' Y:'+功能2.getText()+' Z:'+功能3.getText());
 },true,"取消",function(){
 
 });
}catch(err){ERR(err)}})}

var 自动搭路=new java.lang.Thread(new java.lang.Runnable({run:function(){
 while (true) {
 自动搭路.sleep(100);
 var x = Player.getX();
 var y = Player.getY();
 var z = Player.getZ();
 if (脚下方块 == true) {
 Level.setTile(x, y - 2, z, 20,0);
 Level.setTile(x + 1, y - 2, z + 1, 20,0);
 Level.setTile(x + 1, y - 2, z - 1, 20,0);
 Level.setTile(x - 1, y - 2, z + 1, 20,0);
 Level.setTile(x - 1, y - 2, z - 1, 20,0);
 Level.setTile(x, y - 2, z + 1, 20,0);
 Level.setTile(x, y - 2, z - 1, 20,0);
 Level.setTile(x + 1, y - 2, z, 20,0);
 Level.setTile(x - 1, y - 2, z, 20,0);
 }

 }
}}));
自动搭路.start();


var 破=new java.lang.Thread(new java.lang.Runnable({run:function(){
 while (true) {
 破.sleep(100);
 var x2 = Player.getX();
 var y2 = Player.getY();
 var z2 = Player.getZ();
 if (脚下消失 == true) {
 Level.setTile(x2, y2 - 2, z2, 0,0);
 Level.setTile(x2 + 1, y2 - 2, z2 + 1, 0,0);
 Level.setTile(x2 + 1, y2 - 2, z2 - 1, 0,0);
 Level.setTile(x2 - 1, y2 - 2, z2 + 1, 0,0);
 Level.setTile(x2 - 1, y2 - 2, z2 - 1, 0,0);
 Level.setTile(x2, y2 - 2, z2 + 1, 0,0);
 Level.setTile(x2, y2 - 2, z2 - 1, 0,0);
 Level.setTile(x2 + 1, y2 - 2, z2, 0,0);
 Level.setTile(x2 - 1, y2 - 2, z2, 0,0);
 }
 }
}}));
破.start();

function 冲刺(实体,x,y,z){
var a=getYaw()*Math.PI/180;
var b=getPitch()*Math.PI/180;
xx=-Math.sin(a)*Math.cos(b);
yy=-Math.sin(b);
zz=Math.cos(a)*Math.cos(b);
setVelX(实体,xx*x);
setVelY(实体,yy*y);
setVelZ(实体,zz*z);
}

function 撤(实体,x,y,z){
var a=getYaw()*Math.PI/180;
var b=getPitch()*Math.PI/180;
xx=Math.sin(a)*Math.cos(b);
yy=Math.sin(b);
zz=-Math.cos(a)*Math.cos(b);
setVelX(实体,xx*x);
setVelY(实体,yy*y);
setVelZ(实体,zz*z);
}

var 喷气=new java.lang.Thread(new java.lang.Runnable({run:function(){
 while(true){
 if(喷气背包==true){
 冲刺(getPlayerEnt(),1,1,1);
 }
 喷气.sleep(70);
 }
}}));
喷气.start();

var 喷气2=new java.lang.Thread(new java.lang.Runnable({run:function(){
 while(true){
 if(喷气背包2==true){
 Entity.setVelY(getPlayerEnt(), 0.15);
 }
 喷气2.sleep(60);
 }
}}));
喷气2.start();
 
var 走=new java.lang.Thread(new java.lang.Runnable({run:function(){
 while(true){
 if(脚下虚空==true){
 Entity.setVelY(getPlayerEnt(), 0);
 }
 走.sleep(50);
 }
}}));
走.start();

var 缓缓=new java.lang.Thread(new java.lang.Runnable({run:function(){
 while(true){
 if(缓降==true){
 Entity.setVelY(getPlayerEnt(), 0);
 }
 缓缓.sleep(250);
 }
}}));
缓缓.start();


function MCPE_GUI_SHOW_CLIENT_MESSAGE() {
 var msg_list = [];
 for (var i=0; i<arguments.length; i++) {
 msg_list.push(arguments[i]);
 }
 clientMessage(msg_list);
}

function getAllPlayer(){
var players=[],p=[];
var ents=Server.getAllPlayers();
for(var i=0;i<ents.length;i++){ 
var e=ents[i];
if(Entity.getEntityTypeId(e)==63){
if(p.indexOf(e)==-1){
players.push({
entity:e,
name:Player.getName(e),
hp:Entity.getHealth(e),
maxhp:Entity.getMaxHealth(e)
}); p.push(e);}
}}
return players;
}


function getNearestEntity(最远选择距离) {
 invalidate();
 var 最远选择距离2 = 最远选择距离;
 var 选取玩家 = null;
 for (var x = 0; x < players['length']; x++) {
 var X距离 = Entity.getX(players[x]) - getPlayerX();
 var Y距离 = Entity.getY(players[x]) - getPlayerY();
 var Z距离 = Entity.getZ(players[x]) - getPlayerZ();
 var 距离 = Math.sqrt(Math.pow(X距离, 2) + Math.pow(Y距离, 2) + Math.pow(Z距离, 2));
 if (距离 < 最远选择距离2 && 距离 > 0 && Entity.getHealth(players[x]) >= 1) {
 最远选择距离2 = 距离;
 选取玩家 = players[x];
 }
 };
 return 选取玩家;
}

function invalidate(){
 try{
 if(mode){
 players=Array.slice.call(Server.getAllPlayers());
 players.shift();
 }else{
 var ls=[];
 for(var i=0;i<=10000;i++)
 if(Entity.getEntityTypeId(i)==63)
 ls.push(i);
 players=ls;
 }
 var arr=[]
 for(var i in players)if(shield.indexOf(Player.getName(players[i]))>-1)arr.unshift(i);
 for(var i in arr)players.splice(arr[i],1);
 }catch(err){load(err+"\n"+err.lineNumber);}
}


function aimAtEnt(自瞄对象) {
 if (自瞄对象 !=null) {
 var distanceX = Entity.getX(自瞄对象) - getPlayerX();
 var distanceY = Entity.getY(自瞄对象) - getPlayerY();
 var distanceZ = Entity.getZ(自瞄对象) - getPlayerZ(); 
 var 玩家实体ID = '63';
 if (Entity.getEntityTypeId(自瞄对象) != 玩家实体ID) {
 distanceY += 0.5;
 };
 var _0x2bf6x178 = Entity.getX(自瞄对象) + 0.5;
 var _0x2bf6x179 = Entity.getY(自瞄对象);
 var _0x2bf6x17a = Entity.getZ(自瞄对象) + 0.5;
 var _0x2bf6x17b = Math.sqrt(distanceX * distanceX + distanceY * distanceY + distanceZ * distanceZ);
 var distanceY = distanceY / _0x2bf6x17b;
 var 俯仰角 = Math.asin(distanceY);
 俯仰角 = 俯仰角 * 180.0 / Math.PI;
 俯仰角 = -俯仰角;
 var 偏航角 = -Math.atan2(_0x2bf6x178 - (Player.getX() + 0.5), _0x2bf6x17a - (Player.getZ() + 0.5)) * (180 / Math.PI);
 if (俯仰角 < 89 && 俯仰角 > -89) {
 Entity.setRot(Player.getEntity(), 偏航角, 俯仰角)
 }
 }
}
function runThread(func){var a=new java.lang.Thread(new java.lang.Runnable({run:func}));a.start();return a;}


runThread(function(){
 while(true){
 if(喵==false&&rao2==true){ 
 if(getNearestEntity(10)!=null){
 绑绕2(getNearestEntity(10),true); 
 }
 }
 lang.Thread.sleep(50);
 } 
 }); 
function 绑(){
if(rao2){
 rao2=false;
 喵=false;
 }
 else{
 bang=false;
 rao2=true; 
 }
 } 

function 绑绕2(player,flashMode){
 runThread(function(){
 try{
 喵=true; 
 while(喵){
 invalidate();
 if(players.indexOf(player)==-1||Entity.getY(player)==0){
 喵=false;
 break; 
 }
 else{
 var yaw;
 var wtime;
 if(flashMode){
 yaw=Math.random()+0;
 wtime=40;
 }else{
 yaw=Entity.getYaw(player)-0;
 wtime=0;
 }
 var pointX=Entity.getX(player)-Math.sin(yaw*Math.PI/180)*2,pointY=Entity.getY(player)+0.5,pointZ=Entity.getZ(player)+Math.cos(yaw*Math.PI/180)*2;
 Entity.setRot(Player.getEntity(),yaw+180,30);
 Entity.setPosition(Player.getEntity(),pointX,pointY,pointZ);
 Entity.setVelY(getPlayerEnt(),0);
 lang.Thread.sleep(wtime);
 }
 } 
 }catch(err){showTip(err,1);}
 });
}


//自动进程1
runThread(function(){
 while(true){
 if(喵==false&&bang==true){ 
 // print("test");
 if(getNearestEntity(10)!=null){
 绑绕(getNearestEntity(10),false); 
 } 
 lang.Thread.sleep(50);
 } 
 }
 }); 

runThread(function(){
 while(true){
 if(喵==false&&rao==true){ 
 if(getNearestEntity(10)!=null){
 绑绕(getNearestEntity(10),true); 
 }
 }
 lang.Thread.sleep(50);
 } 
 }); 

 //自动进程3
 var Thread = new java.lang.Thread(
 new java.lang.Runnable({
 run: function() {
 while (true) {
function 设置家(){
 homes={设x:Player.getX(),设y:Player.getY()+1,设z:Player.getZ()};
 return true;
}

function 回家(){
Entity.setPosition(Player.getEntity(),homes.设x,homes.设y,homes.设z);
}
 Thread.sleep(200)
 var yy1=Player.getY()
 var 速度=(Math.sqrt((yy1-yy2)*(yy1-yy2))*4).toFixed(1);
 var yy2=Player.getY()
 if(回弹==true){
 if(速度>10){
 回家();
 }
 if(速度==0){
 设置家();
 }
 }
 }
 }
 
 }));
Thread.start();

function 长臂猿(){
 try{
 runThread(function(){ 
 invalidate();
 load("§r§b已開啟長臂猿");
 for(var i in players){
 Entity.setCollisionSize(players[i],8,7);
 }
 
 });
 }catch(err){
 print(err+err.lineNumber);
 }
 }
 
function 关闭长臂(){
 try{
 runThread(function(){
 invalidate();
 load("§r§b已關閉長臂猿");
 for(var i in players){
 Entity.setCollisionSize(players[i],1,2);
 }
 });
 
 }catch(err){
 print(err+err.lineNumber);
 }
}
 
 function 自动长臂(){
 if(长臂){
 runThread(function(){try{
 while(长臂){ 
 invalidate();
 var 最远选择距离2 = 15;
 for (var x = 0; x < players['length']; x++) {
 var X距离 = Entity.getX(players[x]) - getPlayerX();
 var Y距离 = Entity.getY(players[x]) - getPlayerY();
 var Z距离 = Entity.getZ(players[x]) - getPlayerZ();
 var 距离 = Math.sqrt(Math.pow(X距离, 2) + Math.pow(Y距离, 2) + Math.pow(Z距离, 2));
 if (距离 < 最远选择距离2 && 距离 > 0 && Entity.getHealth(players[x]) >= 1) { 
 Entity.setCollisionSize(players[x],20,10);
 }
 }
 lang.Thread.sleep(100);
 }
 
 }catch(err){print(err);}
 });
 }
 }

function readtext(re){
if(new java.io.File(re).exists()){
var bu = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(re)));
var data= '';
var vv= bu.readLine();
while(vv!='END'&&vv!=null){
data+= vv+'\n';
vv= bu.readLine()
}return String(data)
}else{return ''}}


//文件选择器
function File_Select(Default_Path)
{
 var File=new java.io.File("/storage/emulated/0/");
var File_Folder=File.getAbsolutePath().toString();
var ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
if(File.exists()&&File.isDirectory())
{
UI(File_Folder_List(File));
}
else
{
print("無法打開路徑"+Default_Path);
}

function File_Folder_List(file)
{
var arr=new Array();
var list=file.listFiles();
if(list==null)
{
arr[0]="/...";
}
else
{
for(var i=0;i<list.length;i++)
{
arr[i]=list[i].getName().toString();
}
arr.sort();
arr.unshift("/...");
}
return arr;
}
function File_Folder_Selected(path)
{
var file=new java.io.File(path);
if(!file.exists())
{
print("路徑不存在！"+path);
}
else if(file.isDirectory())
{
UI(File_Folder_List(file));
}
else if(file.isFile())
{
try
 {
 clientMessage("正在導入中......");
 eval(readtext(path));
 }
 catch(e)
 {
 clientMessage("導入失敗："+e);
 }
}
}


function UI(data)
{
ctx.runOnUiThread(new java.lang.Runnable({run:function()
{
try
{
var dialog=new android.support.v7.app.AlertDialog.Builder(ctx);
dialog.setTitle("請選擇JS文件");
dialog.setItems(data,new android.content.DialogInterface.OnClickListener(){onClick:
function(dialog,which)
{
if(which==0)
{
var pathtemp=File_Folder.split("/");
var result="";
for(var i=0;i<pathtemp.length;i++)
{
if(i!=pathtemp.length-1&&pathtemp[i]!=""&&pathtemp[i]!=" ")
{
result+="/"+pathtemp[i];
}
}
result+="/";
if(File_Folder=="/")
{
load("§r§b已在根目錄，無法返回");
}
else
{
dialog.cancel();
File_Folder=result;
File_Folder_Selected(File_Folder);
}
}
else
{
dialog.cancel();
File_Folder+="/"+data[which];
File_Folder_Selected(File_Folder);
}
}});
dialog.setNegativeButton("取消",null);
dialog.show();
}
catch(err)
{
load("§r§c無法打開選擇器UI: "+err);
}
}}));
}
}
